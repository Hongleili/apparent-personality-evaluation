"""Read-only verification/export of original feature caches, no pickle execution."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib, json, numpy as np, os
source=Path('/content/drive/MyDrive/chalearn_official_results/70ac0575bf09bf29')
out=source.parent/'source_disjoint_20261123_v1'
out.mkdir(exist_ok=True)
cache=out/'cache_bundle.npz'
if cache.exists():
 print('EXISTING_BUNDLE',cache,cache.stat().st_size,flush=True)
else:
 records=[]
 for split,n in [('training',6000),('validation',2000),('test',2000)]:
  paths=sorted((source/'features'/split).glob('*.npz'));assert len(paths)==n,(split,len(paths))
  def read(p):
   payload=p.read_bytes()
   import io
   with np.load(io.BytesIO(payload),allow_pickle=False) as z:
    x=z['features'];ix=z['frame_indices'];zs=z['zero_shot'];scaled=z['zero_shot_scaled'];vh=str(z['video_sha256'].item())
    assert x.shape==(10,768) and x.dtype==np.float32 and np.isfinite(x).all()
    assert np.allclose(np.linalg.norm(x,axis=1),1,atol=1e-4)
    assert ix.shape==(10,) and (np.diff(ix)>0).all()
    assert zs.shape==scaled.shape==(5,) and np.isfinite(zs).all() and np.isfinite(scaled).all()
    assert ((zs>=0)&(zs<=1)).all() and ((scaled>=0)&(scaled<=1)).all() and len(vh)==64
    return (p.name[:-4],split,x,zs,scaled,ix,vh,hashlib.sha256(payload).hexdigest())
  with ThreadPoolExecutor(max_workers=4) as pool:
   for i,r in enumerate(pool.map(read,paths)):
    records.append(r)
    if (i+1)%250==0:print('VERIFIED',split,i+1,'/',n,flush=True)
 records.sort(key=lambda r:r[0]);assert len({r[0] for r in records})==10000
 target=Path('/content/source_disjoint_cache_bundle.npz')
 np.savez_compressed(target,names=np.array([r[0] for r in records]),official_splits=np.array([r[1] for r in records]),features=np.stack([r[2] for r in records]),zero_shot=np.stack([r[3] for r in records]),zero_shot_scaled=np.stack([r[4] for r in records]),frame_indices=np.stack([r[5] for r in records]),video_sha256=np.array([r[6] for r in records]),cache_sha256=np.array([r[7] for r in records]),provenance_json=np.array((source/'provenance.json').read_text()))
 import shutil
 shutil.copyfile(target,cache)
 payload={'files':10000,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'bytes':target.stat().st_size,'original_source_read_only':True}
 (out/'bundle_verification.json').write_text(json.dumps(payload,indent=2))
 print('BUNDLE_COMPLETE',json.dumps(payload),flush=True)
