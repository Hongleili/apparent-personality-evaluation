"""Verify new baseline CSV metrics and reproduce preserved official ridge predictions."""
import os
os.environ['OPENBLAS_NUM_THREADS']='2';os.environ['VECLIB_MAXIMUM_THREADS']='2'
from pathlib import Path
import csv,json,numpy as np
B=Path(__file__).resolve().parent;O=B/'results';T=['openness','conscientiousness','extraversion','agreeableness','neuroticism']
def rows(p):return list(csv.DictReader(p.open()))
checks=[]
for r in rows(O/'baseline_summary.csv'):
 d=O/r['partition_seed']/r['condition'];m=rows(B/'manifests'/r['partition_seed']/r['condition']/(r['split']+'.csv'));p=rows(d/(r['model']+'_'+r['split']+'_predictions.csv'))
 assert [z['filename'] for z in m]==[z['filename'] for z in p]
 y=np.array([[float(z[t]) for t in T] for z in m],dtype=np.float32).astype(float);pred=np.array([[float(z[t]) for t in T] for z in p])
 assert abs(float(np.abs(y-pred).mean())-float(r['MAE']))<1e-12
 assert abs(float(((y-pred)**2).mean())-float(r['MSE']))<1e-12
 checks.append(len(p))
with np.load(B/'cache_bundle.npz',allow_pickle=False) as z:
 names=z['names'];x=z['features'].astype(np.float64).mean(1)
idx={n:i for i,n in enumerate(names)};data={}
for s in ['training','validation','test']:
 m=rows(B.parent/'colab_rerun/repeat_seed_manifests'/(s+'.csv'));ii=[idx[r['filename']] for r in m]
 data[s]=(x[ii],np.array([[float(r[t]) for t in T] for r in m],dtype=np.float32).astype(float),[r['filename'] for r in m])
xt,yt,_=data['training'];xm=xt.mean(0);ym=yt.mean(0);u,s,vt=np.linalg.svd(xt-xm,full_matrices=False);uy=u.T@(yt-ym)
def w(a):return (vt.T*(s/(s*s+a)))@uy
grid=[(float(np.mean((np.clip((data['validation'][0]-xm)@w(a)+ym,0,1)-data['validation'][1])**2)),float(a)) for a in np.logspace(-6,6,25)]
chosen=min(grid)[1];p=np.clip((data['test'][0]-xm)@w(chosen)+ym,0,1)
old=B.parent/'linear_baselines/results';assert chosen==json.loads((old/'selection.json').read_text())['ridge_alpha']
rr=rows(old/'ridge_test_predictions.csv');assert [r['filename'] for r in rr]==data['test'][2]
ref=np.array([[float(r[t]) for t in T] for r in rr]);delta=float(np.max(np.abs(p-ref)));assert delta<1e-8
v={'baseline_prediction_files_verified':len(checks),'prediction_rows_verified':sum(checks),'metrics_match_to':1e-12,'official_ridge_alpha':chosen,'official_ridge_reproduced_MAE':float(np.abs(p-data['test'][1]).mean()),'official_ridge_max_prediction_difference':delta,'official_ridge_matches':True}
(O/'baseline_verification.json').write_text(json.dumps(v,indent=2));print(json.dumps(v,indent=2))
