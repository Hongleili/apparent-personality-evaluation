"""Exploratory source-isolated test; originals are read only, fitted heads start afresh."""
import os
os.environ.setdefault('OMP_NUM_THREADS','2');os.environ.setdefault('OPENBLAS_NUM_THREADS','2');os.environ.setdefault('VECLIB_MAXIMUM_THREADS','2')
from pathlib import Path
import csv,json,hashlib,sys,copy,random,time,platform
import numpy as np
import torch
from torch.utils.data import DataLoader,TensorDataset
B=Path(__file__).resolve().parent
sys.path.insert(0,str(B.parent/'colab_rerun'))
import experiment as exp
T=exp.TRAITS
O=B/'results';O.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def js(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);q=p.with_suffix('.tmp');q.write_text(json.dumps(x,indent=2,allow_nan=False));os.replace(q,p)
def csvwrite(p,rr):exp.write_csv(p,rr)
def torchsave(p,obj):
 q=p.with_suffix('.tmp');torch.save(obj,q);os.replace(q,p)
def frozen(p,obj):
 if p.exists():assert json.loads(p.read_text())==obj,f'Frozen configuration changed: {p}'
 else:js(p,obj)
def rng():
 n=np.random.get_state();return {'python':random.getstate(),'numpy':[n[0],n[1].tolist(),n[2],n[3],n[4]],'torch':torch.get_rng_state()}
def restore(r):
 random.setstate(r['python']);n=r['numpy'];np.random.set_state((n[0],np.array(n[1],dtype=np.uint32),n[2],n[3],n[4]));torch.set_rng_state(r['torch'])
def report(dest,model,seed,split,ix,pred):
 yy=y[ix].astype(float);pp=np.asarray(pred,dtype=float);metrics=exp.metrics(yy,pp)
 tag=model+(f'_seed{seed}' if seed is not None else '')
 csvwrite(dest/f'{tag}_{split}_predictions.csv',[{'filename':str(names[i]),**{t:float(pp[k,j]) for j,t in enumerate(T)}} for k,i in enumerate(ix)])
 csvwrite(dest/f'{tag}_{split}_metrics.csv',metrics)
 return {'model':model,'training_seed':seed,'split':split,'n':len(ix),'MAE':float(np.abs(yy-pp).mean()),'MSE':float(((yy-pp)**2).mean()),'PCC':float(np.mean([r['PCC'] for r in metrics])) if all(r['PCC'] is not None for r in metrics) else None,'ACC':float(1-np.abs(yy-pp).mean())}

torch.set_num_threads(2)
cfg=json.loads((B/'protocol.json').read_text());assert cfg['status']=='frozen_before_new_model_outcomes'
with np.load(B/'cache_bundle.npz',allow_pickle=False) as z:
 names=z['names'].copy();x=z['features'].copy();zs=z['zero_shot'].copy();scaled=z['zero_shot_scaled'].copy();official=z['official_splits'].copy();frames=z['frame_indices'].copy();vh=z['video_sha256'].copy();cachehash=z['cache_sha256'].copy();prov=json.loads(str(z['provenance_json'].item()))
assert len(set(names))==10000 and x.shape==(10000,10,768) and x.dtype==np.float32
assert np.isfinite(x).all() and np.allclose(np.linalg.norm(x,axis=2),1,atol=1e-4)
assert frames.shape==(10000,10) and (np.diff(frames,axis=1)>0).all()
assert all(len(s)==64 for s in vh) and all(len(s)==64 for s in cachehash)
assert prov['annotation_csv_sha256']==cfg['official_manifest_sha256']
assert sha(B.parent/'colab_rerun/experiment.py')==prov['script_sha256']
assert sha(B.parent/'colab_rerun/chalearn_data.py')==prov['data_script_sha256']
rr=list(csv.DictReader((B/'all_labels.csv').open()));assert [r['filename'] for r in rr]==names.tolist()
assert [r['official_split'] for r in rr]==official.tolist()
y=np.array([[float(r[t]) for t in T] for r in rr],dtype=np.float32)
assert np.isfinite(y).all() and ((y>=0)&(y<=1)).all()
idx={str(n):i for i,n in enumerate(names)}
for values,tag in [(zs,'zero_shot_cosine'),(scaled,'zero_shot_scaled')]:
    reference=list(csv.DictReader((B.parent/'qwen_fulltest_analysis/inputs/clip'/(tag+'_test_predictions.csv')).open()))
    expected=np.array([[float(r[t]) for t in T] for r in reference],dtype=float)
    assert np.array_equal(values[[idx[r['filename']] for r in reference]].astype(float),expected),'Original zero-shot cache mismatch'
identity={'runner_sha256':sha(__file__),'protocol_sha256':sha(B/'protocol.json'),'bundle_sha256':sha(B/'cache_bundle.npz'),'software':{'python':platform.python_version(),'numpy':np.__version__,'torch':str(torch.__version__)},'device':'cpu','threads':2,'original_software':prov['versions'],'note':'New CPU software is shared by source-disjoint and clip-control runs; not a bitwise reproduction of original GPU fits.'}
frozen(O/'run_identity.json',identity)
js(O/'input_verification.json',{'n':10000,'feature_shape':list(x.shape),'manifest_hashes_match_original':True,'original_architecture_source_hash_match':True,'source_clip_coverage':{s:int((official==s).sum()) for s in set(official)},'features_allow_pickle':False})
xx=x.astype(np.float64).mean(1)
summary=[]
for splitseed in cfg['partition_seeds']:
 for condition in ['source_disjoint','clip_random_control']:
  dest=O/str(splitseed)/condition;dest.mkdir(parents=True,exist_ok=True)
  manifest=B/'manifests'/str(splitseed)/condition
  ids={s:np.array([idx[r['filename']] for r in csv.DictReader((manifest/(s+'.csv')).open())]) for s in ['training','validation','test']}
  assert len(set(np.concatenate(list(ids.values()))))==10000
  groups={s:{rr[i]['source_prefix'] for i in ix} for s,ix in ids.items()}
  if condition=='source_disjoint':assert all(not(groups[a]&groups[b]) for a,b in [('training','validation'),('training','test'),('validation','test')])
  tr,va=ids['training'],ids['validation'];xm=xx[tr].mean(0);ym=y[tr].astype(float).mean(0);xc=xx[tr]-xm;yc=y[tr].astype(float)-ym
  print('SVD',splitseed,condition,flush=True)
  u,s,vt=np.linalg.svd(xc,full_matrices=False);uy=u.T@yc;cut=max(xc.shape)*np.finfo(float).eps*s[0]
  def coeff(alpha):
   if alpha==0:
    f=np.zeros_like(s);np.divide(1,s,out=f,where=s>cut)
   else:f=s/(s*s+alpha)
   return (vt.T*f)@uy
  grid=[]
  for a in np.logspace(-6,6,25):
   pp=np.clip((xx[va]-xm)@coeff(a)+ym,0,1);grid.append({'alpha':float(a),'validation_MSE':float(((pp-y[va].astype(float))**2).mean())})
  alpha=min(grid,key=lambda r:(r['validation_MSE'],r['alpha']))['alpha']
  csvwrite(dest/'ridge_validation_search.csv',grid);js(dest/'ridge_selection.json',{'alpha':alpha,'selection_used_test':False})
  weights={'linear':coeff(0),'ridge':coeff(alpha)}
  for name,w in weights.items():np.savez(dest/(name+'_parameters.npz'),coefficients=w,intercept=ym-xm@w)
  for split in ['validation','test']:
   ii=ids[split]
   for model,pp in [('training_mean',np.broadcast_to(ym,(len(ii),5))),('training_median',np.broadcast_to(np.median(y[tr].astype(float),axis=0),(len(ii),5))),('zero_shot_cosine',zs[ii]),('zero_shot_scaled',scaled[ii])]+[(m,np.clip((xx[ii]-xm)@w+ym,0,1)) for m,w in weights.items()]:
    result=report(dest,model,None,split,ii,pp);summary.append(dict(result,partition_seed=splitseed,condition=condition))
  csvwrite(O/'baseline_summary.csv',summary)
  print('BASELINES_DONE',splitseed,condition,[(r['model'],round(r['MAE'],6)) for r in summary[-6:]],flush=True)
js(O/'BASELINES_COMPLETE.json',{'rows':len(summary),'partition_seeds':cfg['partition_seeds']})
print('ALL_BASELINES_COMPLETE',flush=True)
# Neural predictors are the prespecified exploratory subset on the first partition.
ns=[];splitseed=cfg['partition_seeds'][0]
for condition in ['source_disjoint','clip_random_control']:
 dest=O/str(splitseed)/condition;manifest=B/'manifests'/str(splitseed)/condition
 ids={s:np.array([idx[r['filename']] for r in csv.DictReader((manifest/(s+'.csv')).open())]) for s in ['training','validation','test']}
 tr,va=ids['training'],ids['validation'];xt=torch.from_numpy(x[tr]);yt=torch.from_numpy(y[tr]);xv=torch.from_numpy(x[va]);yv=torch.from_numpy(y[va])
 for seed in cfg['neural_first_partition_only']['training_seeds']:
  for kind in cfg['neural_first_partition_only']['heads']:
   tag=f'{kind}_seed{seed}';d=dest/(tag+'_checkpoint');d.mkdir(exist_ok=True);done=d/'complete.json'
   exp.seed_all(seed);head=exp.make_head(kind,x.shape[-1]);opt=torch.optim.Adam(head.parameters(),lr=.001);gen=torch.Generator().manual_seed(seed)
   loader=DataLoader(TensorDataset(xt,yt),batch_size=64,shuffle=True,generator=gen);history=[];best=float('inf');bad=0;beststate=None;bestepoch=None
   last=d/'last.pt'
   if last.exists():
    c=torch.load(last,map_location='cpu',weights_only=True);assert c['identity']==identity
    head.load_state_dict(c['head']);opt.load_state_dict(c['optimizer']);gen.set_state(c['loader']);restore(c['rng']);history=c['history'];best=c['best'];bad=c['bad'];beststate=c['beststate'];bestepoch=c['bestepoch']
   if not done.exists():
    for epoch in range(len(history),100):
     if bad>=15:break
     start=time.monotonic();head.train();total=0.
     for bx,by in loader:
      opt.zero_grad();loss=torch.nn.functional.mse_loss(head(bx),by);loss.backward();opt.step();total+=loss.item()*len(bx)
     head.eval()
     with torch.inference_mode():vl=float(torch.nn.functional.mse_loss(head(xv),yv))
     assert np.isfinite(vl)
     if vl<best:best=vl;bad=0;beststate=copy.deepcopy(head.state_dict());bestepoch=epoch+1
     else:bad+=1
     history.append({'epoch':epoch+1,'training_mse':total/len(tr),'validation_mse':vl})
     torchsave(last,{'identity':identity,'head':head.state_dict(),'optimizer':opt.state_dict(),'loader':gen.get_state(),'rng':rng(),'history':history,'best':best,'bad':bad,'beststate':beststate,'bestepoch':bestepoch})
     csvwrite(d/'history.csv',history)
     js(O/'status.json',{'condition':condition,'head':kind,'training_seed':seed,'epoch':epoch+1,'validation_mse':vl,'completed_fits':len(ns)//2,'total_fits':20})
     print('EPOCH',condition,kind,seed,epoch+1,'val',round(vl,6),'seconds',round(time.monotonic()-start,2),flush=True)
   assert beststate is not None
   head.load_state_dict(beststate);head.eval()
   for split in ['validation','test']:
    ii=ids[split]
    with torch.inference_mode():pp=np.concatenate([head(torch.from_numpy(x[ii[j:j+256]])).numpy() for j in range(0,len(ii),256)])
    result=report(dest,kind,seed,split,ii,pp);ns.append(dict(result,partition_seed=splitseed,condition=condition))
   torchsave(d/'best.pt',{'state_dict':beststate,'bestepoch':bestepoch,'validation_mse':best})
   js(done,{'identity':identity,'bestepoch':bestepoch,'validation_mse':best,'epochs':len(history),'seed':seed,'kind':kind})
   csvwrite(O/'neural_summary.csv',ns);print('FIT_COMPLETE',condition,tag,'test_mae',ns[-1]['MAE'],flush=True)
js(O/'COMPLETE.json',{'identity':identity,'baseline_rows':len(summary),'neural_rows':len(ns),'all_fits_complete':True})
print('EXPERIMENT_COMPLETE',flush=True)
