"""Independently verify saved predictions and report prespecified comparisons."""
from pathlib import Path
import json,csv,hashlib
import numpy as np
B=Path(__file__).resolve().parent;O=B/'results';A=B/'analysis';A.mkdir(exist_ok=True)
T=['openness','conscientiousness','extraversion','agreeableness','neuroticism']
def rows(p):return list(csv.DictReader(p.open()))
def write(p,r):
 with p.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(r[0]));w.writeheader();w.writerows(r)
def js(p,x):p.write_text(json.dumps(x,indent=2,allow_nan=False))
assert json.loads((O/'COMPLETE.json').read_text())['all_fits_complete']
protocol=json.loads((B/'protocol.json').read_text());raw=rows(O/'baseline_summary.csv')+rows(O/'neural_summary.csv')
checks=[];verified=[]
for r in raw:
 seed=r['partition_seed'];cond=r['condition'];split=r['split'];model=r['model'];ts=r['training_seed']
 d=O/seed/cond;tag=model+('_seed'+ts if ts else '')
 manifest=rows(B/'manifests'/seed/cond/(split+'.csv'));pred=rows(d/(tag+'_'+split+'_predictions.csv'))
 assert [q['filename'] for q in manifest]==[q['filename'] for q in pred]
 y=np.array([[float(q[t]) for t in T] for q in manifest],dtype=np.float32).astype(float);p=np.array([[float(q[t]) for t in T] for q in pred])
 assert np.isfinite(p).all() and ((p>=0)&(p<=1)).all()
 mae=float(np.abs(y-p).mean());mse=float(((y-p)**2).mean())
 assert abs(mae-float(r['MAE']))<1e-12 and abs(mse-float(r['MSE']))<1e-12
 pertrait=rows(d/(tag+'_'+split+'_metrics.csv'))
 for j,t in enumerate(T):
  assert pertrait[j]['trait']==t and abs(float(np.abs(y[:,j]-p[:,j]).mean())-float(pertrait[j]['MAE']))<1e-12
  if np.ptp(p[:,j])>0:assert abs(float(np.corrcoef(y[:,j],p[:,j])[0,1])-float(pertrait[j]['PCC']))<1e-10
 if model=='ridge':
  grid=rows(d/'ridge_validation_search.csv');chosen=min(grid,key=lambda q:(float(q['validation_MSE']),float(q['alpha'])))
  assert float(chosen['alpha'])==json.loads((d/'ridge_selection.json').read_text())['alpha']
 if ts:
  ck=d/(tag+'_checkpoint');hist=rows(ck/'history.csv');sel=json.loads((ck/'complete.json').read_text());h=min(hist,key=lambda q:float(q['validation_mse']))
  assert int(h['epoch'])==sel['bestepoch'] and float(h['validation_mse'])==sel['validation_mse']
 checks.append({'partition_seed':seed,'condition':cond,'split':split,'model':model,'training_seed':ts,'verified':True,'n':len(y)})
 verified.append(dict(r,MAE=mae,MSE=mse,PCC=float(r['PCC']) if r['PCC'] else None))
write(A/'prediction_verification.csv',checks)
identity=json.loads((O/'run_identity.json').read_text())
for file,key in [('protocol.json','protocol_sha256'),('run_source_disjoint.py','runner_sha256'),('cache_bundle.npz','bundle_sha256')]:
 assert hashlib.sha256((B/file).read_bytes()).hexdigest()==identity[key]
# Reconstruct every saved neural test prediction from the selected weights.
import torch,sys
sys.path.insert(0,str(B.parent/'colab_rerun'))
import experiment as exp
torch.set_num_threads(2)
with np.load(B/'cache_bundle.npz',allow_pickle=False) as z:
 features=z['features'].copy();lookup={n:i for i,n in enumerate(z['names'])}
weight_checks=[]
for r in raw:
 if not r['training_seed'] or r['split']!='test':continue
 d=O/r['partition_seed']/r['condition'];tag=r['model']+'_seed'+r['training_seed']
 ck=torch.load(d/(tag+'_checkpoint')/'best.pt',map_location='cpu',weights_only=True)
 head=exp.make_head(r['model'],768);head.load_state_dict(ck['state_dict']);head.eval()
 saved=rows(d/(tag+'_test_predictions.csv'));ii=[lookup[q['filename']] for q in saved]
 with torch.inference_mode():
  actual=np.concatenate([head(torch.from_numpy(features[ii[j:j+256]])).numpy() for j in range(0,len(ii),256)])
 expected=np.array([[float(q[t]) for t in T] for q in saved]);delta=float(np.max(np.abs(actual.astype(float)-expected)))
 assert delta<1e-7
 weight_checks.append({'condition':r['condition'],'model':r['model'],'seed':r['training_seed'],'max_prediction_difference':delta})
write(A/'selected_weight_verification.csv',weight_checks)
del features
aggregate=[]
for cond in ['source_disjoint','clip_random_control']:
 for model in protocol['baselines_all_partitions']+['ffnn','cnn_lstm']:
  rs=[r for r in verified if r['condition']==cond and r['model']==model and r['split']=='test']
  unit='training seeds on first partition' if model in ['ffnn','cnn_lstm'] else 'partition repetitions'
  vals=np.array([r['MAE'] for r in rs]);pc=[r['PCC'] for r in rs]
  aggregate.append({'condition':cond,'model':model,'repetition_unit':unit,'n_repetitions':len(vals),'MAE_mean':float(vals.mean()),'MAE_sd':float(vals.std(ddof=1)),'PCC_mean':float(np.mean(pc)) if all(p is not None for p in pc) else None})
write(A/'test_summary.csv',aggregate)
first=[]
for cond in ['source_disjoint','clip_random_control']:
 for model in protocol['baselines_all_partitions']+['ffnn','cnn_lstm']:
  rs=[r for r in verified if r['condition']==cond and r['model']==model and r['split']=='test' and r['partition_seed']==str(protocol['partition_seeds'][0])]
  vals=np.array([r['MAE'] for r in rs]);pc=[r['PCC'] for r in rs]
  first.append({'condition':cond,'model':model,'test_clips':int(rs[0]['n']),'n_fits':len(rs),'MAE_mean':float(vals.mean()),'MAE_sd':float(vals.std(ddof=1)) if len(vals)>1 else 0.,'PCC_mean':float(np.mean(pc)) if all(v is not None for v in pc) else None})
write(A/'first_partition_comparison.csv',first)
# First source-disjoint test: paired errors, clustered by source prefix.
seed=str(protocol['partition_seeds'][0]);cond='source_disjoint';d=O/seed/cond;m=rows(B/'manifests'/seed/cond/'test.csv');names=[q['filename'] for q in m]
y=np.array([[float(q[t]) for t in T] for q in m],dtype=np.float32).astype(float)
def pred(tag):
 q=rows(d/(tag+'_test_predictions.csv'));assert [z['filename'] for z in q]==names
 return np.array([[float(z[t]) for t in T] for z in q])
err=lambda p:np.abs(p-y).mean(1)
er=err(pred('ridge'));em=err(pred('training_median'));en=np.mean([err(pred('cnn_lstm_seed'+str(s))) for s in range(42,47)],axis=0)
diffs=np.stack([er-em,en-er],axis=1);groups,gi=np.unique([q['source_prefix'] for q in m],return_inverse=True);sizes=np.bincount(gi);sums=np.stack([np.bincount(gi,weights=diffs[:,j]) for j in range(2)],axis=1)
gen=np.random.default_rng(20261123);draws=[]
for _ in range(20):
 w=gen.multinomial(len(groups),np.full(len(groups),1/len(groups)),size=500);draws.append((w@sums)/(w@sizes)[:,None])
bs=np.concatenate(draws);contr=[]
for j,name in enumerate(['ridge_minus_training_median','cnn_lstm_mean_error_minus_ridge']):
 ci=np.quantile(bs[:,j],[.025,.975,.0125,.9875]);contr.append({'contrast':name,'difference_MAE':float(diffs[:,j].mean()),'CI95_lower':float(ci[0]),'CI95_upper':float(ci[1]),'CI97_5_lower':float(ci[2]),'CI97_5_upper':float(ci[3]),'n_source_groups':len(groups),'n_clips':len(y),'bootstrap_replicates':10000})
write(A/'source_cluster_contrasts.csv',contr)
# Audit saved cache against the independently saved original test zero-shot CSVs.
with np.load(B/'cache_bundle.npz',allow_pickle=False) as z:
 ix={n:i for i,n in enumerate(z['names'])}
 for key,tag in [('zero_shot','zero_shot_cosine'),('zero_shot_scaled','zero_shot_scaled')]:
  rr=rows(B.parent/'qwen_fulltest_analysis/inputs/clip'/(tag+'_test_predictions.csv'))
  ref=np.array([[float(r[t]) for t in T] for r in rr]);actual=z[key][[ix[r['filename']] for r in rr]]
  assert np.array_equal(ref,actual.astype(float))
js(A/'verification.json',{'prediction_files_verified':len(checks),'prediction_rows_verified':sum(r['n'] for r in checks),'all_metrics_recomputed':True,'all_ridge_selections_validation_only':True,'neural_best_epochs_match_validation_minima':True,'original_zero_shot_predictions_exact_match':True,'source_overlap_all_grouped_splits':0,'selected_neural_weights_verified':len(weight_checks),'complete':True})
# Readable result artifact with clear scope and limitations.
lines=['ChaLearn source-separated follow-up experiment','', 'Exploratory analysis of frozen CLIP features. Original official-split results are preserved.', 'All 10,000 clips and 3,060 source prefixes were used. Prefixes identify source recordings, not verified people.', 'Five deterministic source-disjoint splits and five random-clip controls matched in partition sizes.', 'FFNN and CNN-LSTM: five training seeds on the first partition only. Other architectures and Qwen were not retrained.', '', 'TEST RESULTS:']
for r in aggregate:lines.append(f"{r['condition']:20s} {r['model']:20s} MAE {r['MAE_mean']:.6f} +/- {r['MAE_sd']:.6f} ({r['repetition_unit']})")
lines+=['','FIRST PARTITION COMPARISON:']
for r in first:lines.append(f"{r['condition']:20s} {r['model']:20s} MAE {r['MAE_mean']:.6f} +/- {r['MAE_sd']:.6f} ({r['n_fits']} fits, {r['test_clips']} test clips)")
lines+=['','PAIRED CONTRASTS ON FIRST SOURCE-DISJOINT TEST (negative favours first method):']
for r in contr:lines.append(f"{r['contrast']}: {r['difference_MAE']:.6f}; adjusted 97.5% cluster interval [{r['CI97_5_lower']:.6f}, {r['CI97_5_upper']:.6f}]")
lines+=['','Interpretation limits: fixed split repetitions overlap and are not independent datasets. Standard deviations are descriptive. Conditions have different test clips; their difference is not a paired or causal estimate of source leakage. Training seeds do not measure population uncertainty. Cluster intervals condition on the fitted models and one partition. All source grouping is unverified with respect to identity. CPU software is shared by new conditions but differs from the original GPU software. No psychological validity or deployment safety is established.']
(A/'RESULTS.txt').write_text('\n'.join(lines)+'\n')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,ax=plt.subplots(1,2,figsize=(11,4.4),layout='constrained')
for ai,models,title in [(ax[0],['training_median','zero_shot_cosine','linear','ridge'],'Five partition repetitions'),(ax[1],['ridge','ffnn','cnn_lstm'],'First partition (neural heads: five seeds)')]:
 for k,condition in enumerate(['clip_random_control','source_disjoint']):
  selected=[next(r for r in (aggregate if ai is ax[0] else first) if r['condition']==condition and r['model']==m) for m in models]
  ai.errorbar(np.arange(len(models))+(k-.5)*.14,[r['MAE_mean'] for r in selected],yerr=[r['MAE_sd'] for r in selected],fmt='o',capsize=4,label=condition.replace('_',' '))
 ai.set_xticks(range(len(models)),[m.replace('_',' ') for m in models],rotation=15);ai.set_title(title);ai.set_ylabel('Test mean absolute error (lower is better)');ai.grid(axis='y',alpha=.2)
ax[0].legend(fontsize=8);fig.suptitle('Source-separated evaluation of frozen CLIP features\nError bars: descriptive sample SD, not confidence intervals',fontsize=12)
fig.savefig(A/'source_separated_results.png',dpi=180);fig.savefig(A/'source_separated_results.pdf');plt.close(fig)
js(O/'status.json',{'phase': 'complete', 'completed_fits': 20, 'total_fits': 20, 'baseline_partition_conditions': 10, 'baseline_prediction_files': 120, 'neural_prediction_files': 40, 'verification_complete': True, 'analysis_directory': 'analysis', 'complete': True})
print('\n'.join(lines));print('VERIFICATION_COMPLETE',len(checks),flush=True)
