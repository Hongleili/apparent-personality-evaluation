"""Freeze source-isolated partitions without consulting labels or model results."""
import csv,hashlib,json,re,datetime
from pathlib import Path
B=Path(__file__).resolve().parent
M=B.parent/'colab_rerun/repeat_seed_manifests'
traits=['openness','conscientiousness','extraversion','agreeableness','neuroticism']
rows=[];hashes={}
for split,n in [('training',6000),('validation',2000),('test',2000)]:
 p=M/(split+'.csv');hashes[split]=hashlib.sha256(p.read_bytes()).hexdigest()
 rr=list(csv.DictReader(p.open()));assert len(rr)==n
 for r in rr:
  m=re.fullmatch(r'(.+)\.(\d+)\.mp4',r['filename']);assert m
  rows.append(dict(r,official_split=split,source_prefix=m[1]))
rows.sort(key=lambda r:r['filename']);assert len({r['filename'] for r in rows})==10000
groups=sorted({r['source_prefix'] for r in rows})
def ordered(items,seed,namespace):
 return sorted(items,key=lambda x:(hashlib.sha256(f'{namespace}:{seed}:{x}'.encode()).hexdigest(),x))
def write(p,rr):
 with p.open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
counts=[]
for seed in range(20261123,20261128):
 g=ordered(groups,seed,'chalearn_source_disjoint_v1')
 n1=int(.6*len(g));n2=int(.2*len(g));assignment={x:s for s,gg in [('training',g[:n1]),('validation',g[n1:n1+n2]),('test',g[n1+n2:])] for x in gg}
 grouped={s:[dict(r,new_split=s) for r in rows if assignment[r['source_prefix']]==s] for s in ['training','validation','test']}
 c1,c2=len(grouped['training']),len(grouped['validation'])
 perm=ordered([r['filename'] for r in rows],seed,'chalearn_clip_control_v1')
 ca={x:s for s,nn in [('training',perm[:c1]),('validation',perm[c1:c1+c2]),('test',perm[c1+c2:])] for x in nn}
 control={s:[dict(r,new_split=s) for r in rows if ca[r['filename']]==s] for s in grouped}
 for condition,data in [('source_disjoint',grouped),('clip_random_control',control)]:
  dest=B/'manifests'/str(seed)/condition;dest.mkdir(parents=True,exist_ok=True)
  sets={s:{r['source_prefix'] for r in rr} for s,rr in data.items()}
  overlaps={f'{a}-{b}':len(sets[a]&sets[b]) for a,b in [('training','validation'),('training','test'),('validation','test')]}
  if condition=='source_disjoint':assert not any(overlaps.values())
  for s,rr in data.items():write(dest/(s+'.csv'),rr)
  counts.append({'partition_seed':seed,'condition':condition,'clips':{s:len(rr) for s,rr in data.items()},'source_groups':{s:len(v) for s,v in sets.items()},'source_overlaps':overlaps})
write(B/'all_labels.csv',rows)
protocol={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'frozen_before_new_model_outcomes','study_type':'exploratory follow-up motivated by completed official-split findings; not prospective preregistration',
 'source_run':'70ac0575bf09bf29','official_manifest_sha256':hashes,'traits':traits,'label_semantics':'neuroticism kept numerically unchanged and interpreted as emotional stability; no label inversion',
 'source_definition':'filename prefix before numeric clip index; proxies for recordings, not verified people',
 'partitions':'SHA256 ordering of namespace:seed:identifier; first floor(0.6*G) groups training, next floor(0.2*G) validation, remainder test. Control randomly orders clips with separate namespace and exactly matches grouped clip counts. Assignment uses identifiers only.',
 'partition_seeds':list(range(20261123,20261128)), 'partition_counts':counts,
 'frozen_features':'Original 10 x 768 per-frame normalized CLIP ViT-L/14 projected features; no encoder training; allow_pickle=False',
 'baselines_all_partitions':['training_mean','training_median','zero_shot_cosine','zero_shot_scaled','linear','ridge'],
 'ridge':'float64 centered SVD; unpenalized intercept; logspace(-6,6,25); common alpha across five traits; select lowest clipped validation MSE; ties smaller alpha; train only fitting',
 'neural_first_partition_only':{'heads':['ffnn','cnn_lstm'],'training_seeds':[42,43,44,45,46],'conditions':['source_disjoint','clip_random_control'],'selection_reason':'Original simple mean-pooled head and lowest official neural MAE; exploratory subset, not all architectures', 'optimizer':'Adam','lr':.001,'batch_size':64,'max_epochs':100,'patience':15,'selection':'Minimum validation MSE; no test selection','architecture':'Exact make_head from original experiment.py','device':'cpu'},
 'reporting':'Macro MAE primary, per-trait MAE and Pearson correlation; 1-MAE also reported. Fixed seeds describe optimizer variability, not sampling uncertainty. Five partition replicates descriptive and dependent. Compare constants to distinguish label-distribution effects. Test sets differ between conditions: no paired clip bootstrap across conditions and no causal claim of leakage magnitude.',
 'uncertainty':'Within first source-disjoint test, 10000 whole-source bootstrap replicates, seed 20261123; paired ridge-minus-training-median and CNN-LSTM-minus-ridge differences; mean per-clip errors across fixed neural seeds; 97.5% marginal intervals for two prespecified contrasts. Conditional on fitted models and this partition.',
 'preservation':'Original data/features/results read-only; all new artifacts in chalearn_source_disjoint; no manuscript change until verification.'}
p=B/'protocol.json'
if p.exists():raise RuntimeError('Protocol already exists; do not overwrite')
p.write_text(json.dumps(protocol,indent=2));(B/'partition_audit.json').write_text(json.dumps(counts,indent=2))
print(json.dumps({'total_clips':len(rows),'total_sources':len(groups),'first_partition':counts[:2]},indent=2))
