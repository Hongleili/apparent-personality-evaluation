from pathlib import Path
import sys,csv,itertools,json,hashlib
import numpy as np
sys.path.insert(0,str(Path('outputs/colab_rerun').resolve()))
import experiment as exp
p=Path('outputs/five_seed_results');out=Path('outputs/paired_uncertainty');out.mkdir(exist_ok=True)
heads=['ffnn','cnn','lstm','gru','bilstm','cnn_lstm'];seeds=[42,43,44,45,46]
names,y=exp.load_manifest('outputs/colab_rerun/repeat_seed_manifests','test');err=[];hashes={}
for seed in seeds:
 ee=[]
 for h in heads:
  f=p/f'seed_{seed}'/f'{h}_test_predictions.csv';rows=list(csv.DictReader(open(f)));assert [r['filename'] for r in rows]==names
  pred=np.array([[float(r[t]) for t in exp.TRAITS] for r in rows]);assert pred.shape==(2000,5)
  ee.append(np.abs(y.astype(float)-pred).mean(axis=1));hashes[str(f)]=hashlib.sha256(f.read_bytes()).hexdigest()
 err.append(ee)
e=np.array(err).transpose(0,2,1);d=e[:,:,:5]-e[:,:,5,None];point=d.mean(axis=(0,1))
# Paired crossed bootstrap: independently resample training seeds and test clips;
# identical draws across heads and keep all five traits together within each clip.
B=20000;rng=np.random.default_rng(20261103);boot=np.empty((B,5))
for start in range(0,B,100):
 n=min(100,B-start);w=rng.multinomial(5,[.2]*5,size=n)/5
 weighted=np.einsum('bs,snc->bnc',w,d)
 idx=rng.integers(0,len(names),size=(n,len(names)))
 boot[start:start+n]=weighted[np.arange(n)[:,None],idx].mean(axis=1)
seedmeans=d.mean(axis=1);signs=np.array(list(itertools.product([-1,1],repeat=5)))
pvals=np.mean(np.abs(signs@seedmeans/5)>=np.abs(point)[None,:]-1e-15,axis=0)
order=np.argsort(pvals);adjust=np.empty(5);adjust[order]=np.minimum(1,np.maximum.accumulate(pvals[order]*(5-np.arange(5))))
rows=[]
for i,h in enumerate(heads[:-1]):
 q=np.quantile(boot[:,i],[.005,.025,.975,.995]);rows.append({'comparator':h,'delta_MAE_comparator_minus_cnn_lstm':point[i],'ci95_low':q[1],'ci95_high':q[2],'ci99_low':q[0],'ci99_high':q[3],'exact_seed_signflip_p':pvals[i],'holm_p':adjust[i],'seed_differences':seedmeans[:,i].tolist()})
exp.write_csv(out/'paired_mae_comparisons.csv',rows)
meta={'seeds':seeds,'test_clips':2000,'traits':exp.TRAITS,'replicates':B,'rng_seed':20261103,'primary_metric':'macro MAE','difference':'comparator minus CNN-LSTM; positive favours CNN-LSTM','interval':'percentile crossed bootstrap, paired over heads; independent resampling of five seeds and 2000 clips','multiplicity':'99% marginal intervals correspond to Bonferroni 95% family coverage for five comparisons, subject to bootstrap assumptions; exact seed sign-flip tests Holm adjusted','limitations':['Post-hoc exploratory comparison: CNN-LSTM chosen after observed test ranking','Only five training seeds; bootstrap approximations fragile','Clip independence assumed; no source-video/person clustering available','Exact two-sided paired seed sign-flip test assumes exchangeability under null; with five seeds smallest attainable p=0.0625','SD is variation across seeds, not CI'],'prediction_sha256':hashes,'results':rows}
(out/'analysis.json').write_text(json.dumps(meta,indent=2));np.savez_compressed(out/'bootstrap_differences.npz',differences=boot)
for r in rows:print(r)
