from pathlib import Path
import csv,json,hashlib,re,collections
import numpy as np
R=Path(__file__).parent;D=R/'results';traits=['openness','conscientiousness','extraversion','agreeableness','neuroticism']
read=lambda p:list(csv.DictReader(p.open()))
labels=read(R.parent/'colab_rerun/repeat_seed_manifests/validation.csv')[:20];rr=read(D/'validation_predictions.csv');assert [r['filename'] for r in rr]==[r['filename'] for r in labels]
y=np.array([[float(r[t]) for t in traits] for r in labels],dtype=np.float32).astype(float);p=np.array([[float(r[t]) for t in traits] for r in rr]);assert ((p>=0)&(p<=1)).all()
hashes=json.loads((R/'pilot_video_hashes.json').read_text())
for i,r in enumerate(rr):
 rec=json.loads((D/('validation_'+r['filename']+'.json')).read_text());assert rec['video_sha256']==hashes[r['filename']]
 raw=re.sub(r'^```(?:json)?\s*','',rec['raw'].strip());raw=re.sub(r'\s*```$','',raw);parsed=json.loads(raw);assert set(parsed)==set(traits)
 assert all(parsed[t]==rec['predictions'][t]==p[i,j] for j,t in enumerate(traits))
 assert len(rec['frame_indices'])==10 and (np.diff(rec['frame_indices'])>0).all()
saved=read(D/'validation_metrics.csv');metrics=[]
for j,t in enumerate(traits):
 a=y[:,j];b=p[:,j];pos=a>=.5;pred=b>=.5;tp=int((pos&pred).sum());tn=int((~pos&~pred).sum());fp=int((~pos&pred).sum());fn=int((pos&~pred).sum());mae=abs(a-b).mean()
 v=dict(trait=t,n=20,MAE=float(mae),PCC=float(np.corrcoef(a,b)[0,1]),ACC=float(1-mae),FPR_percent=100*fp/(fp+tn),FNR_percent=100*fn/(fn+tp),TP=tp,TN=tn,FP=fp,FN=fn)
 for k in v:
  if k=='trait':assert saved[j][k]==t
  else:assert abs(v[k]-float(saved[j][k]))<1e-10
 metrics.append(v)
counts=collections.Counter(tuple(x) for x in p)
result=dict(validated_responses=20,full_split=False,macro_MAE=float(abs(p-y).mean()),macro_PCC=float(np.mean([m['PCC'] for m in metrics])),unique_score_vectors=len(counts),most_common_vector_count=counts.most_common(1)[0][1],metrics=metrics,note='Convenience pilot: first 20 validation filenames; not representative, not a test-set result. No score inversion or prompt selection based on these scores.')
(R/'verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
status=json.loads((R/'status.json').read_text());status.update(status='Pilot complete and independently verified; full evaluation not started',valid_responses=20);(R/'status.json').write_text(json.dumps(status,indent=2))
