from pathlib import Path
import json, numpy as np,re
R=Path(__file__).parent;D=R/'diagnostics_results';cfg=json.loads((D/'config.json').read_text());names=cfg['names'];traits=['openness','conscientiousness','extraversion','agreeableness','emotional_stability'];oldtraits=traits[:-1]+['neuroticism'];data={};coverage={}
for kind in ['original_real','original_blank','clear_real','clear_blank']:
 records=[];values=[]
 for name in names:
  p=R/'results'/('validation_'+name+'.json') if kind=='original_real' else D/(kind+'_'+name+'.json')
  rec=json.loads(p.read_text());records.append(rec)
  if 'predictions' in rec:
   raw=re.sub(r'^```(?:json)?\s*','',rec['raw'].strip());raw=re.sub(r'\s*```$','',raw);parsed=json.loads(raw);assert parsed==rec['predictions']
   ts=oldtraits if kind.startswith('original') else traits
   assert set(parsed)==set(ts);values.append([parsed[t] for t in ts])
  else:values.append([float('nan')]*5)
 data[kind]=np.array(values);coverage[kind]=int(np.isfinite(data[kind]).all(1).sum())
comparisons={}
for a,b in [('original_real','original_blank'),('clear_real','clear_blank'),('original_real','clear_real')]:
 ok=np.isfinite(data[a]).all(1)&np.isfinite(data[b]).all(1);diff=data[a][ok]-data[b][ok]
 comparisons[a+' versus '+b]={'valid_pairs':int(ok.sum()),'identical_vectors':int((diff==0).all(1).sum()),'mean_absolute_score_change':float(np.abs(diff).mean()) if len(diff) else None,'per_trait_mean_absolute_change':dict(zip(traits,np.abs(diff).mean(0).tolist())) if len(diff) else None}
# The clear condition's token input and geometry must be identical for real/blank controls; pixel tensors must differ.
for name in names:
 a=json.loads((D/('clear_real_'+name+'.json')).read_text());b=json.loads((D/('clear_blank_'+name+'.json')).read_text())
 assert a['input_ids_sha256']==b['input_ids_sha256'] and a['image_grid_thw']==b['image_grid_thw'] and a['pixels_sha256']!=b['pixels_sha256']
summary={'coverage':coverage,'comparisons':comparisons,'descriptions':{p.stem:json.loads(p.read_text())['raw'] for p in D.glob('description*.json')},'limitations':'Eight convenience-selected validation clips. Blank images are out of distribution. Score changes establish input/wording sensitivity, not correct visual grounding or personality validity. No test-set inference or prompt selection by label performance.'}
(R/'diagnostics_summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
