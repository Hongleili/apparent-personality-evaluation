from pathlib import Path
import json,hashlib,re,time,csv,os,importlib.metadata
import numpy as np
import torch
from PIL import Image
from transformers import AutoProcessor,Qwen2_5_VLForConditionalGeneration
from experiment_qwen import sample_frames
root=Path('/content/qwen_pilot'); source=Path('/content/drive/MyDrive/chalearn_qwen_results/qwen_2d7f97a4482feba5');out=source.parent/'qwen_diagnostics_v1';out.mkdir(exist_ok=True)
base=json.loads((source/'config.json').read_text());assert torch.cuda.is_available()
names=[r['filename'] for r in csv.DictReader((root/'data/validation.csv').open())][:8]
keys=['openness','conscientiousness','extraversion','agreeableness','emotional_stability']
clear=('These are ten chronological frames from one video. Estimate the apparent first-impression scores that observers might assign, rather than actual personality or a clinical assessment. Use only these images. Each score must be a number from 0 to 1. The emotional_stability score means 0 for an anxious, easily upset impression and 1 for a calm, emotionally stable impression. Return only a JSON object with these five numeric keys: '+', '.join(keys)+'.')
config={'source':str(source),'model':base['model'],'revision':base['revision'],'names':names,'selection':'First eight pilot manifest filenames, fixed before diagnostics','original_prompt':base['prompt'],'clear_prompt':clear,'controls':'Real frames versus constant RGB(127,127,127) images of the exact same dimensions; same 10 positions','generation':{'do_sample':False,'max_new_tokens':200},'processor':'fast=True, same min/max pixels as pilot','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'purpose':'Exploratory input-sensitivity and wording diagnostics; not prompt optimization against labels; no test data'}
def save(p,v):
 tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(v,indent=2));os.replace(tmp,p)
if (out/'config.json').exists():assert json.loads((out/'config.json').read_text())==config
else:save(out/'config.json',config)
torch.manual_seed(42)
model=Qwen2_5_VLForConditionalGeneration.from_pretrained(base['model'],revision=base['revision'],torch_dtype=torch.float16,device_map='auto',attn_implementation='sdpa').eval()
processor=AutoProcessor.from_pretrained(base['model'],revision=base['revision'],use_fast=True,min_pixels=base['min_pixels'],max_pixels=base['max_pixels'])
def infer(frames,prompt):
 messages=[{'role':'user','content':[{'type':'image'} for _ in frames]+[{'type':'text','text':prompt}]}]
 text=processor.apply_chat_template(messages,tokenize=False,add_generation_prompt=True)
 inputs=processor(text=[text],images=frames,return_tensors='pt',padding=True).to(model.device)
 assert inputs['image_grid_thw'].shape[0]==10
 with torch.inference_mode():tokens=model.generate(**inputs,max_new_tokens=200,do_sample=False)
 raw=processor.batch_decode(tokens[:,inputs['input_ids'].shape[1]:],skip_special_tokens=True)[0]
 return {'raw':raw,'input_ids_sha256':hashlib.sha256(inputs['input_ids'].cpu().numpy().tobytes()).hexdigest(),'pixels_sha256':hashlib.sha256(inputs['pixel_values'].float().cpu().numpy().tobytes()).hexdigest(),'image_grid_thw':inputs['image_grid_thw'].cpu().tolist()}
for i,name in enumerate(names):
 video=root/'data/validation'/name;old=json.loads((source/('validation_'+name+'.json')).read_text());assert hashlib.sha256(video.read_bytes()).hexdigest()==old['video_sha256']
 frames,indices=sample_frames(video,10);assert indices==old['frame_indices'];blank=[Image.new('RGB',f.size,(127,127,127)) for f in frames]
 for condition,imgs,prompt,expected in [('original_blank',blank,base['prompt'],list(old['predictions'])),('clear_real',frames,clear,keys),('clear_blank',blank,clear,keys)]:
  dest=out/(condition+'_'+name+'.json')
  if dest.exists():continue
  record=infer(imgs,prompt);record.update(filename=name,condition=condition,frame_indices=indices,frame_sizes=[f.size for f in frames],video_sha256=old['video_sha256'])
  try:
   text=re.sub(r'^```(?:json)?\s*','',record['raw'].strip());text=re.sub(r'\s*```$','',text);p=json.loads(text)
   assert set(p)==set(expected) and all(type(v) in (int,float) and 0<=v<=1 for v in p.values())
   record['predictions']=p
  except Exception as e:record['parse_error']=repr(e)
  save(dest,record);print('DIAGNOSTIC',i+1,'/8',condition,'valid', 'predictions' in record,flush=True)
# Visible-content descriptions are a separate input-path sanity check, not personality judgments.
for index in [0,2]:
 name=names[index];frames,_=sample_frames(root/'data/validation'/name,10)
 for condition,imgs in [('real',frames),('blank',[Image.new('RGB',f.size,(127,127,127)) for f in frames])]:
  dest=out/f'description_{index}_{condition}.json'
  if not dest.exists():save(dest,infer(imgs,'Describe only directly visible clothing and background in these images. Do not infer personality, identity, age, ethnicity or mental state. If there is no visible scene, state that clearly.'))
  print('DESCRIPTION',index,condition,flush=True)
save(out/'COMPLETE.json',{'clips':8,'new_score_responses':24,'description_checks':4});print('DIAGNOSTICS COMPLETE',out,flush=True)
