"""Five fixed seeds on the original frozen CLIP features; epoch-resumable heads."""
from pathlib import Path
import json, csv, copy, random, os, hashlib, time
from concurrent.futures import ThreadPoolExecutor
import numpy as np
import torch
from torch.utils.data import DataLoader, TensorDataset
import experiment as exp
from chalearn_data import EXPECTED, TRAITS, atomic_json, sha256

SEEDS=[42,43,44,45,46]

def save_pt(path,value):
    tmp=path.with_suffix('.tmp');torch.save(value,tmp);os.replace(tmp,path)

def rng_state():
    n=np.random.get_state()
    return {'python':random.getstate(),'numpy':[n[0],n[1].tolist(),n[2],n[3],n[4]],'cpu':torch.get_rng_state(),'cuda':[]}

def restore_rng(r):
    random.setstate(r['python']);n=r['numpy'];np.random.set_state((n[0],np.array(n[1],dtype=np.uint32),n[2],n[3],n[4]))
    torch.set_rng_state(r['cpu'])

def main(dataset,source):
    dataset,source=Path(dataset),Path(source)
    device='cpu'
    torch.set_num_threads(2)
    saved=json.loads((source/'provenance.json').read_text());cfg=saved['config']
    assert {k:v.split('+')[0] for k,v in exp.versions().items()}=={k:v.split('+')[0] for k,v in saved['versions'].items()},f'Software mismatch: {exp.versions()} vs {saved["versions"]}'
    assert sha256(exp.__file__)==saved['script_sha256'],'Original experiment source mismatch'
    assert sha256(Path(exp.__file__).with_name('chalearn_data.py'))==saved['data_script_sha256']
    assert hashlib.sha256(json.dumps(saved,sort_keys=True).encode()).hexdigest()[:16]==source.name
    for split in EXPECTED: assert sha256(dataset/f'{split}.csv')==saved['annotation_csv_sha256'][split],split
    out=source.parent/(source.name+'_frame_ablation_cpu_v1');out.mkdir(exist_ok=True)
    protocol={'source_run':source.name,'seeds':SEEDS,'config':cfg,'versions':exp.versions(),'runner_sha256':sha256(__file__),
      'selection':'Per-head minimum validation MSE, no test-based selection','conditions':['ordered','shuffled','mean_repeated'],'device':device,'seed42':'All five seeds newly trained on matched CPU','shuffle':'Fixed SHA256 filename-keyed permutation; identical for all training seeds','mean':'Arithmetic mean repeated 10 times without renormalization','interpretation':'Exploratory; CNN-LSTM chosen after earlier results. Mean repetition removes both variation and order.',
      'resume':'Full optimizer, RNG, data-loader generator and model state saved each epoch'}
    if (out/'protocol.json').exists(): assert json.loads((out/'protocol.json').read_text())==protocol,'Protocol mismatch'
    else: atomic_json(out/'protocol.json',protocol)
    data={}
    for split in EXPECTED:
        names,y=exp.load_manifest(dataset,split)
        assert {p.name for p in (source/'features'/split).glob('*.npz')}=={n+'.npz' for n in names},'Feature coverage mismatch'
        def read(n):
            with np.load(source/'features'/split/(n+'.npz'),allow_pickle=False) as z:
                x=z['features'].copy();ix=z['frame_indices'];assert x.shape==(cfg['frames'],saved['feature_dimension']) and x.dtype==np.float32
                assert np.isfinite(x).all() and np.allclose(np.linalg.norm(x,axis=1),1,atol=1e-4)
                assert ix.shape==(cfg['frames'],) and (np.diff(ix)>0).all()
                assert len(str(z['video_sha256'].item()))==64
                return x
        print('Validating cached features:',split,len(names),flush=True)
        with ThreadPoolExecutor(max_workers=4) as pool:
            xx=[]
            for i,x in enumerate(pool.map(read,names)):
                xx.append(x)
                if (i+1)%500==0:print(split,i+1,'/',len(names),flush=True)
        data[split]=(names,y,np.stack(xx));del xx
    assert all(not(set(data[a][0])&set(data[b][0])) for i,a in enumerate(EXPECTED) for b in list(EXPECTED)[i+1:])
    _,yt,xt=data['training'];xv=torch.from_numpy(data['validation'][2]).to(device);yv=torch.from_numpy(data['validation'][1]).to(device)
    # Validate original seed-42 metrics against saved predictions, keeping all source artifacts read-only.
    summaries=[]
    def report(seed,kind,split,pred,dest=None):
        names,y,_=data[split];rows=exp.metrics(y,pred)
        if dest:
            exp.write_csv(dest/f'{kind}_{split}_metrics.csv',rows)
            exp.write_csv(dest/f'{kind}_{split}_predictions.csv',[{'filename':n,**{t:float(pred[i,j]) for j,t in enumerate(TRAITS)}} for i,n in enumerate(names)])
        mean={k:float(np.mean([r[k] for r in rows])) for k in ['MAE','PCC','ACC','FPR_percent','FNR_percent']}
        summaries.append({'seed':seed,'head':kind,'split':split,**mean})
        return rows
    for seed in SEEDS:
        dest=out/f'seed_{seed}';dest.mkdir(exist_ok=True)
        for kind in ['ordered','shuffled','mean_repeated']:
            transformed={}
            for split,(names,y,x) in data.items():
                if kind=='ordered': xx=x
                elif kind=='mean_repeated': xx=np.repeat(x.mean(axis=1,keepdims=True),cfg['frames'],axis=1)
                else:
                    perms=np.array([np.random.default_rng(int.from_bytes(hashlib.sha256(('frame_ablation_v1:'+n).encode()).digest()[:8],'big')).permutation(cfg['frames']) for n in names])
                    xx=np.take_along_axis(x,perms[:,:,None],axis=1)
                    assert np.allclose(xx.mean(1),x.mean(1),atol=1e-6)
                    atomic_json(out/f'{split}_permutations.json',dict(zip(names,perms.tolist())))
                transformed[split]=xx
            xt=transformed['training'];xv=torch.from_numpy(transformed['validation']).to(device)
            done=dest/f'{kind}_complete.json'
            if done.exists():
                record=json.loads(done.read_text())
                assert record['seed']==seed and record['runner_sha256']==protocol['runner_sha256']
                for split in ('validation','test'):
                    rows=list(csv.DictReader(open(dest/f'{kind}_{split}_predictions.csv')))
                    assert [r['filename'] for r in rows]==data[split][0]
                    report(seed,kind,split,np.array([[float(r[t]) for t in TRAITS] for r in rows]))
                print('Already complete',seed,kind,flush=True);continue
            exp.seed_all(seed);head=exp.make_head('cnn_lstm',xt.shape[-1]).to(device);gen=torch.Generator().manual_seed(seed)
            loader=DataLoader(TensorDataset(torch.from_numpy(xt),torch.from_numpy(yt)),batch_size=cfg['batch_size'],shuffle=True,generator=gen)
            opt=torch.optim.Adam(head.parameters(),lr=cfg['lr']);lossfn=torch.nn.MSELoss()
            best=float('inf');beststate=None;bestepoch=0;bad=0;history=[];start=0;last=dest/f'{kind}_last.pt'
            if last.exists():
                ck=torch.load(last,map_location='cpu',weights_only=True)
                assert ck['seed']==seed and ck['kind']==kind and ck['runner_sha256']==protocol['runner_sha256']
                head.load_state_dict(ck['model']);opt.load_state_dict(ck['optimizer']);gen.set_state(ck['generator']);restore_rng(ck['rng'])
                start=ck['epoch'];best=ck['best'];beststate=ck['beststate'];bestepoch=ck['bestepoch'];bad=ck['bad'];history=ck['history']
                print('RESUME',seed,kind,'after epoch',start,flush=True)
            for epoch in range(start,cfg['epochs']):
                if bad>=cfg['patience']:break
                head.train();total=0
                for x,y in loader:
                    x,y=x.to(device),y.to(device);opt.zero_grad();loss=lossfn(head(x),y);loss.backward();opt.step();total+=loss.item()*len(x)
                head.eval()
                with torch.inference_mode():vl=lossfn(head(xv),yv).item()
                assert np.isfinite(vl)
                history.append({'epoch':epoch+1,'training_mse':total/len(xt),'validation_mse':vl})
                if vl<best:
                    best=vl;bad=0;beststate={k:v.detach().cpu().clone() for k,v in head.state_dict().items()};bestepoch=epoch+1
                    save_pt(dest/f'{kind}_best.pt',{'state_dict':beststate,'epoch':bestepoch,'validation_mse':best})
                else:bad+=1
                save_pt(last,{'seed':seed,'kind':kind,'runner_sha256':protocol['runner_sha256'],'epoch':epoch+1,'model':head.state_dict(),'optimizer':opt.state_dict(),'generator':gen.get_state(),'rng':rng_state(),'best':best,'beststate':beststate,'bestepoch':bestepoch,'bad':bad,'history':history})
                atomic_json(out/'progress.json',{'seed':seed,'head':kind,'epoch':epoch+1,'validation_mse':vl,'best_epoch':bestepoch,'completed_seed_head_pairs':len(summaries)//2,'total':15})
                print('seed',seed,kind,'epoch',epoch+1,'val MSE',round(vl,7),'best epoch',bestepoch,flush=True)
            head.load_state_dict(beststate);head.eval()
            for split in ('validation','test'):
                with torch.inference_mode():pred=head(torch.from_numpy(transformed[split]).to(device)).cpu().numpy()
                report(seed,kind,split,pred,dest)
            exp.write_csv(dest/f'{kind}_history.csv',history)
            atomic_json(done,{'seed':seed,'best_epoch':bestepoch,'validation_mse':best,'runner_sha256':protocol['runner_sha256']})
            exp.write_csv(out/'per_seed_macro_metrics.csv',summaries)
            del head,opt;torch.cuda.empty_cache()
    aggregate=[]
    for kind in ['ordered','shuffled','mean_repeated']:
        for split in ('validation','test'):
            rr=[r for r in summaries if r['head']==kind and r['split']==split];assert len(rr)==5
            row={'head':kind,'split':split,'n_seeds':5}
            for k in ['MAE','PCC','ACC','FPR_percent','FNR_percent']:
                vals=[r[k] for r in rr];row[k+'_mean']=float(np.mean(vals));row[k+'_sd']=float(np.std(vals,ddof=1))
            aggregate.append(row)
    exp.write_csv(out/'five_seed_summary.csv',aggregate)
    atomic_json(out/'COMPLETE.json',{'seeds':SEEDS,'conditions':['ordered','shuffled','mean_repeated'],'source_run':source.name,'completed_seed_head_pairs':15,'note':'SD describes variation across training seeds; not a confidence interval over test samples.'})
    print('ALL FRAME ABLATIONS COMPLETE:',out,flush=True)
    return str(out)
