from pathlib import Path
import csv,json,hashlib,itertools
import numpy as np
R=Path(__file__).parent;D=R/'results';M=R.parent/'colab_rerun/repeat_seed_manifests'
def rows(p):return list(csv.DictReader(p.open()))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
traits=['openness','conscientiousness','extraversion','agreeableness','neuroticism'];kinds=['ordered','shuffled','mean_repeated'];keys=['MAE','PCC','ACC','FPR_percent','FNR_percent']
protocol=json.loads((D/'protocol.json').read_text());assert protocol['runner_sha256']==sha(R/'run_ablation.py')
assert json.loads((D/'COMPLETE.json').read_text())['completed_seed_head_pairs']==15
allmetrics={};errors={};count=0
for split,n in [('training',6000),('validation',2000),('test',2000)]:
 labels=rows(M/f'{split}.csv');names=[r['filename'] for r in labels];assert len(names)==len(set(names))==n
 perm=json.loads((D/f'{split}_permutations.json').read_text());assert set(perm)==set(names)
 for name in names:
  expected=np.random.default_rng(int.from_bytes(hashlib.sha256(('frame_ablation_v1:'+name).encode()).digest()[:8],'big')).permutation(10).tolist();assert perm[name]==expected
 if split=='training':continue
 y=np.array([[float(r[t]) for t in traits] for r in labels],dtype=np.float32).astype(float)
 for seed in range(42,47):
  for kind in kinds:
   root=D/f'seed_{seed}';done=json.loads((root/f'{kind}_complete.json').read_text());assert done['seed']==seed and done['runner_sha256']==protocol['runner_sha256']
   hist=rows(root/f'{kind}_history.csv');best=min(hist,key=lambda r:float(r['validation_mse']));assert int(best['epoch'])==done['best_epoch'] and float(best['validation_mse'])==done['validation_mse']
   rr=rows(root/f'{kind}_{split}_predictions.csv');assert [r['filename'] for r in rr]==names
   p=np.array([[float(r[t]) for t in traits] for r in rr]);assert p.shape==y.shape and np.isfinite(p).all() and ((p>=0)&(p<=1)).all();count+=n
   saved=rows(root/f'{kind}_{split}_metrics.csv');values=[]
   for j,t in enumerate(traits):
    a=y[:,j];b=p[:,j];pos=a>=.5;pred=b>=.5;tp=int((pos&pred).sum());tn=int((~pos&~pred).sum());fp=int((~pos&pred).sum());fn=int((pos&~pred).sum());mae=np.abs(a-b).mean()
    v=dict(MAE=mae,PCC=np.corrcoef(a,b)[0,1],ACC=1-mae,FPR_percent=100*fp/(fp+tn),FNR_percent=100*fn/(fn+tp),TP=tp,TN=tn,FP=fp,FN=fn)
    assert saved[j]['trait']==t and int(saved[j]['n'])==n
    for key,value in v.items():assert abs(value-float(saved[j][key]))<1e-10,(seed,kind,split,key)
    values.append(v)
   allmetrics[seed,kind,split]={k:float(np.mean([v[k] for v in values])) for k in keys};errors[seed,kind,split]=np.abs(p-y).mean(1)
for r in rows(D/'per_seed_macro_metrics.csv'):
 for k in keys:assert abs(float(r[k])-allmetrics[int(r['seed']),r['head'],r['split']][k])<1e-10
summary=[]
for r in rows(D/'five_seed_summary.csv'):
 for k in keys:
  a=[allmetrics[s,r['head'],r['split']][k] for s in range(42,47)]
  assert abs(np.mean(a)-float(r[k+'_mean']))<1e-10 and abs(np.std(a,ddof=1)-float(r[k+'_sd']))<1e-10
 if r['split']=='test':summary.append(r)
comparisons=[]
for kind in kinds[1:]:
 delta=np.array([allmetrics[s,kind,'test']['MAE']-allmetrics[s,'ordered','test']['MAE'] for s in range(42,47)])
 null=np.array([np.mean(delta*np.array(sign)) for sign in itertools.product([-1,1],repeat=5)])
 comparisons.append(dict(comparison=kind+' minus ordered',mean_MAE_difference=float(delta.mean()),paired_seed_differences=delta.tolist(),two_sided_exact_signflip_p=float(np.mean(np.abs(null)>=abs(delta.mean())-1e-15))))
pvals=[c['two_sided_exact_signflip_p'] for c in comparisons];order=np.argsort(pvals);adj=0
for rank,idx in enumerate(order):adj=max(adj,min(1,(2-rank)*pvals[idx]));comparisons[idx]['Holm_p']=adj
result=dict(verified_prediction_rows=count,verified_trait_metric_rows=150,completed_runs=15,test_summary=summary,paired_comparisons=comparisons,files_sha256={str(p.relative_to(D)):sha(p) for p in D.rglob('*') if p.is_file()})
(R/'verification.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='files_sha256'},indent=2))
