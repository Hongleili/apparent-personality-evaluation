"""Freeze the second-encoder experiment before extracting/scoring its features."""
from pathlib import Path
import json,hashlib,platform,datetime
import numpy as np
import torch
B=Path(__file__).resolve().parent; P=B.parent/'chalearn_source_disjoint'; C=B.parent/'chalearn_source_replication'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
 return h.hexdigest()
if (B/'protocol.json').exists(): raise SystemExit('Protocol already frozen; do not replace it.')
inventory={str(f.relative_to(B.parent)):sha(f) for root in [P,C] for f in root.rglob('*') if f.is_file() and '__pycache__' not in str(f)}
(B/'parent_inventory.json').write_text(json.dumps(inventory,indent=2))
with np.load(P/'cache_bundle.npz',allow_pickle=False) as z:
 np.savez_compressed(B/'frame_reference.npz',**{k:z[k] for k in ['names','official_splits','frame_indices','video_sha256']})
cfg={
 'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'status':'frozen_before_siglip_features_and_outcomes',
 'target_journal':'IEEE Transactions on Affective Computing',
 'study_type':'Exploratory second-encoder extension motivated by already observed CLIP findings; no preregistration claim.',
 'question':'Does the ordering of ridge, FFNN and CNN-LSTM under source-separated versus size-matched random-clip partitions extend to another frozen vision-language encoder family?',
 'encoder':json.loads((B/'model_identity.json').read_text()),
 'feature_definition':'Official SigLIP 2 Base/16 224 vision tower pooler_output (learned attention pooling), L2 normalized per frame; 10 x 768 float32 per clip; no encoder fine-tuning.',
 'inference':{'device':'mps','dtype':'float32','attention':'sdpa','batch_clips':8,'decoder_workers':4,'image_processor':'Official checkpoint SiglipImageProcessor, use_fast=False; native resize/normalization, no extra face crop.', 'remote_code':False},
 'frames':'Exact original CLIP per-video frame indices; same SHA256 video bytes; same OpenCV FFmpeg sequential grab/retrieve RGB algorithm. Decoder/software recorded; not claiming bitwise cross-platform pixel equivalence.',
 'frame_reference_sha256':sha(B/'frame_reference.npz'),
 'clip_bundle_sha256':sha(P/'cache_bundle.npz'),
 'parent_inventory_sha256':sha(B/'parent_inventory.json'),
 'all_labels_sha256':sha(P/'all_labels.csv'),
 'architecture_sha256':sha(B.parent/'colab_rerun/experiment.py'),
 'data_module_sha256':sha(B.parent/'colab_rerun/chalearn_data.py'),
 'partition_seeds':[20261123,20261124,20261125,20261126,20261127],
 'conditions':['source_disjoint','clip_random_control'],
 'manifests':'Reuse all 30 original manifest files unchanged; 3060 source-prefix recording proxies, not verified identities; 1836/612/612 sources in grouped splits, zero grouped overlap.',
 'training_software':{'python':platform.python_version(),'numpy':np.__version__,'torch':str(torch.__version__)},
 'training_device':'cpu','threads_per_worker':2,'max_parallel_training_workers':4,
 'neural':{'heads':['ffnn','cnn_lstm'],'training_seeds':[42,43,44,45,46],'optimizer':'Adam','lr':0.001,'batch_size':64,'max_epochs':100,'patience':15,'selection':'Minimum validation MSE; test never used for tuning','architecture':'Exact original make_head; 768 inputs; no new architecture or hyperparameter search.'},
 'n_neural_fits':100,
 'baselines':['training_mean','training_median','linear','ridge'],
 'ridge':'Same float64 centered SVD; unpenalized intercept; logspace(-6,6,25); lowest clipped validation MSE; ties smaller alpha; train-only fitting.',
 'traits':['openness','conscientiousness','extraversion','agreeableness','neuroticism'],
 'label_semantics':'Raw neuroticism field unchanged and interpreted as emotional stability, as in CLIP study.',
 'reporting':'All partitions and seeds irrespective of direction. Primary macro test MAE, per-trait MAE/PCC; partition means over five training seeds, sample SD across five dependent partition means; within-partition optimizer SD separate. No 25-independent-fit inference. Conditions contain different test clips, so source-minus-control is descriptive, not paired or causal.',
 'uncertainty':'Prespecified new family of ten SigLIP contrasts: ridge-minus-training-median and CNN-LSTM five-fit mean absolute error minus ridge on each grouped test. Resample 612 whole sources 10000 times, clip weighted, seed equal to partition seed; report ordinary 95% and Bonferroni 99.5% marginal intervals. Conditional on fixed fitted models. Original CLIP family remains separately identified; no new joint 20-contrast family or cross-encoder significance claim.',
 'interpretation':'Supports or limits generality of evaluation-dependent rankings; does not isolate architecture/pretraining effects. No claim of state-of-the-art, verified identity separation, causal leakage magnitude, or known pretraining independence.',
 'preservation':'All original data, CLIP results and existing manuscript read-only. New evidence must pass saved-prediction and checkpoint verification before manuscript integration.'
}
(B/'protocol.json').write_text(json.dumps(cfg,indent=2,allow_nan=False))
print('FROZEN',sha(B/'protocol.json'),'PARENT_FILES',len(inventory),flush=True)
