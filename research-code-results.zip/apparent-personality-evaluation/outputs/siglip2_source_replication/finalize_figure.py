"""Publication layout from verified values; no metric or statistical changes."""
from pathlib import Path
import csv,json,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
B=Path(__file__).resolve().parent;A=B/'analysis'
assert json.loads((B/'COMPLETE.json').read_text())['complete']
rows=list(csv.DictReader((A/'cross_encoder_by_partition.csv').open()))
seeds=json.loads((B/'protocol.json').read_text())['partition_seeds']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9})
fig,axes=plt.subplots(1,2,figsize=(7.2,3.25))
fig.subplots_adjust(left=.125,right=.985,bottom=.16,top=.72,wspace=.28)
colors={'ffnn':'#b07123','cnn_lstm':'#6c4b8e'}
for ax,encoder in zip(axes,['CLIP ViT-L/14','SigLIP 2 B/16']):
 def get(seed,cond,model):return next(r for r in rows if int(r['partition_seed'])==seed and r['condition']==cond and r['model']==model and r['encoder']==encoder)
 for cond,marker in [('clip_random_control','o'),('source_disjoint','D')]:
  for model in ['ffnn','cnn_lstm']:
   rr=[get(s,cond,model) for s in seeds]
   diff=[float(r['MAE_mean'])-float(get(int(r['partition_seed']),cond,'ridge')['MAE_mean']) for r in rr]
   offset={('clip_random_control','ffnn'):-.21,('clip_random_control','cnn_lstm'):-.07,('source_disjoint','ffnn'):.07,('source_disjoint','cnn_lstm'):.21}[(cond,model)]
   ax.errorbar(np.arange(1,6)+offset,diff,yerr=[float(r['MAE_seed_sd']) for r in rr],fmt=marker,linestyle='none',capsize=2,color=colors[model],markerfacecolor='white' if cond=='clip_random_control' else colors[model])
 ax.axhline(0,color='#333333',linewidth=.8);ax.set_xticks(range(1,6));ax.set_xlabel('Partition repetition');ax.set_title(encoder,fontsize=10);ax.grid(axis='y',alpha=.2)
axes[0].set_ylabel('Neural MAE minus ridge MAE')
lo=min(ax.get_ylim()[0] for ax in axes);hi=max(ax.get_ylim()[1] for ax in axes)
for ax in axes:ax.set_ylim(lo,hi)
handles=[Line2D([0],[0],color=colors[m],lw=2,label=l) for m,l in [('ffnn','FFNN'),('cnn_lstm','CNN–LSTM')]]+[Line2D([0],[0],color='#444444',marker='o',markerfacecolor='white',linestyle='none',label='Random-clip'),Line2D([0],[0],color='#444444',marker='D',linestyle='none',label='Source-separated')]
fig.legend(handles=handles,fontsize=8,loc='upper center',bbox_to_anchor=(.54,.885),ncol=4,frameon=False,columnspacing=1.3)
fig.text(.54,.985,'Matched encoders: positive differences favour ridge',ha='center',va='top',fontsize=9)
fig.text(.54,.935,'Points: five-fit mean error; bars: training-seed SD, not confidence intervals',ha='center',va='top',fontsize=8)
fig.savefig(A/'cross_encoder_results.pdf');fig.savefig(A/'cross_encoder_results.png',dpi=180);plt.close(fig)
(A/'figure_provenance.json').write_text(json.dumps({'source':'cross_encoder_by_partition.csv','source_sha256':hashlib.sha256((A/'cross_encoder_by_partition.csv').read_bytes()).hexdigest(),'renderer':'finalize_figure.py','renderer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'legend_outside_data_axes':True,'no_statistical_changes':True},indent=2))
