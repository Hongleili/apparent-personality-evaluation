"""Stage read-only ChaLearn archives into a separate local experiment directory."""
from pathlib import Path
import sys, getpass, json, csv, time, os
import numpy as np
B = Path(__file__).resolve().parent
sys.path.insert(0, str(B.parent / 'colab_rerun'))
import chalearn_data as data
root = Path(os.environ['CHALEARN_SOURCE_DIR'])
dest = B / 'media'
report = data.stage_dataset(root, dest, password_provider=getpass.getpass)
with np.load(B.parent / 'chalearn_source_disjoint/cache_bundle.npz', allow_pickle=False) as z:
    names=z['names'].copy(); splits=z['official_splits'].copy(); hashes=z['video_sha256'].copy()
verified=[]
for i,(name,split,digest) in enumerate(zip(names,splits,hashes)):
    p=dest/str(split)/str(name)
    actual=data.sha256(p)
    if actual != str(digest): raise ValueError('Original CLIP video hash mismatch: '+str(name))
    verified.append({'filename':str(name),'official_split':str(split),'video_sha256':actual,'bytes':p.stat().st_size})
    if (i+1)%500==0: print('VIDEO_HASHES_VERIFIED',i+1,flush=True)
with (B/'verified_media.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(verified[0]));w.writeheader();w.writerows(verified)
data.atomic_json(B/'MEDIA_COMPLETE.json',{'n':len(verified),'all_match_original_clip_hashes':True,'originals_read_only':True})
print('MEDIA_COMPLETE',len(verified),flush=True)
