"""Resumable frozen SigLIP 2 inference using the original CLIP video/frame references."""
from pathlib import Path
import sys,os,json,hashlib,time,platform,fcntl,concurrent.futures,importlib.metadata
B=Path(__file__).resolve().parent
sys.path.insert(0,str(B/'encoder_packages'));sys.path.insert(0,str(B.parent/'colab_rerun'))
os.environ['HF_HUB_OFFLINE']='1';os.environ['TOKENIZERS_PARALLELISM']='false'
import numpy as np
import torch
from transformers import SiglipVisionModel,SiglipImageProcessor
import experiment as exp
from chalearn_data import sha256,atomic_json
def atomic_npz(p,**items):
 tmp=p.with_suffix('.tmp')
 with tmp.open('wb') as f:np.savez_compressed(f,**items)
 os.replace(tmp,p)
cfg=json.loads((B/'protocol.json').read_text())
assert sha256(B/'frame_reference.npz')==cfg['frame_reference_sha256']
lock=(B/'extraction.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
torch.set_num_threads(4)
assert torch.backends.mps.is_available()
for file,info in json.loads((B/'model_files.json').read_text()).items():assert sha256(B/'model'/file)==info['sha256'],file
expected=json.loads((B/'model_expected_hash.json').read_text())
assert expected['revision']==cfg['encoder']['revision']
assert (B/'model/model.safetensors').stat().st_size==expected['size']
assert sha256(B/'model/model.safetensors')==expected['sha256']
model,loading=SiglipVisionModel.from_pretrained(B/'model',local_files_only=True,trust_remote_code=False,use_safetensors=True,torch_dtype=torch.float32,attn_implementation='sdpa',output_loading_info=True)
assert not loading['missing_keys'] and not loading['mismatched_keys'] and not loading['error_msgs'],loading
assert all(k.startswith('text_model.') or k in ['logit_scale','logit_bias'] for k in loading['unexpected_keys']),loading
assert model.config.hidden_size==768 and model.config.image_size==224 and model.config.patch_size==16
processor=SiglipImageProcessor.from_pretrained(B/'model',local_files_only=True)
model.eval().requires_grad_(False).to('mps')
versions={k:importlib.metadata.version(k) for k in ['torch','numpy','transformers','opencv-python-headless','Pillow','safetensors','huggingface-hub']}
identity={'protocol_sha256':sha256(B/'protocol.json'),'extractor_sha256':sha256(__file__),'model_files_sha256':sha256(B/'model_files.json'),'frame_reference_sha256':cfg['frame_reference_sha256'],'software':versions,'python':platform.python_version(),'device':'mps','dtype':'float32','pooling':'SiglipVisionModel.pooler_output_L2_normalized','processor':processor.to_dict(),'model_config':model.config.to_dict()}
identity_hash=hashlib.sha256(json.dumps(identity,sort_keys=True).encode()).hexdigest()
if (B/'feature_identity.json').exists():assert json.loads((B/'feature_identity.json').read_text())==identity
else:atomic_json(B/'feature_identity.json',identity)
with np.load(B/'frame_reference.npz',allow_pickle=False) as z:
 names=z['names'].copy();splits=z['official_splits'].copy();indices=z['frame_indices'].copy();hashes=z['video_sha256'].copy()
out=B/'features';out.mkdir(exist_ok=True)
def read_video(i):
 p=B/'media'/str(splits[i])/str(names[i]);assert sha256(p)==str(hashes[i]),str(names[i])
 frames,ix=exp.sample_frames(p,10);assert np.array_equal(ix,indices[i]),str(names[i])
 # Raw RGB hashes document decoded pixels without publishing/repacking images.
 rgb=[hashlib.sha256(np.asarray(f).tobytes()).hexdigest() for f in frames]
 return i,frames,ix,rgb
def validate_cache(i):
 p=out/(str(names[i])+'.npz')
 if not p.exists():return False
 with np.load(p,allow_pickle=False) as z:
  assert str(z['identity_hash'].item())==identity_hash and str(z['video_sha256'].item())==str(hashes[i])
  assert np.array_equal(z['frame_indices'],indices[i])
  f=z['features'];assert f.shape==(10,768) and f.dtype==np.float32 and np.isfinite(f).all() and np.allclose(np.linalg.norm(f,axis=-1),1,atol=1e-5)
 return True
pending=[i for i in range(len(names)) if not validate_cache(i)]
print('EXTRACTION_START','cached',len(names)-len(pending),'remaining',len(pending),flush=True)
start=time.monotonic();new=0
try:
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
  for offset in range(0,len(pending),8):
   batch=list(pool.map(read_video,pending[offset:offset+8]));frames=[f for _,ff,_,_ in batch for f in ff]
   pixels=processor(images=frames,return_tensors='pt')['pixel_values']
   with torch.inference_mode():
    f=torch.nn.functional.normalize(model(pixel_values=pixels.to('mps')).pooler_output,dim=-1).cpu().numpy().astype(np.float32)
   if not (B/'inference_validation.json').exists():
    # Verify CPU/MPS agreement once, without looking at any target labels or scores.
    model.to('cpu')
    with torch.inference_mode():ref=torch.nn.functional.normalize(model(pixel_values=pixels[:10]).pooler_output,dim=-1).numpy()
    delta=float(np.max(np.abs(ref-f[:10])));cos=np.sum(ref*f[:10],axis=1)
    assert delta<0.0001 and cos.min()>0.99999,(delta,cos.min())
    model.to('mps')
    atomic_json(B/'inference_validation.json',{'first_video':str(names[batch[0][0]]),'cpu_mps_max_abs_difference':delta,'minimum_cosine':float(cos.min()),'labels_used':False,'feature_shape':[10,768],'processor':processor.to_dict()})
   for j,(i,ff,ix,rgb) in enumerate(batch):
    feat=f[10*j:10*(j+1)];assert np.isfinite(feat).all() and np.allclose(np.linalg.norm(feat,axis=1),1,atol=1e-5)
    atomic_npz(out/(str(names[i])+'.npz'),features=feat,frame_indices=np.array(ix),video_sha256=np.array(str(hashes[i])),frame_rgb_sha256=np.array(rgb),identity_hash=np.array(identity_hash))
   new+=len(batch);elapsed=time.monotonic()-start;done=len(names)-len(pending)+new
   status={'phase':'extracting','complete_clips':done,'total_clips':len(names),'new_clips_this_session':new,'elapsed_seconds':elapsed,'clips_per_second':new/elapsed,'estimated_remaining_seconds':(len(names)-done)*elapsed/new,'identity_hash':identity_hash}
   atomic_json(B/'extraction_status.json',status)
   if new%80==0 or done==len(names):print('FEATURES',done,'/',len(names),'clips_per_second',round(new/elapsed,3),flush=True)
except Exception as e:
 atomic_json(B/'extraction_failure.json',{'error':repr(e),'new_clips_this_session':new});raise
for i in range(len(names)):assert validate_cache(i)
features=[];rgb=[];cache_hashes=[]
for name in names:
 p=out/(str(name)+'.npz')
 with np.load(p,allow_pickle=False) as z:features.append(z['features'].copy());rgb.append(z['frame_rgb_sha256'].copy())
 cache_hashes.append(sha256(p))
atomic_npz(B/'cache_bundle.npz',names=names,official_splits=splits,features=np.stack(features),frame_indices=indices,video_sha256=hashes,frame_rgb_sha256=np.stack(rgb),cache_sha256=np.array(cache_hashes),feature_identity_json=np.array(json.dumps(identity,sort_keys=True)))
atomic_json(B/'FEATURES_COMPLETE.json',{'n':len(names),'shape':[10000,10,768],'bundle_sha256':sha256(B/'cache_bundle.npz'),'identity_hash':identity_hash,'all_video_hashes_and_frame_indices_match_clip':True})
atomic_json(B/'extraction_status.json',{'phase':'complete','complete_clips':len(names),'total_clips':len(names)})
print('FEATURES_COMPLETE',len(names),flush=True)
