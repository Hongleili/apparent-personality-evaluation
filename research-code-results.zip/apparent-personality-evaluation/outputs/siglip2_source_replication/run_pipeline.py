"""One local resumable run: extraction, five partitions, independent verification."""
from pathlib import Path
import sys,subprocess,json,time,fcntl,concurrent.futures,os
B=Path(__file__).resolve().parent
lock=(B/'pipeline.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
def status(v):
 p=B/'pipeline_status.json';q=p.with_suffix('.tmp');q.write_text(json.dumps(v,indent=2));os.replace(q,p)
def run(script,log,*args):
 with (B/log).open('a') as f:
  r=subprocess.run([sys.executable,str(B/script),*map(str,args)],stdout=f,stderr=subprocess.STDOUT)
 if r.returncode:raise RuntimeError(f'{script} {args} failed with status {r.returncode}; inspect {log}')
try:
 status({'phase':'waiting_for_checkpoint_download'})
 start=time.monotonic()
 while not (B/'model_files.json').exists():
  if time.monotonic()-start>1800:raise TimeoutError('Official model download did not finish within 30 minutes')
  time.sleep(5)
 assert json.loads((B/'MEDIA_COMPLETE.json').read_text())['all_match_original_clip_hashes']
 status({'phase':'feature_extraction'})
 run('extract_features.py','extraction.log')
 status({'phase':'training','partitions_completed':[]})
 cfg=json.loads((B/'protocol.json').read_text());completed=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
  jobs={pool.submit(run,'run_partition.py',f'partition_{s}.log',s):s for s in cfg['partition_seeds']}
  for job in concurrent.futures.as_completed(jobs):
   job.result();completed.append(jobs[job]);status({'phase':'training','partitions_completed':sorted(completed)})
 status({'phase':'independent_verification'})
 run('analyze_results.py','analysis.log')
 status({'phase':'complete','verification':json.loads((B/'COMPLETE.json').read_text())})
 print('PIPELINE_COMPLETE',flush=True)
except Exception as e:
 status({'phase':'failed','error':repr(e)});raise
