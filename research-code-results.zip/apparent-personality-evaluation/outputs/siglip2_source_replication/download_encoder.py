"""Fetch the official checkpoint at an immutable revision; no remote Python code."""
from pathlib import Path
import sys, json, hashlib, os
B=Path(__file__).resolve().parent
sys.path.insert(0,str(B/'encoder_packages'))
os.environ['HF_HUB_DISABLE_TELEMETRY']='1'
os.environ['HF_HUB_DISABLE_XET']='1'
from huggingface_hub import HfApi, snapshot_download
model='google/siglip2-base-patch16-224'
p=B/'model_identity.json'
if p.exists(): identity=json.loads(p.read_text())
else:
    info=HfApi().model_info(model)
    identity={'model_id':model,'revision':info.sha,'trust_remote_code':False,'weights_format':'safetensors'}
    p.write_text(json.dumps(identity,indent=2))
print('MODEL_REVISION',identity['revision'],flush=True)
folder=snapshot_download(model,revision=identity['revision'],allow_patterns=['config.json','preprocessor_config.json','model.safetensors','README.md'],local_dir=B/'model',max_workers=2)
manifest={}
for f in (B/'model').iterdir():
    if f.is_file():
        h=hashlib.sha256()
        with f.open('rb') as stream:
            for chunk in iter(lambda:stream.read(8*1024*1024),b''):h.update(chunk)
        manifest[f.name]={'sha256':h.hexdigest(),'bytes':f.stat().st_size}
(B/'model_files.json').write_text(json.dumps(manifest,indent=2))
print('MODEL_READY',folder,flush=True)
