"""Audit frozen Qwen responses and compare unchanged CLIP predictions."""
from pathlib import Path
import csv, hashlib, json, math, re
from collections import Counter
import numpy as np

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent.parent
INPUT = BASE/'inputs'
OUT = BASE/'analysis'
OUT.mkdir(exist_ok=True)
TRAITS = ['openness','conscientiousness','extraversion','agreeableness','neuroticism']
KEYS = TRAITS[:-1] + ['emotional_stability']
SEEDS = list(range(42,47))
HEADS = ['ffnn','cnn','lstm','gru','bilstm','cnn_lstm']
NBOOT = 50000
RNG_SEED = 20261122
HASHES = {}

def sha(path):
    value=hashlib.sha256(path.read_bytes()).hexdigest()
    HASHES[str(path.relative_to(ROOT))]=value
    return value

def write_json(name,obj):
    (OUT/name).write_text(json.dumps(obj,indent=2,allow_nan=False))

def write_csv(name,rows):
    with (OUT/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def matrix(path,names=None):
    sha(path)
    with path.open() as f: rows=list(csv.DictReader(f))
    ns=[r['filename'] for r in rows]
    assert len(ns)==len(set(ns)), path
    values=np.array([[float(r[t]) for t in TRAITS] for r in rows],dtype=np.float64)
    assert np.isfinite(values).all() and ((values>=0)&(values<=1)).all(), path
    if names is not None:
        assert set(ns)==set(names), path
        ix={n:i for i,n in enumerate(ns)}
        values=values[[ix[n] for n in names]]
    return ns,values

names,y=matrix(INPUT/'frozen/test.csv')
assert len(names)==2000
_,reference_labels=matrix(ROOT/'outputs/colab_rerun/repeat_seed_manifests/test.csv',names)
assert np.array_equal(y,reference_labels)
cfg=json.loads((INPUT/'frozen/protocol.json').read_text())
run=json.loads((INPUT/'results/run_config.json').read_text())
inventory=json.loads((INPUT/'results/verified_video_inventory.json').read_text())
assert cfg==run['protocol'] and cfg['keys']==KEYS
assert sha(INPUT/'frozen/test.csv')==cfg['manifest_sha256']
assert sha(INPUT/'frozen/run_fulltest.py')==run['runner_sha256']
assert run['versions']==cfg['software']
assert set(inventory)==set(names)
assert {p.name for p in (INPUT/'results').glob('*.mp4.json')}=={n+'.json' for n in names}
qwen=np.full((2000,5),np.nan)
failures=[];valid=np.zeros(2000,dtype=bool)
raw_counts=Counter();vectors=Counter();coverage_rows=[]
for i,n in enumerate(names):
    path=INPUT/'results'/(n+'.json');sha(path)
    r=json.loads(path.read_text())
    assert r['filename']==n
    assert r['video_sha256']==inventory[n]['video_sha256']
    assert r['frame_indices']==inventory[n]['frame_indices']
    assert len(r['frame_indices'])==10 and len(set(r['frame_indices']))==10
    assert r['frame_indices']==sorted(r['frame_indices'])
    assert len(r['image_grid_thw'])==10
    for h in ['video_sha256','input_ids_sha256','pixels_sha256']:
        assert re.fullmatch('[0-9a-f]{64}',r[h])
    cleaned=re.sub(r'^```(?:json)?\s*','',r['raw'].strip())
    cleaned=re.sub(r'\s*```$','',cleaned)
    error=None
    try:
        p=json.loads(cleaned)
        if not isinstance(p,dict) or set(p)!=set(KEYS) or any(type(v) not in (int,float) or not 0<=v<=1 for v in p.values()):
            raise ValueError('Invalid score schema')
    except (ValueError,TypeError) as exc:
        error=type(exc).__name__
        assert 'parse_error' in r and 'predictions' not in r
        failures.append({'filename':n,'error_type':error,'raw_length':len(r['raw']),'raw':r['raw']})
        raw_counts[r['raw']]+=1
    else:
        assert r['predictions']==p and 'parse_error' not in r
        valid[i]=True;qwen[i]=[p[k] for k in KEYS]
        vectors[tuple(qwen[i])]+=1
    coverage_rows.append({'filename':n,'valid':bool(valid[i]),'parse_error_type':error or ''})
assert int(valid.sum())==1945 and len(failures)==55
expected_status={'expected':2000,'attempted':2000,'valid':1945,'invalid':55,'complete':True}
assert json.loads((INPUT/'results/status.json').read_text())==expected_status
assert json.loads((INPUT/'results/COMPLETE.json').read_text())==expected_status
write_csv('qwen_coverage.csv',coverage_rows)
write_csv('qwen_invalid_responses.csv',failures)
write_csv('qwen_valid_predictions.csv',[dict(filename=names[i],**dict(zip(KEYS,map(float,qwen[i])))) for i in np.flatnonzero(valid)])

train_names,train_y=matrix(ROOT/'outputs/colab_rerun/repeat_seed_manifests/training.csv')
val_names,_=matrix(ROOT/'outputs/colab_rerun/repeat_seed_manifests/validation.csv')
methods={
    'training_mean':np.broadcast_to(train_y.mean(0),(1,2000,5)).copy(),
    'training_median':np.broadcast_to(np.median(train_y,axis=0),(1,2000,5)).copy(),
}
for name in ['zero_shot_cosine','zero_shot_scaled']:
    _,a=matrix(INPUT/'clip'/(name+'_test_predictions.csv'),names);methods[name]=a[None]
for name in ['linear','ridge']:
    _,a=matrix(ROOT/'outputs/linear_baselines/results'/(name+'_test_predictions.csv'),names);methods[name]=a[None]
seed_hashes=json.loads((ROOT/'outputs/paired_uncertainty/analysis.json').read_text())['prediction_sha256']
for head in HEADS:
    arrays=[]
    for seed in SEEDS:
        path=ROOT/f'outputs/five_seed_results/seed_{seed}/{head}_test_predictions.csv'
        assert sha(path)==seed_hashes[str(path.relative_to(ROOT))],path
        _,a=matrix(path,names);arrays.append(a)
    methods[head]=np.stack(arrays)
assert len(methods)==12

def scores(pred,target):
    err=np.abs(pred-target);mae=err.mean(0)
    pcc=[]
    for j in range(5):
        # Explicitly undefined for a mathematically constant predictor.
        if np.ptp(pred[:,j])==0 or np.ptp(target[:,j])==0:pcc.append(None)
        else:pcc.append(float(np.corrcoef(pred[:,j],target[:,j])[0,1]))
    pp=pred>=.5;yy=target>=.5
    tp=(pp&yy).sum(0);tn=(~pp&~yy).sum(0);fp=(pp&~yy).sum(0);fn=(~pp&yy).sum(0)
    fpr=fp/(fp+tn)*100;fnr=fn/(fn+tp)*100
    traits=[{'trait':KEYS[j],'mae':float(mae[j]),'acc_1_minus_mae':float(1-mae[j]),'pcc':pcc[j],
             'fpr_percent':float(fpr[j]),'fnr_percent':float(fnr[j]),'tp':int(tp[j]),'tn':int(tn[j]),'fp':int(fp[j]),'fn':int(fn[j])} for j in range(5)]
    return traits,{'mae':float(mae.mean()),'acc_1_minus_mae':float(1-mae.mean()),'pcc':None if any(v is None for v in pcc) else float(np.mean(pcc)),
                   'fpr_percent':float(fpr.mean()),'fnr_percent':float(fnr.mean())}

trait_rows=[];macro_rows=[];aggregate=[]
def add_method(name,arr,mask,subset):
    metrics=[]
    for k,pred in enumerate(arr):
        tr,ma=scores(pred[mask],y[mask]);metrics.append(ma)
        seed=SEEDS[k] if len(arr)==5 else ''
        for r in tr:trait_rows.append(dict(model=name,subset=subset,n=int(mask.sum()),seed=seed,**r))
        macro_rows.append(dict(model=name,subset=subset,n=int(mask.sum()),seed=seed,**ma))
    row={'model':name,'subset':subset,'n':int(mask.sum()),'runs':len(arr)}
    for key in metrics[0]:
        vals=[m[key] for m in metrics]
        row[key+'_mean']=None if vals[0] is None else float(np.mean(vals))
        row[key+'_sd']=None if vals[0] is None or len(vals)==1 else float(np.std(vals,ddof=1))
    aggregate.append(row)

add_method('qwen',qwen[None],valid,'qwen_valid')
for model,arr in methods.items():
    add_method(model,arr,valid,'qwen_valid')
    add_method(model,arr,np.ones(2000,dtype=bool),'full_test')
write_csv('trait_metrics.csv',trait_rows);write_csv('macro_metrics_per_run.csv',macro_rows);write_csv('macro_metrics.csv',aggregate)

def group(n):
    m=re.fullmatch(r'(.+)\.(\d+)\.mp4',n)
    assert m,n
    return m[1]
all_groups=np.array([group(n) for n in names])
train_groups={group(n) for n in train_names};val_groups={group(n) for n in val_names}
groups,gi=np.unique(all_groups[valid],return_inverse=True);G=len(groups)
sizes=np.bincount(gi).astype(np.float64)
qerr=np.abs(qwen[valid]-y[valid]).mean(1)
model_names=list(methods)
# Positive difference means the comparator has lower MAE than Qwen.
diff=np.column_stack([qerr-np.abs(a[:,valid]-y[None,valid]).mean((0,2)) for a in methods.values()])
group_sums=np.stack([np.bincount(gi,weights=diff[:,j],minlength=G) for j in range(len(model_names))],axis=1)
q_group=np.bincount(gi,weights=qerr,minlength=G)
rng=np.random.default_rng(RNG_SEED)
boot=np.empty((NBOOT,len(model_names)));qboot=np.empty(NBOOT)
for start in range(0,NBOOT,250):
    b=min(250,NBOOT-start)
    picks=rng.integers(0,G,size=(b,G))
    weights=np.zeros((b,G),dtype=np.float64)
    np.add.at(weights,(np.arange(b)[:,None],picks),1)
    denom=weights@sizes
    boot[start:start+b]=(weights@group_sums)/denom[:,None]
    qboot[start:start+b]=(weights@q_group)/denom
    if start%10000==0:print('BOOTSTRAP',start,'/',NBOOT,flush=True)
adjusted_alpha=.05/len(model_names)
contrasts=[]
for j,name in enumerate(model_names):
    lo,hi=np.quantile(boot[:,j],[.025,.975])
    alo,ahi=np.quantile(boot[:,j],[adjusted_alpha/2,1-adjusted_alpha/2])
    contrasts.append({'comparator':name,'qwen_minus_comparator_mae':float(diff[:,j].mean()),
                      'ci95_lower':float(lo),'ci95_upper':float(hi),
                      'bonferroni_lower':float(alo),'bonferroni_upper':float(ahi)})
write_csv('paired_cluster_mae_intervals.csv',contrasts)
np.savez_compressed(OUT/'paired_cluster_bootstrap.npz',differences=boot,qwen_mae=qboot,comparators=np.array(model_names))

# Independent scalar reconciliation of Qwen MAE and confusion totals.
scalar_mae=math.fsum(abs(float(qwen[i,j])-float(y[i,j])) for i in np.flatnonzero(valid) for j in range(5))/(1945*5)
assert abs(scalar_mae-aggregate[0]['mae_mean'])<1e-14
assert all(r['tp']+r['tn']+r['fp']+r['fn']==r['n'] for r in trait_rows)
assert np.allclose(diff.mean(0),[aggregate[0]['mae_mean']-next(r['mae_mean'] for r in aggregate if r['model']==m and r['subset']=='qwen_valid') for m in model_names],atol=1e-14)
summary={
 'status':expected_status,'coverage_percent':97.25,'traits':KEYS,'source_label_mapping':'neuroticism retained numerically; displayed as emotional stability, no inversion',
 'qwen':aggregate[0],'qwen_mae_cluster_ci95':np.quantile(qboot,[.025,.975]).tolist(),
 'unique_valid_vectors':len(vectors),'largest_duplicate_vector_count':max(vectors.values()),
 'invalid_raw_patterns':[{'count':v,'raw_length':len(k),'all_exclamation_marks':set(k)=={'!'},'raw_preview':k[:80]} for k,v in raw_counts.most_common()],
 'groups':{'full_test':len(set(all_groups)),'valid_test':G,'invalid_test':len(set(all_groups[~valid])),
           'valid_group_sizes':dict(sorted(Counter(map(int,sizes)).items())),
           'training':len(train_groups),'validation':len(val_groups),
           'train_test_prefix_overlap':len(train_groups&set(all_groups)),
           'validation_test_prefix_overlap':len(val_groups&set(all_groups))},
 'bootstrap':{'replicates':NBOOT,'rng_seed':RNG_SEED,'unit':'filename source-video prefix; not verified person identity',
              'estimand':'clip-weighted macro MAE, ratio of cluster-summed errors to cluster clip counts',
              'difference':'Qwen MAE minus comparator MAE; positive favours comparator',
              'comparisons':len(model_names),'marginal_adjusted_coverage_percent':100*(1-adjusted_alpha),
              'conditional_on':'fixed valid subset and fitted models; neural comparison averages per-clip absolute errors across five fixed seeds, not ensemble predictions; no seed resampling',
              'limitations':'Exploratory conditional intervals, approximate Bonferroni family coverage; no correction of cross-split source overlap or training-population uncertainty'},
 'metrics':aggregate,'contrasts':contrasts,'hashes':HASHES,
 'verification':['2009 exported inputs matched recorded SHA256','2000 unique planned responses','raw JSON independently reparsed under frozen strict schema','all saved predictions and failure flags reconciled','all frame indices and source hashes matched saved inventory','manifest and runner hashes matched frozen configuration','30 neural prediction files matched archived SHA256','all comparator filename sets matched test manifest','official labels exactly matched the independent local manifest','MAE independently reconciled using scalar summation','all confusion counts reconciled to evaluated sample sizes']}
write_json('analysis.json',summary)
print(json.dumps({k:summary[k] for k in ['status','qwen','qwen_mae_cluster_ci95','unique_valid_vectors','largest_duplicate_vector_count','invalid_raw_patterns','groups','contrasts']},indent=2),flush=True)
