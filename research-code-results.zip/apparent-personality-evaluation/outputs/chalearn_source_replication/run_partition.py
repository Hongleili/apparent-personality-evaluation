"""Extend frozen CLIP neural comparison to a specified existing partition.
Original data, configuration and results are read only. Every epoch is resumable.
"""
import os
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:os.environ[key]='2'
from pathlib import Path
import csv,json,hashlib,sys,copy,random,time,platform,fcntl
import numpy as np
import torch
from torch.utils.data import DataLoader,TensorDataset
B=Path(__file__).resolve().parent;P=B.parent/'chalearn_source_disjoint';O=B/'results';O.mkdir(exist_ok=True)
sys.path.insert(0,str(B.parent/'colab_rerun'));import experiment as exp
T=exp.TRAITS

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def js(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);q=p.with_suffix('.tmp');q.write_text(json.dumps(x,indent=2,allow_nan=False));os.replace(q,p)
def csvwrite(p,r):exp.write_csv(p,r)
def torchsave(p,obj):q=p.with_suffix('.tmp');torch.save(obj,q);os.replace(q,p)
def frozen(p,obj):
 if p.exists():assert json.loads(p.read_text())==obj,f'Frozen configuration changed: {p}'
 else:js(p,obj)
def rng():
 n=np.random.get_state();return {'python':random.getstate(),'numpy':[n[0],n[1].tolist(),n[2],n[3],n[4]],'torch':torch.get_rng_state()}
def restore(r):
 random.setstate(r['python']);n=r['numpy'];np.random.set_state((n[0],np.array(n[1],dtype=np.uint32),n[2],n[3],n[4]));torch.set_rng_state(r['torch'])
def report(dest,model,seed,split,ix,pred):
 yy=y[ix].astype(float);pp=np.asarray(pred,dtype=float);metrics=exp.metrics(yy,pp);tag=f'{model}_seed{seed}'
 csvwrite(dest/f'{tag}_{split}_predictions.csv',[{'filename':str(names[i]),**{t:float(pp[k,j]) for j,t in enumerate(T)}} for k,i in enumerate(ix)])
 csvwrite(dest/f'{tag}_{split}_metrics.csv',metrics)
 return {'model':model,'training_seed':seed,'split':split,'n':len(ix),'MAE':float(np.abs(yy-pp).mean()),'MSE':float(((yy-pp)**2).mean()),'PCC':float(np.mean([r['PCC'] for r in metrics])),'ACC':float(1-np.abs(yy-pp).mean()),'partition_seed':splitseed,'condition':condition}

torch.set_num_threads(2);cfg=json.loads((B/'protocol.json').read_text());splitseed=int(sys.argv[1]);assert splitseed in cfg['new_partition_seeds'];R=O/str(splitseed);R.mkdir(exist_ok=True)
lock=(R/'worker.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert sha(B/'parent_inventory.json')==cfg['parent_inventory_sha256']
assert sha(P/'protocol.json')==cfg['parent_protocol_sha256'];assert sha(P/'run_source_disjoint.py')==cfg['parent_runner_sha256'];assert sha(P/'cache_bundle.npz')==cfg['bundle_sha256'];assert sha(P/'all_labels.csv')==cfg['all_labels_sha256']
assert sha(B.parent/'colab_rerun/experiment.py')==cfg['architecture_sha256'];assert sha(B.parent/'colab_rerun/chalearn_data.py')==cfg['data_module_sha256']
software={'python':platform.python_version(),'numpy':np.__version__,'torch':str(torch.__version__)};assert software==cfg['software']
identity={'runner_sha256':sha(__file__),'protocol_sha256':sha(B/'protocol.json'),'bundle_sha256':cfg['bundle_sha256'],'software':software,'device':'cpu','threads':2,'partition_seed':splitseed,'architecture_sha256':cfg['architecture_sha256']};frozen(R/'run_identity.json',identity)
with np.load(P/'cache_bundle.npz',allow_pickle=False) as z:names=z['names'].copy();x=z['features'].copy();official=z['official_splits'].copy()
assert x.shape==(10000,10,768) and x.dtype==np.float32 and np.isfinite(x).all() and np.allclose(np.linalg.norm(x,axis=2),1,atol=1e-4)
rr=list(csv.DictReader((P/'all_labels.csv').open()));assert [r['filename'] for r in rr]==names.tolist();assert [r['official_split'] for r in rr]==official.tolist();y=np.array([[float(r[t]) for t in T] for r in rr],dtype=np.float32);idx={str(n):i for i,n in enumerate(names)}
# Independently verify unchanged labels against original annotation manifests.
parent=json.loads((P/'protocol.json').read_text())
for s,h in parent['official_manifest_sha256'].items():
 f=B.parent/'colab_rerun/repeat_seed_manifests'/(s+'.csv');assert sha(f)==h
 for r in csv.DictReader(f.open()):assert np.array_equal(y[idx[r['filename']]],np.array([float(r[t]) for t in T],dtype=np.float32))
ns=[]
for condition in cfg['neural']['conditions']:
 dest=R/condition;dest.mkdir(exist_ok=True);manifest=P/'manifests'/str(splitseed)/condition
 ids={s:np.array([idx[r['filename']] for r in csv.DictReader((manifest/(s+'.csv')).open())]) for s in ['training','validation','test']}
 assert len(set(np.concatenate(list(ids.values()))))==10000
 groups={s:{rr[i]['source_prefix'] for i in ix} for s,ix in ids.items()}
 if condition=='source_disjoint':assert all(not(groups[a]&groups[b]) for a,b in [('training','validation'),('training','test'),('validation','test')])
 for s in ids:
  rel=str((manifest/(s+'.csv')).relative_to(P));assert sha(P/rel)==json.loads((B/'parent_inventory.json').read_text())[rel]
 tr,va=ids['training'],ids['validation'];xt=torch.from_numpy(x[tr]);yt=torch.from_numpy(y[tr]);xv=torch.from_numpy(x[va]);yv=torch.from_numpy(y[va])
 for seed in cfg['neural']['training_seeds']:
  for kind in cfg['neural']['heads']:
   tag=f'{kind}_seed{seed}';d=dest/(tag+'_checkpoint');d.mkdir(exist_ok=True);done=d/'complete.json'
   exp.seed_all(seed);head=exp.make_head(kind,x.shape[-1]);opt=torch.optim.Adam(head.parameters(),lr=.001);gen=torch.Generator().manual_seed(seed)
   loader=DataLoader(TensorDataset(xt,yt),batch_size=64,shuffle=True,generator=gen);history=[];best=float('inf');bad=0;beststate=None;bestepoch=None;last=d/'last.pt'
   if last.exists():
    c=torch.load(last,map_location='cpu',weights_only=True);assert c['identity']==identity
    head.load_state_dict(c['head']);opt.load_state_dict(c['optimizer']);gen.set_state(c['loader']);restore(c['rng']);history=c['history'];best=c['best'];bad=c['bad'];beststate=c['beststate'];bestepoch=c['bestepoch']
   if not done.exists():
    for epoch in range(len(history),100):
     if bad>=15:break
     start=time.monotonic();head.train();total=0.
     for bx,by in loader:
      opt.zero_grad();loss=torch.nn.functional.mse_loss(head(bx),by);loss.backward();opt.step();total+=loss.item()*len(bx)
     head.eval()
     with torch.inference_mode():vl=float(torch.nn.functional.mse_loss(head(xv),yv))
     assert np.isfinite(vl)
     if vl<best:best=vl;bad=0;beststate=copy.deepcopy(head.state_dict());bestepoch=epoch+1
     else:bad+=1
     history.append({'epoch':epoch+1,'training_mse':total/len(tr),'validation_mse':vl})
     torchsave(last,{'identity':identity,'head':head.state_dict(),'optimizer':opt.state_dict(),'loader':gen.get_state(),'rng':rng(),'history':history,'best':best,'bad':bad,'beststate':beststate,'bestepoch':bestepoch})
     csvwrite(d/'history.csv',history);js(R/'status.json',{'phase':'training','partition_seed':splitseed,'condition':condition,'head':kind,'training_seed':seed,'epoch':epoch+1,'validation_mse':vl,'completed_fits':len(ns)//2,'total_fits':20})
     print('EPOCH',splitseed,condition,kind,seed,epoch+1,'val',round(vl,6),'seconds',round(time.monotonic()-start,2),flush=True)
   else:assert json.loads(done.read_text())['identity']==identity
   assert beststate is not None;head.load_state_dict(beststate);head.eval()
   for split in ['validation','test']:
    ii=ids[split]
    with torch.inference_mode():pp=np.concatenate([head(torch.from_numpy(x[ii[j:j+256]])).numpy() for j in range(0,len(ii),256)])
    ns.append(report(dest,kind,seed,split,ii,pp))
   torchsave(d/'best.pt',{'state_dict':beststate,'bestepoch':bestepoch,'validation_mse':best});js(done,{'identity':identity,'bestepoch':bestepoch,'validation_mse':best,'epochs':len(history),'seed':seed,'kind':kind})
   csvwrite(R/'neural_summary.csv',ns);print('FIT_COMPLETE',splitseed,condition,tag,'test_mae',ns[-1]['MAE'],flush=True)
js(R/'COMPLETE.json',{'identity':identity,'neural_rows':len(ns),'all_fits_complete':True});js(R/'status.json',{'phase':'complete','completed_fits':20,'total_fits':20});print('PARTITION_COMPLETE',splitseed,flush=True)
