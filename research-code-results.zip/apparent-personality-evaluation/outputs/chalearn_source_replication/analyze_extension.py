"""Independent metric and weight verification of all five partition comparisons."""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:os.environ[k]='2'
from pathlib import Path
import csv,json,hashlib,sys
import numpy as np
B=Path(__file__).resolve().parent;P=B.parent/'chalearn_source_disjoint';A=B/'analysis';A.mkdir(exist_ok=True)
T=['openness','conscientiousness','extraversion','agreeableness','neuroticism']
def rows(p):return list(csv.DictReader(Path(p).open()))
def write(p,r):
 with Path(p).open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(r[0]));w.writeheader();w.writerows(r)
def js(p,v):Path(p).write_text(json.dumps(v,indent=2,allow_nan=False))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
cfg=json.loads((B/'protocol.json').read_text());pcfg=json.loads((P/'protocol.json').read_text())
for seed in cfg['new_partition_seeds']:assert json.loads((B/'results'/str(seed)/'COMPLETE.json').read_text())['all_fits_complete']
inventory=json.loads((B/'parent_inventory.json').read_text())
for name,digest in inventory.items():assert sha(P/name)==digest,('Parent changed',name)
raw=[dict(r,root=str(P/'results')) for r in rows(P/'results/baseline_summary.csv')+rows(P/'results/neural_summary.csv')]
for seed in cfg['new_partition_seeds']:
 raw.extend(dict(r,root=str(B/'results')) for r in rows(B/'results'/str(seed)/'neural_summary.csv'))
assert len(raw)==320 and len({(r['partition_seed'],r['condition'],r['model'],r['training_seed'],r['split']) for r in raw})==320
verified=[];checks=[];traits=[]
for r in raw:
 seed=r['partition_seed'];cond=r['condition'];split=r['split'];model=r['model'];ts=r['training_seed'];tag=model+('_seed'+ts if ts else '')
 d=Path(r['root'])/seed/cond;m=rows(P/'manifests'/seed/cond/(split+'.csv'));pr=rows(d/(tag+'_'+split+'_predictions.csv'))
 assert [z['filename'] for z in pr]==[z['filename'] for z in m]
 y=np.array([[float(z[t]) for t in T] for z in m],dtype=np.float32).astype(float);p=np.array([[float(z[t]) for t in T] for z in pr])
 assert np.isfinite(p).all() and ((p>=0)&(p<=1)).all() and len(y)==int(r['n'])
 err=np.abs(y-p);mae=float(err.mean());mse=float(((y-p)**2).mean());pt=rows(d/(tag+'_'+split+'_metrics.csv'));pcs=[]
 assert abs(mae-float(r['MAE']))<1e-12 and abs(mse-float(r['MSE']))<1e-12 and abs(1-mae-float(r['ACC']))<1e-12
 for j,t in enumerate(T):
  z=pt[j];assert z['trait']==t and int(z['n'])==len(y)
  a=y[:,j];b=p[:,j];a1=a>=.5;b1=b>=.5
  v={'MAE':float(err[:,j].mean()),'ACC':float(1-err[:,j].mean()),'TP':int((a1&b1).sum()),'TN':int((~a1&~b1).sum()),'FP':int((~a1&b1).sum()),'FN':int((a1&~b1).sum())}
  v.update(FPR_percent=100*v['FP']/(v['FP']+v['TN']),FNR_percent=100*v['FN']/(v['FN']+v['TP']))
  cc=float(np.corrcoef(a,b)[0,1]) if np.ptp(a)>0 and np.ptp(b)>0 else None;pcs.append(cc)
  if cc is None:assert z['PCC']==''
  else:assert abs(cc-float(z['PCC']))<1e-10
  for key,val in v.items():assert abs(val-float(z[key]))<1e-10,(tag,key)
  traits.append({'partition_seed':seed,'condition':cond,'model':model,'training_seed':ts,'split':split,'trait':t,**v,'PCC':cc})
 cc=float(np.mean(pcs)) if all(v is not None for v in pcs) else None
 if cc is None:assert r['PCC']==''
 else:assert abs(cc-float(r['PCC']))<1e-10
 if model=='ridge':
  grid=rows(d/'ridge_validation_search.csv');chosen=min(grid,key=lambda z:(float(z['validation_MSE']),float(z['alpha'])))
  assert float(chosen['alpha'])==json.loads((d/'ridge_selection.json').read_text())['alpha']
 if ts:
  ck=d/(tag+'_checkpoint');hist=rows(ck/'history.csv');sel=json.loads((ck/'complete.json').read_text());h=min(hist,key=lambda z:float(z['validation_mse']))
  assert int(h['epoch'])==sel['bestepoch'] and float(h['validation_mse'])==sel['validation_mse']
 checks.append({'partition_seed':seed,'condition':cond,'split':split,'model':model,'training_seed':ts,'verified':True,'n':len(y)})
 verified.append(dict(r,MAE=mae,MSE=mse,PCC=cc))
write(A/'prediction_verification.csv',checks);write(A/'all_trait_metrics.csv',traits)
print('METRICS_VERIFIED',len(checks),sum(z['n'] for z in checks),flush=True)
# Manifest overlap and exact counts verified afresh, without assuming prior audit.
audits=[]
for seed in cfg['partition_seeds_all']:
 for cond in cfg['neural']['conditions']:
  mm={s:rows(P/'manifests'/str(seed)/cond/(s+'.csv')) for s in ['training','validation','test']};allnames=[z['filename'] for rs in mm.values() for z in rs]
  assert len(allnames)==len(set(allnames))==10000
  g={s:{r['source_prefix'] for r in rs} for s,rs in mm.items()}
  ov={a+'_'+b:len(g[a]&g[b]) for a,b in [('training','validation'),('training','test'),('validation','test')]}
  if cond=='source_disjoint':assert all(v==0 for v in ov.values()) and [len(g[s]) for s in mm]==[1836,612,612]
  audits.append({'partition_seed':seed,'condition':cond,**{s+'_clips':len(rs) for s,rs in mm.items()},**ov})
write(A/'partition_verification.csv',audits)
import torch
sys.path.insert(0,str(B.parent/'colab_rerun'));import experiment as exp
torch.set_num_threads(2)
assert sha(B.parent/'colab_rerun/experiment.py')==cfg['architecture_sha256']
with np.load(P/'cache_bundle.npz',allow_pickle=False) as z:features=z['features'].copy();lookup={n:i for i,n in enumerate(z['names'])}
weight_checks=[]
for r in raw:
 if not r['training_seed'] or r['split']!='test':continue
 d=Path(r['root'])/r['partition_seed']/r['condition'];tag=r['model']+'_seed'+r['training_seed'];ck=torch.load(d/(tag+'_checkpoint')/'best.pt',map_location='cpu',weights_only=True)
 head=exp.make_head(r['model'],768);head.load_state_dict(ck['state_dict']);head.eval();saved=rows(d/(tag+'_test_predictions.csv'));ii=[lookup[z['filename']] for z in saved]
 with torch.inference_mode():actual=np.concatenate([head(torch.from_numpy(features[ii[j:j+256]])).numpy() for j in range(0,len(ii),256)])
 expected=np.array([[float(z[t]) for t in T] for z in saved]);delta=float(np.max(np.abs(actual.astype(float)-expected)));assert delta<1e-7
 weight_checks.append({'partition_seed':r['partition_seed'],'condition':r['condition'],'model':r['model'],'seed':r['training_seed'],'max_prediction_difference':delta})
 if len(weight_checks)%20==0:print('WEIGHTS_VERIFIED',len(weight_checks),flush=True)
write(A/'selected_weight_verification.csv',weight_checks);del features
by_partition=[];aggregate=[];models=pcfg['baselines_all_partitions']+['ffnn','cnn_lstm']
for cond in cfg['neural']['conditions']:
 for model in models:
  for seed in cfg['partition_seeds_all']:
   rr=[r for r in verified if r['condition']==cond and r['model']==model and r['split']=='test' and r['partition_seed']==str(seed)];vals=np.array([r['MAE'] for r in rr]);pcs=[r['PCC'] for r in rr]
   assert len(rr)==(5 if model in cfg['neural']['heads'] else 1)
   by_partition.append({'partition_seed':seed,'condition':cond,'model':model,'test_clips':int(rr[0]['n']),'n_fits':len(rr),'MAE_mean':float(vals.mean()),'MAE_seed_sd':float(vals.std(ddof=1)) if len(vals)>1 else 0.,'PCC_mean':float(np.mean(pcs)) if all(p is not None for p in pcs) else None})
  rr=[r for r in by_partition if r['condition']==cond and r['model']==model];vals=np.array([r['MAE_mean'] for r in rr]);pcs=[r['PCC_mean'] for r in rr]
  aggregate.append({'condition':cond,'model':model,'n_partitions':5,'fits_per_partition':rr[0]['n_fits'],'MAE_mean':float(vals.mean()),'MAE_partition_sd':float(vals.std(ddof=1)),'PCC_mean':float(np.mean(pcs)) if all(p is not None for p in pcs) else None})
write(A/'test_by_partition.csv',by_partition);write(A/'test_summary.csv',aggregate)
# Two comparisons on each of five source-separated tests, family of ten.
contr=[]
for seed in cfg['partition_seeds_all']:
 cond='source_disjoint';d=P/'results'/str(seed)/cond;nd=d if seed==20261123 else B/'results'/str(seed)/cond;m=rows(P/'manifests'/str(seed)/cond/'test.csv');names=[z['filename'] for z in m];y=np.array([[float(z[t]) for t in T] for z in m],dtype=np.float32).astype(float)
 def pred(root,tag):
  rr=rows(root/(tag+'_test_predictions.csv'));assert [z['filename'] for z in rr]==names
  return np.array([[float(z[t]) for t in T] for z in rr])
 err=lambda p:np.abs(p-y).mean(1)
 er=err(pred(d,'ridge'));em=err(pred(d,'training_median'));en=np.mean([err(pred(nd,'cnn_lstm_seed'+str(s))) for s in cfg['neural']['training_seeds']],axis=0)
 diffs=np.stack([er-em,en-er],axis=1);groups,gi=np.unique([z['source_prefix'] for z in m],return_inverse=True);sizes=np.bincount(gi);sums=np.stack([np.bincount(gi,weights=diffs[:,j]) for j in range(2)],axis=1)
 gen=np.random.default_rng(seed);bs=[]
 for _ in range(20):
  w=gen.multinomial(len(groups),np.full(len(groups),1/len(groups)),size=500);bs.append((w@sums)/(w@sizes)[:,None])
 bs=np.concatenate(bs)
 for j,name in enumerate(['ridge_minus_training_median','cnn_lstm_mean_error_minus_ridge']):
  ci=np.quantile(bs[:,j],[.025,.975,.0025,.9975]);contr.append({'partition_seed':seed,'contrast':name,'difference_MAE':float(diffs[:,j].mean()),'CI95_lower':float(ci[0]),'CI95_upper':float(ci[1]),'CI99_5_lower':float(ci[2]),'CI99_5_upper':float(ci[3]),'n_source_groups':len(groups),'n_clips':len(y),'bootstrap_replicates':10000})
write(A/'source_cluster_contrasts.csv',contr)
def get(seed,cond,model):return next(r for r in by_partition if r['partition_seed']==seed and r['condition']==cond and r['model']==model)
directions=[]
for seed in cfg['partition_seeds_all']:
 for model in ['ridge','ffnn','cnn_lstm']:
  source=get(seed,'source_disjoint',model);control=get(seed,'clip_random_control',model)
  directions.append({'partition_seed':seed,'model':model,'source_minus_control_MAE':source['MAE_mean']-control['MAE_mean'],'source_minus_ridge_MAE':source['MAE_mean']-get(seed,'source_disjoint','ridge')['MAE_mean'],'control_minus_ridge_MAE':control['MAE_mean']-get(seed,'clip_random_control','ridge')['MAE_mean']})
write(A/'direction_checks.csv',directions)
# Repeat parent hash check after read-only analysis.
for name,digest in inventory.items():assert sha(P/name)==digest
v={'prediction_files_verified':len(checks),'prediction_rows_verified':sum(r['n'] for r in checks),'all_macro_and_trait_metrics_recomputed':True,'all_ridge_selections_validation_only':True,'neural_best_epochs_match_validation_minima':True,'source_overlap_all_grouped_splits':0,'selected_neural_weights_verified':len(weight_checks),'parent_files_unchanged':len(inventory),'all_fits_complete':True,'complete':True};js(A/'verification.json',v)
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10})
fig,axes=plt.subplots(1,2,figsize=(10.8,4.15),layout='constrained')
colors={'ridge':'#2b6b91','ffnn':'#b07123','cnn_lstm':'#6c4b8e'}
for ax,cond,title in zip(axes,['clip_random_control','source_disjoint'],['Size-matched random-clip controls','Source-separated partitions']):
 for model,label in [('ridge','Ridge'),('ffnn','FFNN'),('cnn_lstm','CNN–LSTM')]:
  rr=[get(s,cond,model) for s in cfg['partition_seeds_all']];offset={'ridge':-.1,'ffnn':0.,'cnn_lstm':.1}[model]
  ax.errorbar(np.arange(1,6)+offset,[r['MAE_mean'] for r in rr],yerr=[r['MAE_seed_sd'] for r in rr],fmt='o',linestyle='none',capsize=3,color=colors[model],label=label)
 ax.set_xticks(range(1,6));ax.set_xlabel('Partition repetition');ax.set_ylabel('Test mean absolute error');ax.set_title(title,fontsize=11);ax.set_ylim(.080,.098);ax.grid(axis='y',alpha=.22)
axes[0].legend(fontsize=9);fig.suptitle('Fixed CLIP features: five partitions × five neural training seeds\nPoints: mean over training seeds; bars: seed SD (ridge is deterministic)',fontsize=11)
fig.savefig(A/'source_separated_results.pdf');fig.savefig(A/'source_separated_results.png',dpi=180);plt.close(fig)
lines=['FIVE-PARTITION SOURCE-SEPARATED CLIP EXTENSION','',json.dumps(v),'','Across-partition mean +/- sample SD of five partition means (not 25 independent fits):']
for r in aggregate:lines.append(f"{r['condition']:20s} {r['model']:20s} {r['MAE_mean']:.6f} +/- {r['MAE_partition_sd']:.6f}")
lines+=['','All per-partition contrasts (99.5% marginal intervals; ten-comparison family):']
for r in contr:lines.append(f"{r['partition_seed']} {r['contrast']} {r['difference_MAE']:.6f} [{r['CI99_5_lower']:.6f},{r['CI99_5_upper']:.6f}]")
for model in ['ffnn','cnn_lstm']:
 rr=[r for r in directions if r['model']==model];lines.append(f"{model}: source MAE > ridge in {sum(r['source_minus_ridge_MAE']>0 for r in rr)}/5; control MAE < ridge in {sum(r['control_minus_ridge_MAE']<0 for r in rr)}/5.")
lines+=['','Exploratory extension after first-partition outcomes. Five repetitions overlap, so are dependent. Conditions contain different test clips; no paired or causal cross-condition estimate. Cluster intervals condition on fixed fitted models, use source-recording proxies rather than identities and exclude training-population uncertainty. Two selected heads only; other heads and Qwen were not refitted.']
(A/'RESULTS.txt').write_text('\n'.join(lines)+'\n');print('\n'.join(lines),flush=True)
js(B/'COMPLETE.json',v)
