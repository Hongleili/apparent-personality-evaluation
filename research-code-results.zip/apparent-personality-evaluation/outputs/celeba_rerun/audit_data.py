from pathlib import Path
import hashlib,json,csv,zipfile
import numpy as np
root=Path(__file__).resolve().parent;data=root/'data';out=root/'audit';out.mkdir(exist_ok=True)
expected={'list_attr_celeba.txt':'75e246fa4810816ffd6ee81facbd244c','list_eval_partition.txt':'d32c9cbf5e040fd4025c592c306e6668','img_align_celeba.zip':'00d2c5bc6d35e252742224ab0c1e8fcb'}
checks={}
for name,md5 in expected.items():
 p=data/name
 alt=data/({'list_attr_celeba.txt':'list_attr_celeba.download','list_eval_partition.txt':'list_eval_partition.download','img_align_celeba.zip':'img_align_celeba.zip.part'}[name])
 if not p.exists() and alt.exists():
  h=hashlib.md5();sha=hashlib.sha256()
  with alt.open('rb') as f:
   for b in iter(lambda:f.read(2**20),b''):h.update(b);sha.update(b)
  if h.hexdigest()!=md5:
   checks[name]={'verified':False,'reason':'incomplete or checksum mismatch','bytes':alt.stat().st_size};continue
  alt.rename(p)
 if not p.exists(): checks[name]={'verified':False,'reason':'not downloaded'};continue
 h=hashlib.md5();sha=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b);sha.update(b)
 assert h.hexdigest()==md5,name
 checks[name]={'verified':True,'md5':h.hexdigest(),'sha256':sha.hexdigest(),'bytes':p.stat().st_size}
with (data/'list_attr_celeba.txt').open() as f:
 n=int(next(f));attrs=next(f).split();rows=[line.split() for line in f]
assert n==len(rows)==202599 and len(attrs)==40
names=[r[0] for r in rows];assert len(set(names))==n
a=np.array([[int(x) for x in r[1:]] for r in rows]);assert a.shape==(n,40) and set(np.unique(a))=={-1,1}
splitrows=[l.split() for l in (data/'list_eval_partition.txt').read_text().splitlines()];assert [r[0] for r in splitrows]==names
split=np.array([int(r[1]) for r in splitrows]);counts={str(k):int((split==k).sum()) for k in [0,1,2]};assert counts=={'0':162770,'1':19867,'2':19962}
selected=['Smiling','Wavy_Hair','Wearing_Hat','Heavy_Makeup','Young','Wearing_Necktie'];audit=[]
for attr in selected:
 j=attrs.index(attr);y=a[:,j]==1;majority=int(y[split==0].mean()>=.5)
 for k,label in [(0,'training'),(1,'validation'),(2,'test')]:
  yy=y[split==k];audit.append({'attribute':attr,'split':label,'n':len(yy),'positive':int(yy.sum()),'negative':int((~yy).sum()),'positive_percent':float(yy.mean()*100),'training_majority_prediction':majority,'majority_accuracy_percent':float((yy==majority).mean()*100)})
with (out/'attribute_counts_and_majority_baseline.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(audit[0]));w.writeheader();w.writerows(audit)
if checks['img_align_celeba.zip']['verified']:
 with zipfile.ZipFile(data/'img_align_celeba.zip') as z:
  files=[x for x in z.infolist() if not x.is_dir()];assert len(files)==n
  assert {Path(x.filename).name for x in files}==set(names)
  assert all(x.filename=='img_align_celeba/'+Path(x.filename).name for x in files)
  assert z.testzip() is None
 checks['img_align_celeba.zip']['image_count']=n;checks['img_align_celeba.zip']['archive_crc_verified']=True
report={'source':'Official CUHK CelebA Google Drive; MD5 references from torchvision CelebA loader','files':checks,'splits':counts,'attribute_count':40,'selected_attributes':selected,'model_inference_completed':False,'historical_reproduction':'Exact ~100000-image training subset, prompts and head settings unavailable; rerun requires explicit reconstructed protocol.'}
(out/'dataset_audit.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));print('Test majority accuracies:',[(r['attribute'],round(r['majority_accuracy_percent'],2)) for r in audit if r['split']=='test'])
