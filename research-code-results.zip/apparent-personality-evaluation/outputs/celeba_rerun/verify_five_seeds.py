from pathlib import Path
import json,csv,hashlib
import numpy as np
root=Path(__file__).parent
source=(root/'verify_results.py').read_text().split('truth=y[split==2];delta=')[0]
allrows=[];selection=[];hashes={}
for seed in range(42,47):
 code=source.replace("out=root/'results'",f"out=root/'five_seeds/seed_{seed}'")
 ns={'__file__':str(root/'verify_results.py')};exec(compile(code,'verify_saved_predictions','exec'),ns)
 for row in ns['checked']:allrows.append(dict(seed=seed,**row))
 selection.append(dict(seed=seed,best_epoch=ns['sel']['best_epoch'],epochs=len(ns['hist'])))
 for model in ['zero_shot','training_majority']:
  for split in ['validation','test']:
   filename=f'{model}_{split}_predictions.csv'
   assert (root/'five_seeds'/f'seed_{seed}'/filename).read_bytes()==(root/'results'/filename).read_bytes()
 for f in (root/'five_seeds'/f'seed_{seed}').glob('*'):hashes[f'{seed}/{f.name}']=hashlib.sha256(f.read_bytes()).hexdigest()
 print('Verified',seed,flush=True)
summary=[]
for split in ['validation','test']:
 for a in ns['attrs']:
  rows=[r for r in allrows if r['model']=='adapted_head' and r['split']==split and r['attribute']==a]
  d=dict(split=split,attribute=a)
  for k in ['accuracy','balanced_accuracy','FPR','FNR','AUROC','AP','Brier']:
   vals=np.array([r[k] for r in rows]);d[k+'_mean']=float(vals.mean());d[k+'_sd']=float(vals.std(ddof=1))
  summary.append(d)
p=root/'five_seeds'
(p/'summary.json').write_text(json.dumps(summary,indent=2))
with (p/'summary.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
(p/'verification.json').write_text(json.dumps({'status':'passed','seeds':list(range(42,47)),'prediction_rows_verified':597435,'metric_rows_verified':180,'selection':selection,'baseline_predictions_identical_to_original':True,'hashes':hashes,'scope':'Independent saved-prediction verification; not a second model training execution.'},indent=2))
for d in summary:
 if d['split']=='test':print(d['attribute'],*[f'{100*d[k+"_mean"]:.2f} +/- {100*d[k+"_sd"]:.2f}' for k in ['accuracy','balanced_accuracy','FPR','FNR']])
print(selection)
