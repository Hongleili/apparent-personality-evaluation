from pathlib import Path
import csv,json,hashlib
import numpy as np
root=Path(__file__).parent; out=root/'results'
attrs=['Smiling','Wavy_Hair','Wearing_Hat','Heavy_Makeup','Young','Wearing_Necktie']
with (root/'data/list_attr_celeba.txt').open() as f:
    n=int(next(f)); columns=next(f).split(); rows=[r.split() for r in f]
names=[r[0] for r in rows]
y=(np.array([[int(r[1+columns.index(a)]) for a in attrs] for r in rows])+1)//2
part=[r.split() for r in (root/'data/list_eval_partition.txt').read_text().splitlines()]
assert names==[r[0] for r in part] and n==202599
split=np.array([int(r[1]) for r in part]); majority=(y[split==0].mean(0)>=.5)
reported=list(csv.DictReader((out/'attribute_metrics.csv').open()))
checked=[]; predictions={}
def auc(y,p):
    order=np.argsort(p,kind='stable'); ps=p[order]; ranks=np.empty(len(p),float)
    starts=np.r_[0,np.flatnonzero(np.diff(ps))+1]; ends=np.r_[starts[1:],len(p)]
    for a,b in zip(starts,ends): ranks[order[a:b]]=(a+1+b)/2
    pos=y.sum();return (ranks[y==1].sum()-pos*(pos+1)/2)/(pos*(len(y)-pos))
def ap(y,p):
    order=np.argsort(-p,kind='stable'); yy=y[order]; pp=p[order]
    ends=np.r_[np.flatnonzero(np.diff(pp)),len(pp)-1]; tp=np.cumsum(yy)[ends]
    return np.sum(np.diff(np.r_[0,tp])*tp/(ends+1))/y.sum()
for label,i in [('validation',1),('test',2)]:
    idx=np.flatnonzero(split==i); yy=y[idx]
    for model in ['zero_shot','adapted_head','training_majority']:
        rr=list(csv.DictReader((out/f'{model}_{label}_predictions.csv').open()))
        assert [r['filename'] for r in rr]==[names[k] for k in idx]
        assert len(set(r['filename'] for r in rr))==len(idx)
        p=np.array([[float(r[a]) for a in attrs] for r in rr]);assert np.isfinite(p).all() and ((p>=0)&(p<=1)).all()
        if model=='training_majority':assert (p==majority).all()
        predictions[(label,model)]=p
        for j,a in enumerate(attrs):
            t=yy[:,j].astype(bool); pred=p[:,j]>=.5
            tp=int((t&pred).sum());tn=int((~t&~pred).sum());fp=int((~t&pred).sum());fn=int((t&~pred).sum())
            calc=dict(n=len(t),TP=tp,TN=tn,FP=fp,FN=fn,accuracy=(tp+tn)/len(t),balanced_accuracy=(tp/(tp+fn)+tn/(tn+fp))/2,FPR=fp/(fp+tn),FNR=fn/(fn+tp),recall=tp/(tp+fn),AUROC=auc(t,p[:,j]),AP=ap(t,p[:,j]),Brier=float(((p[:,j]-t)**2).mean()))
            if tp+fp:calc['precision']=tp/(tp+fp)
            r=next(r for r in reported if (r['split'],r['model'],r['attribute'])==(label,model,a))
            for k,v in calc.items():assert abs(v-float(r[k]))<2e-7,(label,model,a,k,v,r[k])
            checked.append(dict(split=label,model=model,attribute=a,**calc))
hist=list(csv.DictReader((out/'training_history.csv').open()));best=min(hist,key=lambda r:float(r['validation_BCE']));sel=json.loads((out/'selection.json').read_text())
assert int(best['epoch'])==sel['best_epoch'] and float(best['validation_BCE'])==sel['validation_BCE']
truth=y[split==2];delta=((predictions['test','adapted_head']>=.5)==truth).astype(float)-((predictions['test','zero_shot']>=.5)==truth).astype(float)
rng=np.random.default_rng(20261103);boot=np.stack([delta[rng.integers(0,len(delta),len(delta))].mean(0) for _ in range(5000)])
intervals=list(csv.DictReader((out/'paired_accuracy_intervals.csv').open()))
for j,a in enumerate(attrs):
    r=next(r for r in intervals if r['attribute']==a);q=np.quantile(boot[:,j],[.05/12,.025,.975,1-.05/12])
    for k,v in zip(['family95_low','ci95_low','ci95_high','family95_high'],q):assert abs(float(r[k])-v)<1e-12
    assert abs(float(r['accuracy_delta_head_minus_zero'])-delta[:,j].mean())<1e-12
result={'status':'passed','prediction_rows_checked':sum(len(p) for p in predictions.values()),'metric_rows_checked':len(checked),'test_images':19962,'validation_images':19867,'best_epoch':sel['best_epoch'],'epochs_run':len(hist),'bootstrap_replicates_reproduced':5000,'tolerance':2e-7,'sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file()},'scope':'Verified saved predictions against official labels; did not independently rerun encoder or training.'}
(out/'verification.json').write_text(json.dumps(result,indent=2));(out/'recomputed_metrics.json').write_text(json.dumps(checked,indent=2));print(json.dumps(result,indent=2))
