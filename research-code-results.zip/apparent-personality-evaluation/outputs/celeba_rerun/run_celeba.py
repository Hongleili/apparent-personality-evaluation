"""Reconstructed six-attribute CelebA evaluation. Does not claim historical reproduction."""
from pathlib import Path
import os,json,csv,hashlib,zipfile,random,platform,importlib.metadata
import numpy as np
ATTRS=['Smiling','Wavy_Hair','Wearing_Hat','Heavy_Makeup','Young','Wearing_Necktie']
PHRASES=[('not smiling','smiling'),('without wavy hair','with wavy hair'),('not wearing a hat','wearing a hat'),('not wearing heavy makeup','wearing heavy makeup'),('an older adult','a young adult'),('not wearing a necktie','wearing a necktie')]
MODEL='openai/clip-vit-large-patch14';REV='32bd64288804d66eefd0ccbe215aa642df71cc41'
def digest(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return h.hexdigest()
def js(p,x):
 t=Path(str(p)+'.tmp');t.write_text(json.dumps(x,indent=2));os.replace(t,p)
def csvwrite(p,rows):
 with open(p,'w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def main(data,output):
 import torch
 from PIL import Image
 from transformers import CLIPModel,CLIPProcessor
 from sklearn.metrics import roc_auc_score,average_precision_score
 data,output=Path(data),Path(output);output.mkdir(parents=True,exist_ok=True)
 assert torch.cuda.is_available(),'GPU required for the full image-inference run; no results generated'
 with (data/'list_attr_celeba.txt').open() as f:
  assert int(next(f))==202599;allattrs=next(f).split();rr=[l.split() for l in f]
 names=[r[0] for r in rr];yy=np.array([[int(v) for v in r[1:]] for r in rr]);assert yy.shape==(202599,40)
 y=((yy[:,[allattrs.index(a) for a in ATTRS]]+1)/2).astype(np.float32)
 ss=[l.split() for l in (data/'list_eval_partition.txt').read_text().splitlines()];assert [r[0] for r in ss]==names
 splits=np.array([int(r[1]) for r in ss]);assert [(splits==i).sum() for i in range(3)]==[162770,19867,19962]
 assert len(set(names))==202599
 prompts=[[f'a photo of a person {n}.',f'a photo of a person {p}.'] for n,p in PHRASES]
 prompts[4]=['a photo of an older adult.','a photo of a young adult.']
 config={'model':MODEL,'revision':REV,'attributes':ATTRS,'prompts':prompts,'seed':42,'feature':'L2-normalized projected CLIP embeddings','head':'768->128 ReLU ->6 logits; BCEWithLogitsLoss, Adam lr .001, batch256, max50epochs, patience5; min validation BCE','splits':'full official train/validation/test; no test-based selection','threshold':.5,'bootstrap_replicates':5000,'bootstrap_seed':20261103,'scope':'attribute-label agreement; not generated hallucinations or a causal explanation of ChaLearn errors','historical_difference':'full162770 training images; original ~100000 subset and settings unavailable','script_sha256':digest(__file__),'annotations_sha256':{n:digest(data/n) for n in ['list_attr_celeba.txt','list_eval_partition.txt']},'versions':{k:importlib.metadata.version(k) for k in ['torch','transformers','numpy','Pillow','scikit-learn']},'python':platform.python_version()}
 run=output/('celeba_'+hashlib.sha256(json.dumps(config,sort_keys=True).encode()).hexdigest()[:16]);run.mkdir(exist_ok=True)
 js(run/'config.json',config)
 if (run/'COMPLETE.json').exists():print('Already complete:',run);return str(run)
 cache=run/'features';cache.mkdir(exist_ok=True)
 torch.manual_seed(42);torch.cuda.manual_seed_all(42);np.random.seed(42);random.seed(42)
 torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
 model=CLIPModel.from_pretrained(MODEL,revision=REV,torch_dtype=torch.float16).cuda().eval();processor=CLIPProcessor.from_pretrained(MODEL,revision=REV)
 with torch.inference_mode():
  inputs=processor(text=sum(prompts,[]),return_tensors='pt',padding=True).to('cuda');text=model.get_text_features(**inputs).float();text=text/text.norm(dim=-1,keepdim=True)
  text=text.reshape(6,2,-1);scale=float(model.logit_scale.exp().item())
 np.savez(run/'text_features.npz',features=text.cpu().numpy(),logit_scale=scale)
 archive=zipfile.ZipFile(data/'img_align_celeba.zip');assert {Path(n).name for n in archive.namelist() if not n.endswith('/')}==set(names)
 feats=[];zero=[]
 for start in range(0,len(names),256):
  selected=names[start:start+256];p=cache/f'{start:06d}.npz'
  if p.exists():
   with np.load(p,allow_pickle=False) as z:
    assert z['names'].tolist()==selected;f=z['features'];q=z['probabilities']
    assert f.shape==(len(selected),768) and q.shape==(len(selected),6) and np.isfinite(f).all() and np.isfinite(q).all()
  else:
   ff=[];qq=[]
   for offset in range(0,len(selected),16):
    ims=[]
    for name in selected[offset:offset+16]:
     with archive.open('img_align_celeba/'+name) as fp:ims.append(Image.open(fp).convert('RGB'))
    inp=processor(images=ims,return_tensors='pt').to('cuda')
    with torch.inference_mode():
     emb=model.get_image_features(**inp).float();emb=emb/emb.norm(dim=-1,keepdim=True)
     logits=scale*torch.einsum('bd,apd->bap',emb,text);prob=logits.softmax(-1)[:,:,1]
    ff.append(emb.cpu().numpy());qq.append(prob.cpu().numpy())
   f=np.concatenate(ff);q=np.concatenate(qq)
   tmp=p.with_suffix('.tmp.npz');np.savez_compressed(tmp,names=np.array(selected),features=f,probabilities=q);os.replace(tmp,p)
  feats.append(f);zero.append(q)
  js(run/'progress.json',{'stage':'features','completed_images':min(start+256,len(names)),'total_images':len(names)})
  print('Features',min(start+256,len(names)),'/',len(names),flush=True)
 archive.close();del model;torch.cuda.empty_cache();x=np.concatenate(feats);zs=np.concatenate(zero);del feats,zero
 np.save(run/'filenames.npy',np.array(names));np.save(run/'splits.npy',splits)
 head=torch.nn.Sequential(torch.nn.Linear(768,128),torch.nn.ReLU(),torch.nn.Linear(128,6)).cuda()
 opt=torch.optim.Adam(head.parameters(),lr=.001);lossfn=torch.nn.BCEWithLogitsLoss();gen=torch.Generator().manual_seed(42)
 loader=torch.utils.data.DataLoader(torch.utils.data.TensorDataset(torch.from_numpy(x[splits==0]),torch.from_numpy(y[splits==0])),batch_size=256,shuffle=True,generator=gen)
 xv=torch.from_numpy(x[splits==1]).cuda();yv=torch.from_numpy(y[splits==1]).cuda();best=float('inf');bad=0;hist=[]
 for epoch in range(50):
  head.train()
  for xx,yy in loader:
   opt.zero_grad();loss=lossfn(head(xx.cuda()),yy.cuda());loss.backward();opt.step()
  head.eval()
  with torch.inference_mode():val=float(lossfn(head(xv),yv).item())
  hist.append({'epoch':epoch+1,'validation_BCE':val});print('Head epoch',epoch+1,'validation BCE',val,flush=True)
  if val<best:
   best=val;bad=0;state={k:v.cpu().clone() for k,v in head.state_dict().items()};torch.save(state,run/'head_best.pt');js(run/'selection.json',{'best_epoch':epoch+1,'validation_BCE':val})
  else:bad+=1
  if bad>=5:break
 csvwrite(run/'training_history.csv',hist);head.load_state_dict(torch.load(run/'head_best.pt',map_location='cpu',weights_only=True));head.eval()
 results=[];allpred={}
 for split,label in [(1,'validation'),(2,'test')]:
  idx=np.flatnonzero(splits==split)
  with torch.inference_mode():hp=np.concatenate([head(torch.from_numpy(x[ix]).cuda()).sigmoid().cpu().numpy() for ix in np.array_split(idx,max(1,len(idx)//256))])
  for kind,pred in [('zero_shot',zs[idx]),('adapted_head',hp),('training_majority',np.broadcast_to((y[splits==0].mean(0)>=.5).astype(float),(len(idx),6)))]:
   assert np.isfinite(pred).all();allpred[(label,kind)]=pred
   csvwrite(run/f'{kind}_{label}_predictions.csv',[{'filename':names[ii],**{a:float(pred[k,j]) for j,a in enumerate(ATTRS)}} for k,ii in enumerate(idx)])
   for j,a in enumerate(ATTRS):
    truth=y[idx,j].astype(bool);pp=pred[:,j]>=.5;tp=int((truth&pp).sum());tn=int((~truth&~pp).sum());fp=int((~truth&pp).sum());fn=int((truth&~pp).sum())
    results.append({'split':label,'model':kind,'attribute':a,'n':len(idx),'accuracy':(tp+tn)/len(idx),'balanced_accuracy':.5*(tp/(tp+fn)+tn/(tn+fp)),'FPR':fp/(fp+tn),'FNR':fn/(fn+tp),'precision':tp/(tp+fp) if tp+fp else None,'recall':tp/(tp+fn),'AUROC':float(roc_auc_score(truth,pred[:,j])),'AP':float(average_precision_score(truth,pred[:,j])),'Brier':float(np.mean((pred[:,j]-truth)**2)),'TP':tp,'TN':tn,'FP':fp,'FN':fn})
 csvwrite(run/'attribute_metrics.csv',results)
 truth=y[splits==2].astype(bool);delta=((allpred[('test','adapted_head')]>=.5)==truth).astype(float)-((allpred[('test','zero_shot')]>=.5)==truth).astype(float)
 rng=np.random.default_rng(20261103);boot=np.stack([delta[rng.integers(0,len(delta),len(delta))].mean(0) for _ in range(5000)])
 ci=[]
 for j,a in enumerate(ATTRS):
  q=np.quantile(boot[:,j],[.05/12,.025,.975,1-.05/12]);ci.append({'attribute':a,'accuracy_delta_head_minus_zero':float(delta[:,j].mean()),'ci95_low':q[1],'ci95_high':q[2],'family95_low':q[0],'family95_high':q[3]})
 csvwrite(run/'paired_accuracy_intervals.csv',ci)
 js(run/'COMPLETE.json',{'config':config,'n_test':19962,'n_validation':19867,'n_training':162770,'note':'Single-seed reconstructed adaptation. Paired image bootstrap assumes independent images, fixed models; subject identity clustering not available. No causal link to ChaLearn established.'})
 print('CELEBA COMPLETE:',run,flush=True);return str(run)
