"""Reconstructed six-attribute CelebA evaluation. Does not claim historical reproduction."""
from pathlib import Path
import os,json,csv,hashlib,zipfile,random,platform,importlib.metadata
import numpy as np
ATTRS=['Smiling','Wavy_Hair','Wearing_Hat','Heavy_Makeup','Young','Wearing_Necktie']
PHRASES=[('not smiling','smiling'),('without wavy hair','with wavy hair'),('not wearing a hat','wearing a hat'),('not wearing heavy makeup','wearing heavy makeup'),('an older adult','a young adult'),('not wearing a necktie','wearing a necktie')]
MODEL='openai/clip-vit-large-patch14';REV='32bd64288804d66eefd0ccbe215aa642df71cc41'
def digest(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return h.hexdigest()
def js(p,x):
 t=Path(str(p)+'.tmp');t.write_text(json.dumps(x,indent=2));os.replace(t,p)
def csvwrite(p,rows):
 with open(p,'w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def main(data, original):
 import torch
 from sklearn.metrics import roc_auc_score,average_precision_score
 data,original=Path(data),Path(original)
 base=json.loads((original/'COMPLETE.json').read_text())['config']
 for k,v in base['versions'].items():assert importlib.metadata.version(k).split(chr(43))[0]==v.split(chr(43))[0],(k,importlib.metadata.version(k),v)
 device='cuda' if torch.cuda.is_available() else 'cpu'
 torch.set_num_threads(2)
 for n,h in base['annotations_sha256'].items():assert digest(data/n)==h,(str(data/n), (data/n).stat().st_size,digest(data/n),h)
 with (data/'list_attr_celeba.txt').open() as f:
  assert int(next(f))==202599;allattrs=next(f).split();rr=[l.split() for l in f]
 names=[r[0] for r in rr];yy=np.array([[int(v) for v in r[1:]] for r in rr]);assert yy.shape==(202599,40)
 y=((yy[:,[allattrs.index(a) for a in ATTRS]]+1)/2).astype(np.float32)
 ss=[l.split() for l in (data/'list_eval_partition.txt').read_text().splitlines()];assert [r[0] for r in ss]==names
 splits=np.array([int(r[1]) for r in ss]);assert [(splits==i).sum() for i in range(3)]==[162770,19867,19962]
 assert len(set(names))==202599

 output=original.parent/(original.name+'_cpu_five_seeds_v1');output.mkdir(exist_ok=True)
 manifest={};feats=[];zero=[]
 for start in range(0,len(names),256):
  path=original/'features'/f'{start:06d}.npz'
  with np.load(path,allow_pickle=False) as z:
   assert z['names'].tolist()==names[start:start+256]
   f=z['features'];q=z['probabilities']
   assert f.shape==(min(256,len(names)-start),768) and q.shape==(len(f),6)
   assert np.isfinite(f).all() and np.isfinite(q).all() and ((q>=0)&(q<=1)).all()
   assert np.max(np.abs(np.linalg.norm(f,axis=1)-1))<.001
   feats.append(f);zero.append(q)
  manifest[path.name]=digest(path)
  if start%12800==0:print('Validated features',start,'/',len(names),flush=True)
 x=np.concatenate(feats);zs=np.concatenate(zero);del feats,zero
 js(output/'feature_manifest.json',manifest)
 js(output/'protocol.json',{'original_config':base,'matched_cpu_seeds':[42,43,44,45,46],'original_seed':42,'script_sha256':digest(__file__),'initialization':'New seeds are set immediately before head construction; original seed42 was set before CLIP loading. Original predictions retained unchanged.','selection':'Same architecture, optimizer, validation BCE, patience and maximum epochs as original','device':torch.cuda.get_device_name(0) if device=='cuda' else 'CPU; original seed42 used Tesla T4; hardware is a potential confound'})
 for seed in [42,43,44,45,46]:
  run=output/f'seed_{seed}';run.mkdir(exist_ok=True)
  if (run/'COMPLETE.json').exists():print('Already complete',seed,flush=True);continue
  torch.manual_seed(seed);torch.cuda.manual_seed_all(seed);np.random.seed(seed);random.seed(seed)
  torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
  head=torch.nn.Sequential(torch.nn.Linear(768,128),torch.nn.ReLU(),torch.nn.Linear(128,6)).to(device)
  opt=torch.optim.Adam(head.parameters(),lr=.001);lossfn=torch.nn.BCEWithLogitsLoss();gen=torch.Generator().manual_seed(seed)
  loader=torch.utils.data.DataLoader(torch.utils.data.TensorDataset(torch.from_numpy(x[splits==0]),torch.from_numpy(y[splits==0])),batch_size=256,shuffle=True,generator=gen)
  xv=torch.from_numpy(x[splits==1]).to(device);yv=torch.from_numpy(y[splits==1]).to(device);best=float('inf');bad=0;hist=[]
  for epoch in range(50):
   head.train()
   for xx,yy in loader:
    opt.zero_grad();loss=lossfn(head(xx.to(device)),yy.to(device));loss.backward();opt.step()
   head.eval()
   with torch.inference_mode():val=float(lossfn(head(xv),yv).item())
   hist.append({'epoch':epoch+1,'validation_BCE':val});print('Head epoch',epoch+1,'validation BCE',val,flush=True)
   if val<best:
    best=val;bad=0;state={k:v.cpu().clone() for k,v in head.state_dict().items()};torch.save(state,run/'head_best.pt');js(run/'selection.json',{'best_epoch':epoch+1,'validation_BCE':val})
   else:bad+=1
   if bad>=5:break
  csvwrite(run/'training_history.csv',hist);head.load_state_dict(torch.load(run/'head_best.pt',map_location='cpu',weights_only=True));head.eval()
  results=[];allpred={}
  for split,label in [(1,'validation'),(2,'test')]:
   idx=np.flatnonzero(splits==split)
   with torch.inference_mode():hp=np.concatenate([head(torch.from_numpy(x[ix]).to(device)).sigmoid().cpu().numpy() for ix in np.array_split(idx,max(1,len(idx)//256))])
   for kind,pred in [('zero_shot',zs[idx]),('adapted_head',hp),('training_majority',np.broadcast_to((y[splits==0].mean(0)>=.5).astype(float),(len(idx),6)))]:
    assert np.isfinite(pred).all();allpred[(label,kind)]=pred
    csvwrite(run/f'{kind}_{label}_predictions.csv',[{'filename':names[ii],**{a:float(pred[k,j]) for j,a in enumerate(ATTRS)}} for k,ii in enumerate(idx)])
    for j,a in enumerate(ATTRS):
     truth=y[idx,j].astype(bool);pp=pred[:,j]>=.5;tp=int((truth&pp).sum());tn=int((~truth&~pp).sum());fp=int((~truth&pp).sum());fn=int((truth&~pp).sum())
     results.append({'split':label,'model':kind,'attribute':a,'n':len(idx),'accuracy':(tp+tn)/len(idx),'balanced_accuracy':.5*(tp/(tp+fn)+tn/(tn+fp)),'FPR':fp/(fp+tn),'FNR':fn/(fn+tp),'precision':tp/(tp+fp) if tp+fp else None,'recall':tp/(tp+fn),'AUROC':float(roc_auc_score(truth,pred[:,j])),'AP':float(average_precision_score(truth,pred[:,j])),'Brier':float(np.mean((pred[:,j]-truth)**2)),'TP':tp,'TN':tn,'FP':fp,'FN':fn})
  csvwrite(run/'attribute_metrics.csv',results)
  js(run/'COMPLETE.json',{'seed':seed,'test_images':19962,'validation_images':19867,'training_images':162770})
  print('SEED COMPLETE',seed,flush=True)
 js(output/'COMPLETE.json',{'original_seed42':str(original),'matched_cpu_seeds':[42,43,44,45,46]})
 print('ALL FIVE MATCHED CPU SEEDS COMPLETE',output,flush=True)
