"""Fixed exploratory prompt comparison; no test-based prompt selection."""
from pathlib import Path
import json,csv,hashlib,os,importlib.metadata
import numpy as np
ATTRS=['Smiling','Wavy_Hair','Wearing_Hat','Heavy_Makeup','Young','Wearing_Necktie']
PHRASES=[('not smiling','smiling'),('without wavy hair','with wavy hair'),('not wearing a hat','wearing a hat'),('not wearing heavy makeup','wearing heavy makeup'),('an older adult','a young adult'),('not wearing a necktie','wearing a necktie')]
TEMPLATES={'photo':'a photo of','portrait':'a portrait of','image':'an image of','closeup':'a close-up photograph of'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):
 t=Path(str(p)+'.tmp');t.write_text(json.dumps(x,indent=2,allow_nan=False));os.replace(t,p)
def writecsv(p,rows):
 with p.open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def main(data,original):
 import torch
 from transformers import CLIPModel,CLIPProcessor
 from sklearn.metrics import roc_auc_score,average_precision_score
 torch.set_num_threads(2)
 data,original=Path(data),Path(original);base=json.loads((original/'COMPLETE.json').read_text())['config']
 for n,h in base['annotations_sha256'].items():assert sha(data/n)==h,n
 with (data/'list_attr_celeba.txt').open() as f:
  assert int(next(f))==202599;cols=next(f).split();rows=[l.split() for l in f]
 names=[r[0] for r in rows];y=(np.array([[int(r[1+cols.index(a)]) for a in ATTRS] for r in rows])+1)//2
 ss=[l.split() for l in (data/'list_eval_partition.txt').read_text().splitlines()];assert names==[r[0] for r in ss]
 split=np.array([int(r[1]) for r in ss]);idx=np.flatnonzero(split>0)
 assert [(split==i).sum() for i in range(3)]==[162770,19867,19962]
 prompts={}
 for name,prefix in TEMPLATES.items():
  prompts[name]=[[f'{prefix} a person {v}.' for v in pair] for pair in PHRASES]
  prompts[name][4]=[f'{prefix} {v}.' for v in PHRASES[4]]
 assert prompts['photo']==base['prompts']
 config={'original_run':str(original),'model':base['model'],'revision':base['revision'],'prompts':prompts,'threshold':.5,'text_precision':'CPU float32 for all four templates','image_features':'original frozen T4 features, unchanged','analysis':'Report all templates on official validation/test; no prompt selected using test scores; exploratory after original results were known','versions':{k:importlib.metadata.version(k) for k in ['torch','transformers','numpy','Pillow','scikit-learn']},'script_sha256':sha(__file__)}
 out=original.parent/'celeba_prompt_sensitivity_v1';out.mkdir(exist_ok=True)
 if (out/'config.json').exists():assert json.loads((out/'config.json').read_text())==config,'Configuration changed; use a new run folder'
 save(out/'config.json',config)
 if (out/'COMPLETE.json').exists():print('Already complete',out);return
 print('Loading pinned CLIP text encoder on CPU',flush=True)
 model=CLIPModel.from_pretrained(base['model'],revision=base['revision'],torch_dtype=torch.float32).eval()
 processor=CLIPProcessor.from_pretrained(base['model'],revision=base['revision'])
 with torch.inference_mode():
  text=processor(text=[p for pairs in prompts.values() for pair in pairs for p in pair],return_tensors='pt',padding=True)
  emb=model.get_text_features(**text).float();emb=emb/emb.norm(dim=-1,keepdim=True);scale=float(model.logit_scale.exp())
  text_features=emb.numpy().reshape(4,6,2,768)
 np.savez(out/'text_features.npz',features=text_features,scale=scale,templates=np.array(list(prompts)))
 del model
 x=[];zz=[];loaded=[];manifest={}
 for start in range(0,len(names),256):
  local=np.flatnonzero(split[start:start+256]>0)
  if not len(local):continue
  path=original/'features'/f'{start:06d}.npz'
  with np.load(path,allow_pickle=False) as z:
   assert z['names'].tolist()==names[start:start+256]
   f=z['features'][local];q=z['probabilities'][local]
   assert f.shape==(len(local),768) and np.isfinite(f).all() and np.isfinite(q).all()
   assert np.max(np.abs(np.linalg.norm(f,axis=1)-1))<.001
   x.append(f);zz.append(q);loaded.extend((start+local).tolist())
  manifest[path.name]=sha(path)
  if len(loaded)%1000<256:print('Validated evaluation features',len(loaded),'/39829',flush=True)
 assert loaded==idx.tolist();x=np.concatenate(x);reference=np.concatenate(zz)
 save(out/'feature_manifest.json',manifest)
 predictions={'original_gpu_reference':reference}
 for j,name in enumerate(prompts):
  scores=scale*np.einsum('bd,apd->bap',x,text_features[j]);scores-=scores.max(-1,keepdims=True)
  e=np.exp(scores);predictions[name]=e[:,:,1]/e.sum(-1)
 metrics=[]
 for label,number in [('validation',1),('test',2)]:
  mask=split[idx]==number;ii=idx[mask];truth=y[ii]
  for name,allpred in predictions.items():
   pred=allpred[mask];assert ((pred>=0)&(pred<=1)).all() and np.isfinite(pred).all()
   writecsv(out/f'{name}_{label}_predictions.csv',[{'filename':names[k],**{a:float(pred[z,j]) for j,a in enumerate(ATTRS)}} for z,k in enumerate(ii)])
   for j,a in enumerate(ATTRS):
    t=truth[:,j].astype(bool);b=pred[:,j]>=.5;tp=int((t&b).sum());tn=int((~t&~b).sum());fp=int((~t&b).sum());fn=int((t&~b).sum())
    metrics.append(dict(split=label,template=name,attribute=a,n=len(t),accuracy=(tp+tn)/len(t),balanced_accuracy=(tp/(tp+fn)+tn/(tn+fp))/2,FPR=fp/(fp+tn),FNR=fn/(fn+tp),AUROC=float(roc_auc_score(t,pred[:,j])),AP=float(average_precision_score(t,pred[:,j])),Brier=float(((pred[:,j]-t)**2).mean()),TP=tp,TN=tn,FP=fp,FN=fn))
 writecsv(out/'metrics.csv',metrics)
 save(out/'precision_control.json',{'max_abs_probability_difference':float(abs(predictions['photo']-reference).max()),'mean_abs_probability_difference':float(abs(predictions['photo']-reference).mean()),'threshold_disagreement_fraction':float(((predictions['photo']>=.5)!=(reference>=.5)).mean()),'note':'Compare template wording within CPU-float32 results; original fp16 text reference is a separate precision control.'})
 save(out/'COMPLETE.json',{'validation':19867,'test':19962,'templates':list(prompts),'original_reference':True})
 print('PROMPT SENSITIVITY COMPLETE',out,flush=True)
