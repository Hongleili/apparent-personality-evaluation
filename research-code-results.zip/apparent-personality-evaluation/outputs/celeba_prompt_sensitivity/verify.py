from pathlib import Path
import json,csv,hashlib
import numpy as np
root=Path(__file__).parent
src=(root.parent/'celeba_rerun/verify_results.py').read_text().split("for label,i in [('validation',1)")[0]
ns={'__file__':str(root.parent/'celeba_rerun/verify_results.py')};exec(src,ns)
names,y,split,attrs=[ns[k] for k in ['names','y','split','attrs']]
reported=list(csv.DictReader((root/'metrics.csv').open()));checked=[];preds={}
for label,i in [('validation',1),('test',2)]:
 idx=np.flatnonzero(split==i);yy=y[idx]
 for template in ['photo','portrait','image','closeup','original_gpu_reference']:
  rr=list(csv.DictReader((root/f'{template}_{label}_predictions.csv').open()))
  assert [r['filename'] for r in rr]==[names[k] for k in idx]
  p=np.array([[float(r[a]) for a in attrs] for r in rr]);assert np.isfinite(p).all() and ((p>=0)&(p<=1)).all();preds[label,template]=p
  if template=='original_gpu_reference':assert (root/f'{template}_{label}_predictions.csv').read_bytes()==(root.parent/f'celeba_rerun/results/zero_shot_{label}_predictions.csv').read_bytes()
  for j,a in enumerate(attrs):
   t=yy[:,j].astype(bool);pp=p[:,j]>=.5;tp=int((t&pp).sum());tn=int((~t&~pp).sum());fp=int((~t&pp).sum());fn=int((t&~pp).sum())
   calc=dict(n=len(t),TP=tp,TN=tn,FP=fp,FN=fn,accuracy=(tp+tn)/len(t),balanced_accuracy=(tp/(tp+fn)+tn/(tn+fp))/2,FPR=fp/(fp+tn),FNR=fn/(fn+tp),AUROC=ns['auc'](t,p[:,j]),AP=ns['ap'](t,p[:,j]),Brier=float(((p[:,j]-t)**2).mean()))
   r=next(r for r in reported if (r['split'],r['template'],r['attribute'])==(label,template,a))
   for k,v in calc.items():assert abs(v-float(r[k]))<2e-7,(label,template,a,k)
   checked.append(dict(split=label,template=template,attribute=a,**calc))
control=json.loads((root/'precision_control.json').read_text());a=np.concatenate([preds[l,'photo'] for l in ['validation','test']]);b=np.concatenate([preds[l,'original_gpu_reference'] for l in ['validation','test']])
assert abs(control['max_abs_probability_difference']-abs(a-b).max())<1e-7
assert abs(control['mean_abs_probability_difference']-abs(a-b).mean())<1e-7
assert control['threshold_disagreement_fraction']==((a>=.5)!=(b>=.5)).mean()
summary=[]
for a in attrs:
 rows=[r for r in checked if r['split']=='test' and r['attribute']==a and r['template']!='original_gpu_reference']
 d=dict(attribute=a,**{r['template']:r['accuracy']*100 for r in rows});d['range_pp']=max(d[t] for t in ['photo','portrait','image','closeup'])-min(d[t] for t in ['photo','portrait','image','closeup']);summary.append(d)
print(json.dumps(summary,indent=2));print(control)
(root/'summary.json').write_text(json.dumps(summary,indent=2));(root/'verification.json').write_text(json.dumps({'status':'passed','prediction_rows':199145,'metric_rows':60,'reference_identical':True,'precision_control_verified':True,'hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.glob('*predictions.csv')}},indent=2))
