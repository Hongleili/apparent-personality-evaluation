"""Deterministic mean-pooled linear/ridge baselines on preserved CLIP cache."""
from pathlib import Path
import csv,json,hashlib,platform
import numpy as np
from concurrent.futures import ThreadPoolExecutor

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,rows):
 with open(p,'w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def main(root,manifests,out):
 root,manifests,out=map(Path,(root,manifests,out));out.mkdir(parents=True,exist_ok=True)
 prov=json.loads((root/'provenance.json').read_text())
 traits=['openness','conscientiousness','extraversion','agreeableness','neuroticism']
 alphas=np.logspace(-6,6,25)
 protocol={'source_run':root.name,'feature':'arithmetic mean of ten original normalized projected frames; no renormalization or scaling','solver':'float64 SVD, unpenalized intercept, OLS pseudoinverse cutoff max(shape)*eps*smax','ridge_objective':'sum squared errors + alpha * sum squared coefficients','alpha_grid':alphas.tolist(),'selection':'minimum validation MSE of clipped predictions; one common alpha for all traits, training only fit; tie chooses smaller alpha','prediction':'clip to [0,1] for all metrics; raw predictions also saved','seeds':'deterministic, no repeated random seeds required','traits':traits,'numpy':np.__version__,'python':platform.python_version(),'runner_sha256':sha(__file__),'provenance_sha256':sha(root/'provenance.json')}
 if (out/'protocol.json').exists(): assert json.loads((out/'protocol.json').read_text())==protocol
 else: (out/'protocol.json').write_text(json.dumps(protocol,indent=2))
 data={};hashes=[]
 for split,count in [('training',6000),('validation',2000),('test',2000)]:
  assert sha(manifests/f'{split}.csv')==prov['annotation_csv_sha256'][split]
  rows=list(csv.DictReader(open(manifests/f'{split}.csv')));names=[r['filename'] for r in rows]
  assert len(names)==len(set(names))==count
  assert {p.name for p in (root/'features'/split).glob('*.npz')}=={n+'.npz' for n in names}
  def read(n):
   p=root/'features'/split/(n+'.npz')
   with np.load(p,allow_pickle=False) as z:
    x=z['features'];ix=z['frame_indices'];assert x.shape==(10,768) and x.dtype==np.float32 and np.isfinite(x).all()
    assert np.allclose(np.linalg.norm(x,axis=1),1,atol=1e-4) and ix.shape==(10,) and (np.diff(ix)>0).all()
    assert len(str(z['video_sha256'].item()))==64
    return x.astype(np.float64).mean(axis=0),sha(p)
  xx=[]
  with ThreadPoolExecutor(max_workers=4) as pool:
   for i,(x,h) in enumerate(pool.map(read,names)):
    xx.append(x);hashes.append({'split':split,'filename':names[i],'sha256':h})
    if (i+1)%500==0: print('Validated',split,i+1,'/',count,flush=True)
  y=np.array([[float(r[t]) for t in traits] for r in rows],dtype=np.float32).astype(float)
  data[split]=(names,np.stack(xx),y)
 for a,b in [('training','validation'),('training','test'),('validation','test')]: assert not(set(data[a][0])&set(data[b][0]))
 write(out/'feature_hashes.csv',hashes)
 _,x,y=data['training'];xm=x.mean(0);ym=y.mean(0);xc=x-xm;yc=y-ym
 print('Fitting SVD on training only',xc.shape,flush=True)
 u,s,vt=np.linalg.svd(xc,full_matrices=False);uy=u.T@yc
 cutoff=max(xc.shape)*np.finfo(float).eps*s[0]
 def coeff(alpha):
  if alpha==0:
   f=np.zeros_like(s);np.divide(1,s,out=f,where=s>cutoff)
  else: f=s/(s*s+alpha)
  return (vt.T*f)@uy
 def predict(w,split): return (data[split][1]-xm)@w+ym
 grid=[]
 for alpha in alphas:
  p=np.clip(predict(coeff(alpha),'validation'),0,1)
  grid.append({'alpha':float(alpha),'validation_MSE':float(np.mean((p-data['validation'][2])**2))})
 write(out/'ridge_validation_search.csv',grid)
 chosen=min(grid,key=lambda r:(r['validation_MSE'],r['alpha']))['alpha']
 (out/'selection.json').write_text(json.dumps({'ridge_alpha':chosen,'rank':int((s>cutoff).sum()),'svd_cutoff':cutoff,'selection_used_test':False},indent=2))
 summary=[]
 for model,alpha in [('linear',0),('ridge',chosen)]:
  w=coeff(alpha);np.savez(out/f'{model}_parameters.npz',coefficients=w,intercept=ym-xm@w,alpha=alpha)
  for split in ['validation','test']:
   names,_,yy=data[split];raw=predict(w,split);p=np.clip(raw,0,1)
   for suffix,pp in [('predictions',p),('raw_predictions',raw)]:
    write(out/f'{model}_{split}_{suffix}.csv',[{'filename':n,**{t:float(pp[i,j]) for j,t in enumerate(traits)}} for i,n in enumerate(names)])
   metrics=[]
   for j,t in enumerate(traits):
    a,b=yy[:,j],p[:,j];pos=a>=.5;pred=b>=.5;mae=float(np.abs(a-b).mean())
    metrics.append({'trait':t,'n':len(a),'MAE':mae,'PCC':float(np.corrcoef(a,b)[0,1]),'ACC':1-mae,'FPR_percent':100*float((pred&~pos).sum())/int((~pos).sum()),'FNR_percent':100*float((~pred&pos).sum())/int(pos.sum())})
   write(out/f'{model}_{split}_metrics.csv',metrics)
   summary.append({'model':model,'split':split,'alpha':float(alpha),'MSE':float(np.mean((p-yy)**2)),**{k:float(np.mean([r[k] for r in metrics])) for k in ['MAE','PCC','ACC','FPR_percent','FNR_percent']},'raw_out_of_range_fraction':float(np.mean((raw<0)|(raw>1)))})
 write(out/'summary.csv',summary)
 (out/'COMPLETE.json').write_text(json.dumps({'protocol':protocol,'summary':summary},indent=2))
 print('LINEAR AND RIDGE COMPLETE',json.dumps(summary),flush=True)
 return str(out)
