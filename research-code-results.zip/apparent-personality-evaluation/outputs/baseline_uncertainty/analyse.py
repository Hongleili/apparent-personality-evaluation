from pathlib import Path
import sys,csv,itertools,json,hashlib
import numpy as np
sys.path.insert(0,str(Path('outputs/colab_rerun').resolve()))
import experiment as exp
out=Path('outputs/baseline_uncertainty');heads=['ffnn','cnn','lstm','gru','bilstm','cnn_lstm'];seeds=[42,43,44,45,46];baselines=['linear','ridge'];hashes={}
names,y=exp.load_manifest('outputs/colab_rerun/repeat_seed_manifests','test');y=y.astype(float)
def errors(p):
 rr=list(csv.DictReader(open(p)));assert [r['filename'] for r in rr]==names
 pp=np.array([[float(r[t]) for t in exp.TRAITS] for r in rr]);assert pp.shape==(2000,5) and np.isfinite(pp).all() and (pp>=0).all() and (pp<=1).all()
 hashes[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
 return np.abs(y-pp).mean(1)
e=np.array([[errors(Path('outputs/five_seed_results')/f'seed_{s}'/f'{h}_test_predictions.csv') for h in heads] for s in seeds]).transpose(0,2,1)
b=np.array([errors(Path('outputs/linear_baselines/results')/f'{h}_test_predictions.csv') for h in baselines]).T
pairs=[(h,base) for h in heads for base in baselines]
d=np.stack([b[:,j][None,:]-e[:,:,i] for i in range(6) for j in range(2)],axis=-1);point=d.mean((0,1))
B=50000;rng=np.random.default_rng(20261104);boot=np.empty((B,12))
for start in range(0,B,64):
 n=min(64,B-start);w=rng.multinomial(5,[.2]*5,size=n)/5
 weighted=np.einsum('bs,snc->bnc',w,d);idx=rng.integers(0,2000,size=(n,2000))
 boot[start:start+n]=weighted[np.arange(n)[:,None],idx].mean(1)
seedmeans=d.mean(1);signs=np.array(list(itertools.product([-1,1],repeat=5)))
pvals=(np.abs(signs@seedmeans/5)>=np.abs(point)[None,:]-1e-15).mean(0)
order=np.argsort(pvals);adjust=np.empty(12);adjust[order]=np.minimum(1,np.maximum.accumulate(pvals[order]*(12-np.arange(12))))
rows=[];tail=.05/(2*12)
for i,(head,baseline) in enumerate(pairs):
 q=np.quantile(boot[:,i],[tail,.025,.975,1-tail])
 rows.append({'head':head,'baseline':baseline,'delta_MAE_baseline_minus_head':float(point[i]),'ci95_low':float(q[1]),'ci95_high':float(q[2]),'family95_low':float(q[0]),'family95_high':float(q[3]),'exact_seed_signflip_p':float(pvals[i]),'holm_p':float(adjust[i]),'seed_differences':seedmeans[:,i].tolist()})
exp.write_csv(out/'comparisons.csv',rows)
meta={'replicates':B,'rng_seed':20261104,'seeds':seeds,'n_test':2000,'traits':exp.TRAITS,'difference':'deterministic baseline minus neural head; positive favours neural head','resampling':'paired crossed bootstrap independently resamples seeds and clips, all five traits kept per clip; identical draws for all 12 contrasts; deterministic baseline is fixed across seeds, not five independent fitted baselines','family':'12 new exploratory contrasts: all six neural heads versus OLS and ridge; previous neural-only comparisons form a separate reported family; no joint family-wide guarantee across both analyses','adjusted_marginal_coverage':1-.05/12,'intervals':'percentile bootstrap with Bonferroni marginal levels for approximate 95% coverage over the 12-contrast family','complementary_test':'exact two-sided sign-flip on five seed-level mean differences conditional on fixed test set, Holm adjustment across 12 contrasts; assumes sign exchangeability; minimum raw p=0.0625','limitations':['Exploratory post-hoc analysis on same test set; not confirmatory','Only five seeds; bootstrap approximation limited','Test clips treated independent; identity/source clustering unavailable','Bootstrap conditions on original training/validation samples, fixed encoder, selected baseline penalty and baseline fits; does not capture training-data or hyperparameter-selection uncertainty','Exact seed sign-flip and crossed bootstrap address different uncertainty and must not be conflated'],'input_sha256':hashes,'results':rows}
(out/'analysis.json').write_text(json.dumps(meta,indent=2));np.savez_compressed(out/'bootstrap_differences.npz',differences=boot)
for r in rows: print(r['head'],r['baseline'],*[round(r[k],7) for k in ['delta_MAE_baseline_minus_head','family95_low','family95_high','holm_p']])
