"""Frozen, resumable Qwen test inference; no training or prompt selection."""
import argparse,csv,hashlib,json,os,re,time
from pathlib import Path

def digest(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def save(p,x):
 tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(x,indent=2));os.replace(tmp,p)
def parse(raw,keys):
 s=re.sub(r'^```(?:json)?\s*','',raw.strip());s=re.sub(r'\s*```$','',s)
 p=json.loads(s)
 if set(p)!=set(keys) or any(type(v) not in (int,float) or not 0<=v<=1 for v in p.values()):raise ValueError('Invalid score schema')
 return p

def main():
 a=argparse.ArgumentParser();a.add_argument('--videos',required=True,type=Path);a.add_argument('--features',required=True,type=Path);a.add_argument('--output',required=True,type=Path);a.add_argument('--max-new',type=int,default=100);a.add_argument('--preflight-only',action='store_true');args=a.parse_args()
 if args.max_new<1:raise ValueError('max-new must be positive')
 base=Path(__file__).resolve().parent;cfg=json.loads((base/'protocol.json').read_text());manifest=base/'test.csv'
 assert digest(manifest)==cfg['manifest_sha256']
 rows=list(csv.DictReader(manifest.open()));names=[r['filename'] for r in rows];assert len(names)==len(set(names))==2000
 import numpy as np
 inventory={}
 # Verify the entire test set before allocating model memory or saving predictions.
 for i,n in enumerate(names):
  if Path(n).name!=n:raise ValueError('Unsafe filename')
  video=args.videos/n;cache=args.features/(n+'.npz')
  with np.load(cache,allow_pickle=False) as f:
   expected=str(f['video_sha256'].item());indices=f['frame_indices'].tolist()
  assert digest(video)==expected,f'Video mismatch: {n}'
  inventory[n]={'video_sha256':expected,'frame_indices':indices}
  if (i+1)%100==0:print('PREFLIGHT',i+1,'/2000',flush=True)
 if args.preflight_only:print('PREFLIGHT COMPLETE; no inference');return
 import torch,importlib.metadata,cv2
 from PIL import Image
 from transformers import AutoProcessor,Qwen2_5_VLForConditionalGeneration
 assert torch.cuda.is_available(),'GPU required'
 versions={p:importlib.metadata.version(p) for p in cfg['software']}
 assert versions==cfg['software'],f'Software differs from frozen protocol: {versions}'
 identity={'protocol':cfg,'runner_sha256':digest(__file__),'versions':versions,'gpu':torch.cuda.get_device_name(0)}
 args.output.mkdir(parents=True,exist_ok=True);cp=args.output/'run_config.json'
 if cp.exists():assert json.loads(cp.read_text())==identity,'Resume configuration mismatch; do not overwrite'
 else:save(cp,identity)
 save(args.output/'verified_video_inventory.json',inventory)
 keys=cfg['keys'];pending=[]
 for n in names:
  p=args.output/(n+'.json')
  if p.exists():
   old=json.loads(p.read_text());assert old['filename']==n and old['video_sha256']==inventory[n]['video_sha256'] and old['frame_indices']==inventory[n]['frame_indices']
   try:pred=parse(old['raw'],keys)
   except Exception:assert 'parse_error' in old and 'predictions' not in old
   else:assert old['predictions']==pred
  else:pending.append(n)
 if pending:
  torch.manual_seed(42);torch.cuda.manual_seed_all(42)
  model=Qwen2_5_VLForConditionalGeneration.from_pretrained(cfg['model'],revision=cfg['revision'],torch_dtype=torch.float16,device_map='auto',attn_implementation='sdpa').eval()
  assert all(str(p.device).startswith('cuda') for p in model.parameters()),'Unexpected CPU offload'
  processor=AutoProcessor.from_pretrained(cfg['model'],revision=cfg['revision'],use_fast=True,min_pixels=cfg['min_pixels'],max_pixels=cfg['max_pixels'])
  for n in pending[:args.max_new]:
   cap=cv2.VideoCapture(str(args.videos/n),cv2.CAP_FFMPEG,[cv2.CAP_PROP_N_THREADS,1])
   try:
    count=int(cap.get(cv2.CAP_PROP_FRAME_COUNT));assert count>=10
    indices=np.rint(np.linspace(0,count-1,10)).astype(int).tolist();assert indices==inventory[n]['frame_indices']
    frames=[]
    for k in range(indices[-1]+1):
     assert cap.grab(),f'Video decode failed: {n}'
     if k in indices:
      ok,f=cap.retrieve();assert ok;frames.append(Image.fromarray(cv2.cvtColor(f,cv2.COLOR_BGR2RGB)))
   finally:cap.release()
   msgs=[{'role':'user','content':[{'type':'image'} for _ in frames]+[{'type':'text','text':cfg['prompt']}]}]
   text=processor.apply_chat_template(msgs,tokenize=False,add_generation_prompt=True)
   inputs=processor(text=[text],images=frames,return_tensors='pt',padding=True).to(model.device)
   assert inputs['image_grid_thw'].shape[0]==10
   with torch.inference_mode():tokens=model.generate(**inputs,max_new_tokens=200,do_sample=False)
   raw=processor.batch_decode(tokens[:,inputs['input_ids'].shape[1]:],skip_special_tokens=True)[0]
   rec={'filename':n,**inventory[n],'raw':raw,'input_ids_sha256':hashlib.sha256(inputs['input_ids'].cpu().numpy().tobytes()).hexdigest(),'pixels_sha256':hashlib.sha256(inputs['pixel_values'].float().cpu().numpy().tobytes()).hexdigest(),'image_grid_thw':inputs['image_grid_thw'].cpu().tolist()}
   try:rec['predictions']=parse(raw,keys)
   except Exception as e:rec['parse_error']=repr(e)
   save(args.output/(n+'.json'),rec);print('SAVED',n,'valid', 'predictions' in rec,flush=True)
 completed=[json.loads((args.output/(n+'.json')).read_text()) for n in names if (args.output/(n+'.json')).exists()]
 status={'expected':2000,'attempted':len(completed),'valid':sum('predictions' in r for r in completed),'invalid':sum('parse_error' in r for r in completed),'complete':len(completed)==2000}
 save(args.output/'status.json',status)
 if status['complete']:save(args.output/'COMPLETE.json',status)
 print(json.dumps(status),flush=True)
if __name__=='__main__':main()
