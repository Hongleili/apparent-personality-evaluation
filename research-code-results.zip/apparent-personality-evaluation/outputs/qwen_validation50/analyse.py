from pathlib import Path
import json,csv,re,hashlib,collections
import numpy as np
root=Path(__file__).resolve().parent
protocol=json.loads((root/'protocol.json').read_text()); cfg=json.loads((root/'results/config.json').read_text()); hashes=json.loads((root/'video_hashes.json').read_text())
manifest=root.parent/'colab_rerun/repeat_seed_manifests/validation.csv'
assert hashlib.sha256(manifest.read_bytes()).hexdigest()==protocol['manifest_sha256']
labels={r['filename']:r for r in csv.DictReader(manifest.open())}
traits=['openness','conscientiousness','extraversion','agreeableness','neuroticism']
assert cfg['names']==protocol['names'] and cfg['revision']==protocol['revision']
assert cfg['clear_prompt']==protocol['clear_prompt'] and cfg['original_prompt']==protocol['original_prompt']
assert cfg['script_sha256']==hashlib.sha256((root/'run_validation50.py').read_bytes()).hexdigest()
records={}; failures=[]; rows=[]; summary={}
for cond in ['clear_real','original_real']:
 records[cond]={}
 for name in protocol['names']:
  r=json.loads((root/'results'/f'{cond}_{name}.json').read_text())
  assert r['filename']==name and r['condition']==cond and r['video_sha256']==hashes[name]
  assert len(r['frame_indices'])==len(r['image_grid_thw'])==len(r['frame_sizes'])==10
  expected=traits[:-1]+(['emotional_stability'] if cond=='clear_real' else ['neuroticism'])
  try:
   s=re.sub(r'^```(?:json)?\s*','',r['raw'].strip());s=re.sub(r'\s*```$','',s);parsed=json.loads(s)
   assert set(parsed)==set(expected) and all(type(v) in (int,float) and 0<=v<=1 for v in parsed.values())
  except Exception:
   assert 'parse_error' in r and 'predictions' not in r
   failures.append({'condition':cond,'filename':name,'raw':r['raw'],'failure':'Repeated exclamation marks; no scores' if set(r['raw'])=={'!'} else 'Invalid response'})
   continue
  assert parsed==r['predictions']
  records[cond][name]=r
 valid=list(records[cond]); y=np.array([[float(labels[n][t]) for t in traits] for n in valid]); p=np.array([[records[cond][n]['predictions'][t] for t in expected] for n in valid])
 for j,t in enumerate(traits):
  yt=y[:,j]>=.5;pt=p[:,j]>=.5;tp=int((yt&pt).sum());tn=int((~yt&~pt).sum());fp=int((~yt&pt).sum());fn=int((yt&~pt).sum())
  rows.append(dict(condition=cond,trait=t,n=len(valid),MAE=float(abs(y[:,j]-p[:,j]).mean()),PCC=float(np.corrcoef(y[:,j],p[:,j])[0,1]) if np.ptp(p[:,j])>0 else None,FPR_percent=100*fp/(fp+tn),FNR_percent=100*fn/(fn+tp),TP=tp,TN=tn,FP=fp,FN=fn))
 counts=collections.Counter(map(tuple,p))
 summary[cond]={'attempted':50,'valid':len(valid),'invalid':50-len(valid),'coverage_percent':100*len(valid)/50,'unique_vectors':len(counts),'most_common_vector':counts.most_common(1)[0],**{k:float(np.mean([r[k] for r in rows if r['condition']==cond])) for k in ['MAE','PCC','FPR_percent','FNR_percent']}}
valid=list(records['clear_real']);assert set(valid)==set(records['original_real'])
a=np.array([[records['clear_real'][n]['predictions'][t] for t in traits[:-1]+['emotional_stability']] for n in valid]);b=np.array([[records['original_real'][n]['predictions'][t] for t in traits] for n in valid])
for n in valid:
 x,z=records['clear_real'][n],records['original_real'][n]
 assert x['pixels_sha256']==z['pixels_sha256'] and x['frame_indices']==z['frame_indices'] and x['image_grid_thw']==z['image_grid_thw']
y=np.array([[float(labels[n][t]) for t in traits] for n in valid]);delta=abs(a-y).mean(1)-abs(b-y).mean(1)
rng=np.random.default_rng(20261106);ci=np.quantile(delta[rng.integers(0,len(delta),(20000,len(delta)))].mean(1),[.025,.975])
paired={'n':len(valid),'identical_vectors':int(np.all(a==b,axis=1).sum()),'mean_absolute_score_change':float(abs(a-b).mean()),'per_trait_mean_absolute_score_change':dict(zip(traits,abs(a-b).mean(0).tolist())),'clear_minus_original_MAE':float(delta.mean()),'exploratory_paired_clip_bootstrap_95_CI':ci.tolist(),'bootstrap_caveat':'Unadjusted descriptive interval conditional on 48 valid clips; assumes independent clips, which may share source videos. Not confirmatory.'}
result={'conditions':summary,'paired':paired,'failures':failures,'scope':'50 validation clips, no test data. Metrics conditional on same 48 valid clips. No imputation or regeneration. No label inversion; source neuroticism interpreted as emotional stability.','checks':'100 raw responses independently parsed; manifests, planned clip set, model revision, prompt strings, script hash, video hashes, and paired input pixel hashes checked.'}
(root/'analysis.json').write_text(json.dumps(result,indent=2))
with (root/'trait_metrics.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
(root/'failure_audit.json').write_text(json.dumps(failures,indent=2))
report=['Qwen validation follow-up — verified analysis','',result['scope'],result['checks'],'']
for cond,s in summary.items(): report.append(f"{cond}: {s['valid']}/50 valid; MAE {s['MAE']:.6f}; macro PCC {s['PCC']:.6f}; macro FPR {s['FPR_percent']:.2f}%; macro FNR {s['FNR_percent']:.2f}%; {s['unique_vectors']} unique score vectors; largest duplicate group {s['most_common_vector'][1]}/48.")
report += ['',f"Prompt comparison: {paired['identical_vectors']}/48 identical vectors; mean absolute score change {paired['mean_absolute_score_change']:.6f}; clear minus original MAE {paired['clear_minus_original_MAE']:.6f}; descriptive 95% paired bootstrap interval {ci.tolist()}.",paired['bootstrap_caveat'],'','Failures: both prompts produce 200 exclamation marks for Bz3Jx4QL_6Q.005.mp4 and iOB65zCiOFM.005.mp4. All four remain failures; no repaired or imputed scores.','These data do not establish full-test performance or underlying personality validity.']
(root/'analysis_report.txt').write_text('\n'.join(report)+'\n')
print('\n'.join(report)); print('PER TRAIT',json.dumps(rows))
