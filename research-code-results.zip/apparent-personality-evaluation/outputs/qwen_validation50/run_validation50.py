from pathlib import Path
import json,hashlib,re,time,csv,os,importlib.metadata
import numpy as np
import torch
from PIL import Image
from transformers import AutoProcessor,Qwen2_5_VLForConditionalGeneration
from experiment_qwen import sample_frames
root=Path('/content/qwen_validation50'); source=Path('/content/drive/MyDrive/chalearn_qwen_results/qwen_2d7f97a4482feba5');out=source.parent/'qwen_validation50_v1';out.mkdir(exist_ok=True)
base=json.loads((source/'config.json').read_text());assert torch.cuda.is_available()
names=['0a5FOYBAIcc.001.mp4', '1hpZ2ecWqtI.001.mp4', '39BJkEXJpgc.000.mp4', '4vJ69g7gAH4.000.mp4', '8nt2PL_p-Io.001.mp4', 'ApPnsnIZozw.002.mp4', 'Ay7bZ7Sgx9Q.005.mp4', 'Bz3Jx4QL_6Q.005.mp4', 'C5qRszPK9HY.002.mp4', 'EAMHqNxa9yY.005.mp4', 'EknEAPhAjdA.005.mp4', 'FkzVX7SQ9wE.003.mp4', 'Ft0ahViXZPc.005.mp4', 'FvjIziLzffo.000.mp4', 'JKDEEwxZwrw.000.mp4', 'KIhpjwf5uAA.004.mp4', 'Lq4uvcHNiy8.005.mp4', 'NFAlff6GUpA.001.mp4', 'OiDyfO2zB7s.005.mp4', 'Pb7aNc6Kd40.004.mp4', 'Q4z4GRUtccE.003.mp4', 'QdafN9Y_j-Y.005.mp4', 'SPD5fXHVyIk.000.mp4', 'UzgW75Fd4jU.000.mp4', 'WZnLayQeIZ0.003.mp4', 'WfCSCxADlrg.003.mp4', 'XQZ5M9oLkXw.000.mp4', 'XQZ5M9oLkXw.004.mp4', 'ZxxRJRz2hf0.001.mp4', '_fJcW5234bY.001.mp4', '_fJcW5234bY.003.mp4', 'bnoPmV0_aIc.001.mp4', 'c3esnCQDoKc.000.mp4', 'gsleSGEZHAs.003.mp4', 'iOB65zCiOFM.005.mp4', 'ilOi-sQo9HI.003.mp4', 'jmuVZ3HBiWA.005.mp4', 'kPXVZD3ac8s.002.mp4', 'lnawWqnGpMc.001.mp4', 'lsXw8u4QXIU.005.mp4', 'nZC82V87Pm0.003.mp4', 'nex61B854Ms.000.mp4', 'okSmKH2k5lE.003.mp4', 'pZxqWp0e-Ik.003.mp4', 'qFYgMFMal_s.001.mp4', 't30ERiF6b50.001.mp4', 'u50B6bIkN9g.001.mp4', 'uDm7iZuX5DQ.002.mp4', 'vOEQlAMABWM.002.mp4', 'z-CV743owek.002.mp4']
keys=['openness','conscientiousness','extraversion','agreeableness','emotional_stability']
clear=('These are ten chronological frames from one video. Estimate the apparent first-impression scores that observers might assign, rather than actual personality or a clinical assessment. Use only these images. Each score must be a number from 0 to 1. The emotional_stability score means 0 for an anxious, easily upset impression and 1 for a calm, emotionally stable impression. Return only a JSON object with these five numeric keys: '+', '.join(keys)+'.')
config={'source':str(source),'model':base['model'],'revision':base['revision'],'names':names,'selection':'Uniform random 50 of 1980 validation clips, excluding first 20 pilot clips; selected without reading label values','original_prompt':base['prompt'],'clear_prompt':clear,'controls':'Two fixed wordings, real frames only, 50 new validation clips','generation':{'do_sample':False,'max_new_tokens':200},'processor':'fast=True, same min/max pixels as pilot','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'purpose':'Exploratory input-sensitivity and wording diagnostics; not prompt optimization against labels; no test data'}
def save(p,v):
 tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(v,indent=2));os.replace(tmp,p)
if (out/'config.json').exists():assert json.loads((out/'config.json').read_text())==config
else:save(out/'config.json',config)
torch.manual_seed(42)
model=Qwen2_5_VLForConditionalGeneration.from_pretrained(base['model'],revision=base['revision'],torch_dtype=torch.float16,device_map='auto',attn_implementation='sdpa').eval()
processor=AutoProcessor.from_pretrained(base['model'],revision=base['revision'],use_fast=True,min_pixels=base['min_pixels'],max_pixels=base['max_pixels'])
def infer(frames,prompt):
 messages=[{'role':'user','content':[{'type':'image'} for _ in frames]+[{'type':'text','text':prompt}]}]
 text=processor.apply_chat_template(messages,tokenize=False,add_generation_prompt=True)
 inputs=processor(text=[text],images=frames,return_tensors='pt',padding=True).to(model.device)
 assert inputs['image_grid_thw'].shape[0]==10
 with torch.inference_mode():tokens=model.generate(**inputs,max_new_tokens=200,do_sample=False)
 raw=processor.batch_decode(tokens[:,inputs['input_ids'].shape[1]:],skip_special_tokens=True)[0]
 return {'raw':raw,'input_ids_sha256':hashlib.sha256(inputs['input_ids'].cpu().numpy().tobytes()).hexdigest(),'pixels_sha256':hashlib.sha256(inputs['pixel_values'].float().cpu().numpy().tobytes()).hexdigest(),'image_grid_thw':inputs['image_grid_thw'].cpu().tolist()}
for i,name in enumerate(names):
 video=root/'data/validation'/name
 with np.load(Path('/content/drive/MyDrive/chalearn_official_results/70ac0575bf09bf29/features/validation')/(name+'.npz'),allow_pickle=False) as cache:
  old={'video_sha256':str(cache['video_sha256'].item()),'frame_indices':cache['frame_indices'].tolist()}
 assert hashlib.sha256(video.read_bytes()).hexdigest()==old['video_sha256']
 frames,indices=sample_frames(video,10);assert indices==old['frame_indices']
 for condition,imgs,prompt,expected in [('clear_real',frames,clear,keys),('original_real',frames,base['prompt'],keys[:-1]+['neuroticism'])]:
  dest=out/(condition+'_'+name+'.json')
  if dest.exists():
   previous=json.loads(dest.read_text());assert previous['video_sha256']==old['video_sha256'];continue
  record=infer(imgs,prompt);record.update(filename=name,condition=condition,frame_indices=indices,frame_sizes=[f.size for f in frames],video_sha256=old['video_sha256'])
  try:
   text=re.sub(r'^```(?:json)?\s*','',record['raw'].strip());text=re.sub(r'\s*```$','',text);p=json.loads(text)
   assert set(p)==set(expected) and all(type(v) in (int,float) and 0<=v<=1 for v in p.values())
   record['predictions']=p
  except Exception as e:record['parse_error']=repr(e)
  save(dest,record);print('DIAGNOSTIC',i+1,'/50',condition,'valid', 'predictions' in record,flush=True)
save(out/'COMPLETE.json',{'clips':50,'responses':100});print('VALIDATION50 COMPLETE',out,flush=True)
