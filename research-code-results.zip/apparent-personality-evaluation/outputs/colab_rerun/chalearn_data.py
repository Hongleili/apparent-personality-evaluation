"""ChaLearn labels and nested ZIP staging. Does not execute pickle globals."""
import collections
import csv
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import pickle
import pickletools
import shutil
import struct
import subprocess
import tempfile
import zipfile

TRAITS = ['openness', 'conscientiousness', 'extraversion', 'agreeableness', 'neuroticism']
EXPECTED = {'training': 6000, 'validation': 2000, 'test': 2000}

class _DType:
    def __init__(self, *args): self.args = args
    def __setstate__(self, state): self.state = state

def _scalar(dtype, raw):
    if dtype.args[0] != 'f8' or len(raw) != 8 or dtype.state[1] not in ('<', '>'):
        raise ValueError('Unsupported NumPy scalar representation')
    if isinstance(raw, str): raw = raw.encode('latin1')
    return struct.unpack(dtype.state[1] + 'd', raw)[0]

class _Restricted(pickle.Unpickler):
    def find_class(self, module, name):
        if (module, name) == ('numpy', 'dtype'): return _DType
        if (module, name) == ('numpy.core.multiarray', 'scalar'): return _scalar
        raise ValueError('Rejected pickle global: ' + module + '.' + name)
    def persistent_load(self, pid): raise ValueError('Persistent IDs unsupported')

def read_annotations(path):
    data = Path(path).read_bytes()
    if len(data) > 10_000_000: raise ValueError('Annotation file unexpectedly large')
    allowed = {'PROTO', 'EMPTY_DICT', 'BINPUT', 'MARK', 'SHORT_BINSTRING', 'BINUNICODE',
               'LONG_BINPUT', 'SETITEMS', 'LONG_BINGET', 'STOP', 'BINFLOAT', 'BINGET',
               'GLOBAL', 'BININT1', 'TUPLE3', 'REDUCE', 'NONE', 'BININT', 'TUPLE', 'BUILD', 'TUPLE2'}
    for op, arg, pos in pickletools.genops(data):
        if op.name not in allowed: raise ValueError('Unsupported pickle opcode: ' + op.name)
    obj = _Restricted(io.BytesIO(data), encoding='latin1').load()
    if type(obj) is not dict or not set(TRAITS) <= set(obj): raise ValueError('Invalid annotation schema')
    keys = set(obj[TRAITS[0]])
    for trait in TRAITS:
        if type(obj[trait]) is not dict or set(obj[trait]) != keys: raise ValueError('Trait key mismatch')
        for name, value in obj[trait].items():
            if type(name) is not str or Path(name).name != name or not name.endswith('.mp4'):
                raise ValueError('Invalid video key')
            if type(value) not in (int, float) or not 0 <= value <= 1: raise ValueError('Invalid score')
    return {name: [obj[t][name] for t in TRAITS] for name in sorted(keys)}

def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(8*1024*1024), b''): h.update(chunk)
    return h.hexdigest()

def atomic_json(path, obj):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(obj, indent=2, allow_nan=False)); os.replace(tmp, path)

def stage_dataset(root, destination, password_provider=None):
    """Read official annotations; safely flatten nested video ZIPs into split dirs.

    Uses native unzip for encrypted members. Passwords are requested only in memory.
    No paths supplied by ZIP members are used as output paths. No source is changed.
    """
    root, destination = Path(root), Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    labels = {s: read_annotations(root / f'annotation_{s}.pkl') for s in EXPECTED}
    for s in EXPECTED:
        if len(labels[s]) != EXPECTED[s]: raise ValueError(f'{s}: wrong annotation count')
    for i, a in enumerate(EXPECTED):
        for b in list(EXPECTED)[i+1:]:
            if set(labels[a]) & set(labels[b]): raise ValueError('Split filename overlap')
    passwords = {}
    def copy_member(archive, z, info, sink):
        if not info.flag_bits & 1:
            with z.open(info) as f: shutil.copyfileobj(f, sink, 8*1024*1024)
            return
        if not shutil.which('unzip'): raise RuntimeError('Install system unzip for encrypted ZIPs')
        key = (str(archive), info.filename)
        while True:
            for pw in list(dict.fromkeys(passwords.values())):
                sink.seek(0); sink.truncate()
                p = subprocess.run(['unzip', '-p', '-P', pw, str(archive), info.filename],
                                   stdout=sink, stderr=subprocess.PIPE)
                if p.returncode == 0: return
            if password_provider is None: raise RuntimeError('Encrypted ZIP requires password provider')
            pw = password_provider(f'Password for {Path(archive).name} / {info.filename}: ')
            if not pw: raise RuntimeError('Password entry cancelled')
            passwords[key] = pw
    def visit(archive, split, seen, depth=0):
        if depth > 5: raise ValueError('Excessive ZIP nesting')
        with zipfile.ZipFile(archive) as z:
            for info in z.infolist():
                if info.is_dir(): continue
                ext = PurePosixPath(info.filename).suffix.lower()
                if ext not in ('.zip', '.mp4'): continue
                if info.file_size > 10_000_000_000: raise ValueError('Oversized archive member')
                if ext == '.zip':
                    with tempfile.NamedTemporaryFile(suffix='.zip') as tmp:
                        copy_member(archive, z, info, tmp); tmp.flush()
                        visit(tmp.name, split, seen, depth+1)
                else:
                    name = PurePosixPath(info.filename).name
                    if name not in labels[split]: raise ValueError('Unexpected video: ' + name)
                    if name in seen: raise ValueError('Duplicate video: ' + name)
                    seen.add(name)
                    out = destination / split / name; out.parent.mkdir(parents=True, exist_ok=True)
                    if out.exists() and out.stat().st_size == info.file_size: continue
                    tmp = out.with_suffix('.mp4.tmp')
                    with open(tmp, 'w+b') as sink: copy_member(archive, z, info, sink)
                    if tmp.stat().st_size != info.file_size: raise ValueError('Video size mismatch')
                    os.replace(tmp, out)
    report = {}
    for split, prefix in [('training','train-'), ('validation','val-'), ('test','test-')]:
        seen = set()
        # Prefer already extracted inner ZIP folders, otherwise original outer archive.
        archives = sorted(p for p in root.glob(prefix+'*.zip') if 'transcription' not in p.name)
        if not archives: raise FileNotFoundError(f'No {prefix} archives in {root}')
        for archive in archives:
            folder = root / archive.stem
            inner = sorted(folder.rglob('*.zip')) if folder.is_dir() else []
            for p in inner or [archive]: visit(p, split, seen)
            print(split, archive.name, len(seen), 'video entries inspected', flush=True)
        missing = sorted(set(labels[split]) - seen)
        report[split] = {'expected': EXPECTED[split], 'found': len(seen), 'missing': missing}
        if missing: raise ValueError(f'{split}: {len(missing)} missing clips')
        with open(destination/f'{split}.csv', 'w', newline='') as f:
            w = csv.writer(f); w.writerow(['filename'] + TRAITS)
            for name, values in labels[split].items(): w.writerow([name] + values)
        report[split]['annotation_sha256'] = sha256(root/f'annotation_{split}.pkl')
    atomic_json(destination/'coverage.json', report)
    print(f'All {sum(EXPECTED.values())} annotated filenames staged. Video decoding is checked during frame extraction.')
    return report
