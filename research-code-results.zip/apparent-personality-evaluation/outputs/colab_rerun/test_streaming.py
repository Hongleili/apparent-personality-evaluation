import io
from pathlib import Path
import tempfile
import subprocess
import zipfile
from prepare_streaming import ArchiveStager
from chalearn_data import TRAITS

def test_nested_passwords_and_resume():
    with tempfile.TemporaryDirectory() as d:
        base=Path(d);inner=base/'videos.zip'
        labels={'training':{'clip.001.mp4':[.25]*5}}
        with zipfile.ZipFile(inner,'w') as z:z.writestr('subdir/clip.001.mp4',b'video-fixture-bytes')
        wrapper=base/'wrapper.zip';outer=base/'outer.zip'
        subprocess.run(['/usr/bin/zip','-q','-j','-P','inner-fixture',str(wrapper),str(inner)],check=True)
        subprocess.run(['/usr/bin/zip','-q','-j','-P','outer-fixture',str(outer),str(wrapper)],check=True)
        supplied=iter(['outer-fixture','inner-fixture'])
        dest=base/'staged';stager=ArchiveStager(dest,labels,lambda prompt:next(supplied))
        stager.add_archive(outer,'training');stager.finish_split('training')
        assert (dest/'training'/'clip.001.mp4').read_bytes()==b'video-fixture-bytes'
        resume=ArchiveStager(dest,labels)
        assert resume.reuse_archive_record('outer.zip','training')
        adopted=ArchiveStager(dest,labels)
        assert adopted.adopt_complete_split('training')
        (dest/'training'/'clip.001.mp4').write_bytes(b'bad')
        invalid=ArchiveStager(dest,labels)
        assert not invalid.reuse_archive_record('outer.zip','training')
        print('PASS two encrypted ZIP layers, safe staging, archive resume, split adoption, wrong-size rejection')

if __name__=='__main__':test_nested_passwords_and_resume()
