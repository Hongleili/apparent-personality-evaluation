"""Resume the frozen experiment from validated caches without staging complete splits.
This orchestration module does not modify experiment.py or its run identity.
"""
from pathlib import Path
import json, re, hashlib
from concurrent.futures import ThreadPoolExecutor
import numpy as np
import experiment as exp
from chalearn_data import EXPECTED, TRAITS, read_annotations, atomic_json, sha256
from prepare_streaming import ArchiveStager, ARCHIVES
from onedrive_download import FolderDownloader


def valid_cache(path, frames=10, dim=768):
    if not path.exists(): return False
    with np.load(path, allow_pickle=False) as z:
        assert set(z.files)=={'features','zero_shot','zero_shot_scaled','frame_indices','video_sha256'}, str(path)
        x=z['features']
        assert x.shape==(frames,dim) and np.isfinite(x).all(), str(path)
        assert np.allclose(np.linalg.norm(x,axis=1),1,atol=1e-4), str(path)
        for k in ('zero_shot','zero_shot_scaled'):
            assert z[k].shape==(5,) and np.isfinite(z[k]).all() and ((z[k]>=0)&(z[k]<=1)).all(), str(path)
        idx=z['frame_indices']
        assert idx.shape==(frames,) and np.issubdtype(idx.dtype,np.integer) and idx[0]==0 and (np.diff(idx)>0).all(), str(path)
        assert re.fullmatch('[0-9a-f]{64}',str(z['video_sha256'].item())), str(path)
    return True


def missing_names(run, split, names, cfg, dim):
    folder=run/'features'/split
    unexpected={p.name for p in folder.glob('*.npz')}-{n+'.npz' for n in names}
    if unexpected: raise ValueError(f'Unexpected cache filenames in {split}: {sorted(unexpected)[:5]}')
    def check(n): return valid_cache(folder/(n+'.npz'),cfg['frames'],dim)
    with ThreadPoolExecutor(max_workers=4) as pool: flags=list(pool.map(check,names))
    return {n for n,ok in zip(names,flags) if not ok}


def resume_cached(link, cache, dataset, output, config, password_provider):
    import torch
    from huggingface_hub import model_info
    cache,dataset,output=map(Path,(cache,dataset,output))
    run=output/'70ac0575bf09bf29'
    saved=json.loads((run/'provenance.json').read_text())
    cfg={**exp.DEFAULT,**config,'preparation_mode':'one_archive_then_feature_extraction'}
    assert torch.cuda.is_available(), 'GPU required'
    assert exp.versions()==saved['versions'], 'Software mismatch'
    assert sha256(exp.__file__)==saved['script_sha256'], 'Experiment code mismatch'
    assert sha256(Path(exp.__file__).with_name('chalearn_data.py'))==saved['data_script_sha256'], 'Data code mismatch'
    assert cfg==saved['config'], 'Configuration mismatch'
    assert model_info(cfg['clip_model'],revision=cfg['revision']).sha==saved['resolved_clip_revision'], 'Model revision mismatch'
    assert hashlib.sha256(json.dumps(saved,sort_keys=True).encode()).hexdigest()[:16]==run.name, 'Run identity mismatch'
    dataset.mkdir(parents=True,exist_ok=True)
    downloader=FolderDownloader(link);labels={}
    for split in EXPECTED:
        downloader.download(f'annotation_{split}.pkl',cache)
        labels[split]=read_annotations(cache/f'annotation_{split}.pkl')
        assert len(labels[split])==EXPECTED[split]
        exp.write_csv(dataset/f'{split}.csv',[{'filename':n,**dict(zip(TRAITS,y))} for n,y in labels[split].items()])
        assert sha256(dataset/f'{split}.csv')==saved['annotation_csv_sha256'][split], 'Annotation mismatch'
    splits=list(EXPECTED)
    assert all(not(set(labels[a])&set(labels[b])) for i,a in enumerate(splits) for b in splits[i+1:])
    missing={}
    for split in EXPECTED:
        missing[split]=missing_names(run,split,list(labels[split]),cfg,saved['feature_dimension'])
        print('VALIDATED',split,EXPECTED[split]-len(missing[split]),'/',EXPECTED[split],'; missing',len(missing[split]),flush=True)
    initial={s:len(v) for s,v in missing.items()}
    model=processor=None
    if any(missing.values()):
        model,processor,device,actual=exp.setup_run(dataset,output,cfg)
        assert actual==run, 'Unexpected run identity'
        stager=ArchiveStager(dataset,labels,password_provider)
        for split in EXPECTED:
            if not missing[split]:
                print('SKIP all video archives for',split,'— full validated feature cache',flush=True)
                continue
            # Try the final archive first: earlier attempts processed archives in forward order.
            # This ordering is an optimization, not an assumed filename-to-archive mapping.
            for archive in reversed(ARCHIVES[split]):
                if not missing[split]: break
                index_path=run/'archive_membership'/(archive+'.json')
                if index_path.exists():
                    index=json.loads(index_path.read_text())
                    assert index['split']==split and index['annotation_csv_sha256']==saved['annotation_csv_sha256'][split]
                    if not missing[split].intersection(index['names']):
                        print('SKIP',archive,'— no missing features',flush=True);continue
                before=set(stager.seen[split])
                if not stager.reuse_archive_record(archive,split):
                    path=downloader.download(archive,cache);stager.add_archive(path,split)
                members=stager.seen[split]-before
                atomic_json(index_path,{'split':split,'annotation_csv_sha256':saved['annotation_csv_sha256'][split], 'names':sorted(members)})
                needed=sorted(missing[split]&members)
                print('EXTRACT only',len(needed),'missing clips from',archive,flush=True)
                if needed: exp.extract_features(dataset,model,processor,device,run,cfg,{split:needed})
                for n in needed:
                    assert valid_cache(run/'features'/split/(n+'.npz'),cfg['frames'],saved['feature_dimension'])
                missing[split].difference_update(needed)
            if missing[split]: raise ValueError(f'Unresolved missing clips: {split} {len(missing[split])}')
        del model,processor
        torch.cuda.empty_cache()
    # Feature coverage is explicitly separate from media staging; never claim all videos are local.
    coverage={s:{'expected':EXPECTED[s],'validated_features':EXPECTED[s], 'initial_missing':initial[s]} for s in EXPECTED}
    atomic_json(run/'feature_resume_coverage.json',{'coverage':coverage,'resume_script_sha256':sha256(__file__),
        'cache_policy':'Validated saved features with matching experiment provenance and annotation hashes; source video hashes stored in caches are not rechecked for reused clips.'})
    for split in EXPECTED: exp.arrays(dataset,run,split,'features')
    for split in ('validation','test'):
        for key,tag in [('zero_shot','zero_shot_cosine'),('zero_shot_scaled','zero_shot_scaled')]:
            _,_,pred=exp.arrays(dataset,run,split,key);exp.evaluate(dataset,run,split,tag,pred)
    print('Feature coverage complete; training the six heads under the frozen protocol.',flush=True)
    exp.train_heads(dataset,run,'cuda',cfg)
    return str(run)
