import tempfile, unittest
from pathlib import Path
import numpy as np
from resume_cached import valid_cache, missing_names

class RecoveryTests(unittest.TestCase):
    def test_valid_missing_corrupt_and_extra(self):
        with tempfile.TemporaryDirectory() as d:
            run=Path(d);folder=run/'features'/'test';folder.mkdir(parents=True)
            p=folder/'a.mp4.npz'
            args=dict(features=np.eye(768,dtype=np.float32)[:10], zero_shot=np.ones(5)*.5,
                zero_shot_scaled=np.ones(5)*.6,frame_indices=np.arange(10),video_sha256=np.array('a'*64))
            np.savez(p,**args)
            self.assertTrue(valid_cache(p))
            self.assertEqual(missing_names(run,'test',['a.mp4','b.mp4'],{'frames':10},768),{'b.mp4'})
            args['features']=np.zeros((10,768));np.savez(p,**args)
            with self.assertRaises(AssertionError):valid_cache(p)
            with self.assertRaises(ValueError):missing_names(run,'test',['b.mp4'],{'frames':10},768)
    def test_pickle_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'x.npz';np.savez(p,features=np.array([{}],dtype=object))
            with self.assertRaises((AssertionError,ValueError)):valid_cache(p)
if __name__=='__main__':unittest.main()
