"""Stage ChaLearn one archive at a time, with resumable completion records."""
import csv
import getpass
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import tempfile
import zipfile
from chalearn_data import read_annotations, atomic_json, sha256, TRAITS, EXPECTED
from onedrive_download import FolderDownloader, FILES

ARCHIVES={'training':[f'train-{i}.zip' for i in range(1,7)],
          'validation':['val-1.zip','val-2.zip'],
          'test':['test-1e.zip','test-2e.zip']}

class ArchiveStager:
    def __init__(self,destination,labels,password_provider=None):
        self.destination=Path(destination);self.destination.mkdir(parents=True,exist_ok=True)
        self.labels=labels;self.password_provider=password_provider;self.passwords=[]
        self.seen={s:set() for s in EXPECTED}
        self.records=self.destination/'staging_records';self.records.mkdir(exist_ok=True)

    def adopt_complete_split(self,split):
        """Reuse a complete prior split, checking exact names, positive sizes and CSV targets.

        This is explicitly recorded as reuse, not as a fresh archive CRC check.
        Feature extraction later hashes each video and decodes all requested frames.
        """
        folder=self.destination/split;manifest=self.destination/f'{split}.csv'
        if not folder.is_dir() or not manifest.exists():return False
        with open(manifest) as f:rows=list(csv.DictReader(f))
        if len(rows)!=len(self.labels[split]):return False
        if {r['filename'] for r in rows}!=set(self.labels[split]):return False
        for row in rows:
            expected=self.labels[split][row['filename']]
            if any(abs(float(row[t])-expected[j])>1e-12 for j,t in enumerate(TRAITS)):return False
        files=list(folder.glob('*.mp4'))
        if {p.name for p in files}!=set(self.labels[split]) or any(p.stat().st_size<=0 for p in files):return False
        self.seen[split]=set(self.labels[split])
        atomic_json(self.records/f'{split}_adopted.json',{'split':split,'count':len(files),
            'checks':'exact names, positive sizes, exact annotation targets; archive CRC not repeated'})
        print(split,'reusing previously completed split',len(files),'clips',flush=True)
        return True

    def reuse_archive_record(self,name,split):
        path=self.records/(name+'.json')
        if not path.exists():return False
        r=json.loads(path.read_text())
        if r.get('archive')!=name or r.get('split')!=split or r.get('targets')!=self.labels[split]:
            # JSON target keys are filenames and values are lists, so a full equality check is stable.
            return False
        entries=r.get('videos',{})
        if not entries or not set(entries)<=set(self.labels[split]):return False
        for video,size in entries.items():
            p=self.destination/split/video
            if not p.exists() or p.stat().st_size!=size:return False
        if self.seen[split]&set(entries):raise ValueError('Duplicate archive completion record')
        self.seen[split].update(entries)
        print(name,'reusing completed archive',len(entries),'clips',flush=True)
        return True

    def _copy(self,archive,z,info,sink):
        if not info.flag_bits&1:
            with z.open(info) as source:shutil.copyfileobj(source,sink,8*1024*1024)
            return
        if not shutil.which('unzip'):raise RuntimeError('System unzip required')
        while True:
            for password in self.passwords:
                sink.seek(0);sink.truncate()
                r=subprocess.run(['unzip','-p','-P',password,str(archive),info.filename],stdout=sink,stderr=subprocess.PIPE)
                if r.returncode==0:return
            if self.password_provider is None:raise RuntimeError('Password required')
            password=self.password_provider(f'Password for {Path(archive).name} / {info.filename}: ')
            if not password:raise RuntimeError('Password entry cancelled')
            if password in self.passwords:raise ValueError('Password was already tried and rejected')
            self.passwords.append(password)

    def add_archive(self,archive,split):
        archive=Path(archive);entries={};existing=self.seen[split]
        def visit(path,depth=0):
            if depth>5:raise ValueError('Excessive ZIP nesting')
            with zipfile.ZipFile(path) as z:
                for info in z.infolist():
                    if info.is_dir():continue
                    ext=PurePosixPath(info.filename).suffix.lower()
                    if ext not in ('.zip','.mp4'):continue
                    if info.file_size>10_000_000_000:raise ValueError('Oversized member')
                    if ext=='.zip':
                        with tempfile.NamedTemporaryFile(suffix='.zip') as f:
                            self._copy(path,z,info,f);f.flush();visit(f.name,depth+1)
                    else:
                        name=PurePosixPath(info.filename).name
                        if name not in self.labels[split]:raise ValueError('Unexpected clip: '+name)
                        if name in entries or name in existing:raise ValueError('Duplicate clip: '+name)
                        out=self.destination/split/name;out.parent.mkdir(parents=True,exist_ok=True)
                        # Re-read member even if a previous interrupted attempt left a same-sized file.
                        tmp=out.with_suffix('.mp4.tmp')
                        with open(tmp,'w+b') as f:self._copy(path,z,info,f)
                        if tmp.stat().st_size!=info.file_size or info.file_size==0:raise ValueError('Invalid member size')
                        os.replace(tmp,out);entries[name]=info.file_size
        visit(archive)
        if not entries:raise ValueError('No MP4 clips in archive: '+archive.name)
        existing.update(entries)
        atomic_json(self.records/(archive.name+'.json'),{'archive':archive.name,'split':split,
             'videos':entries,'targets':self.labels[split],'archive_crc_read':'all staged members read to EOF'})
        print(split,archive.name,len(entries),'clips; total',len(existing),flush=True)

    def finish_split(self,split):
        missing=set(self.labels[split])-self.seen[split]
        if missing:raise ValueError(f'{split}: {len(missing)} missing clips')
        with open(self.destination/f'{split}.csv','w',newline='') as f:
            w=csv.writer(f);w.writerow(['filename']+TRAITS)
            for name,values in self.labels[split].items():w.writerow([name]+values)


def prepare_from_onedrive(link,cache,destination,password_provider=getpass.getpass,cleanup_cache=True,on_ready=None):
    cache,destination=Path(cache),Path(destination)
    # Cleanup is restricted to copies downloaded under Colab's ephemeral /content directory.
    if cleanup_cache and cache.resolve() != Path('/content/chalearn_archives'):
        raise ValueError('Automatic ZIP cleanup is restricted to /content/chalearn_archives copies')
    downloader=FolderDownloader(link)
    for split in EXPECTED:downloader.download(f'annotation_{split}.pkl',cache)
    labels={s:read_annotations(cache/f'annotation_{s}.pkl') for s in EXPECTED}
    for split in EXPECTED:
        if len(labels[split])!=EXPECTED[split]:raise ValueError('Annotation count mismatch')
    for i,a in enumerate(EXPECTED):
        for b in list(EXPECTED)[i+1:]:
            if set(labels[a])&set(labels[b]):raise ValueError('Clip split overlap')
    stager=ArchiveStager(destination,labels,password_provider)
    for split,names in ARCHIVES.items():
        if stager.adopt_complete_split(split):
            if cleanup_cache:
                for name in names:
                    p=cache/name
                    if p.exists() and p.stat().st_size==FILES[name][0]:p.unlink()
            if on_ready is not None:on_ready(split,sorted(stager.seen[split]))
            continue
        for name in names:
            before=set(stager.seen[split])
            reused=stager.reuse_archive_record(name,split)
            if not reused:
                p=downloader.download(name,cache);stager.add_archive(p,split)
            if cleanup_cache:
                p=cache/name
                if p.exists() and p.stat().st_size==FILES[name][0]:p.unlink()
            if on_ready is not None:on_ready(split,sorted(stager.seen[split]-before))
        stager.finish_split(split)
        print('Free disk GB:',shutil.disk_usage(destination).free/1e9,flush=True)
    coverage={s:{'expected':EXPECTED[s],'found':len(stager.seen[s]),
                   'annotation_sha256':sha256(cache/f'annotation_{s}.pkl')} for s in EXPECTED}
    atomic_json(destination/'coverage.json',coverage)
    print('All official splits staged:',{s:coverage[s]['found'] for s in coverage},flush=True)
    return coverage
