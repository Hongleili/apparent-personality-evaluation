"""CPU-only checks; does not test GPU inference or training."""
import io
import json
from pathlib import Path
import pickle
import tempfile
import zipfile
import numpy as np
import chalearn_data as data
from experiment import metrics

def test_metrics():
    y=np.array([[0.1]*5,[0.2]*5,[0.8]*5,[0.9]*5])
    perfect=metrics(y,y)
    assert all(abs(r['PCC']-1)<1e-12 and r['ACC']==1 and r['FPR_percent']==0 and r['FNR_percent']==0 for r in perfect)
    inverted=metrics(y,1-y)
    assert all(abs(r['PCC']+1)<1e-12 and r['FPR_percent']==100 and r['FNR_percent']==100 for r in inverted)
    constant=metrics(y,np.full_like(y,0.5))
    assert all(r['PCC'] is None and r['FPR_percent']==100 and r['FNR_percent']==0 for r in constant)
    try:metrics(y,np.full_like(y,np.nan))
    except ValueError:pass
    else:raise AssertionError('NaN accepted')

def test_restricted_pickle():
    class Exploit:
        def __reduce__(self):return (eval, ('1+1',))
    with tempfile.TemporaryDirectory() as d:
        p=Path(d)/'bad.pkl';p.write_bytes(pickle.dumps(Exploit(),protocol=2))
        try:data.read_annotations(p)
        except ValueError:pass
        else:raise AssertionError('Untrusted global accepted')

def test_nested_staging():
    original=data.EXPECTED.copy()
    try:
        data.EXPECTED.update({s:2 for s in original})
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'input';root.mkdir();dest=Path(d)/'output'
            for split,prefix in [('training','train-'),('validation','val-'),('test','test-')]:
                names=[f'{split}{i}.mp4' for i in range(2)]
                obj={t:{n:0.25 for n in names} for t in data.TRAITS}
                (root/f'annotation_{split}.pkl').write_bytes(pickle.dumps(obj,protocol=2))
                buffer=io.BytesIO()
                with zipfile.ZipFile(buffer,'w') as z:
                    for n in names:z.writestr('subdir/'+n,b'ftyp-test-content')
                with zipfile.ZipFile(root/(prefix+'1.zip'),'w') as z:z.writestr('nested.zip',buffer.getvalue())
            report=data.stage_dataset(root,dest)
            assert all(v['found']==2 and not v['missing'] for v in report.values())
            assert len(list(dest.rglob('*.mp4')))==6
            # A repeat must reuse staged outputs and retain identical coverage.
            assert data.stage_dataset(root,dest)==report
            assert not list(dest.rglob('*.tmp'))
    finally:data.EXPECTED.update(original)

if __name__=='__main__':
    test_metrics();test_restricted_pickle();test_nested_staging()
    print('PASS: metrics, rejected pickle global, nested ZIP staging, staging repeat')
