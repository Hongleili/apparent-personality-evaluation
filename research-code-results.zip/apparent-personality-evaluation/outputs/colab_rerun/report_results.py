"""Generate paper tables and FPR/FNR charts solely from saved CLIP run outputs."""
import csv
from pathlib import Path
import numpy as np
from chalearn_data import TRAITS
from experiment import load_manifest, metrics, write_csv

MODELS=['zero_shot_cosine','zero_shot_scaled','ffnn','cnn','lstm','gru','bilstm','cnn_lstm']
LABELS={'zero_shot_cosine':'CLIP zero-shot (cosine)','zero_shot_scaled':'CLIP zero-shot (scaled)',
        'ffnn':'FFNN','cnn':'CNN','lstm':'LSTM','gru':'GRU','bilstm':'BiLSTM','cnn_lstm':'CNN-LSTM',
        'training_mean':'Training mean','training_median':'Training median'}

def read_metrics(path):
    with open(path) as f:rows=list(csv.DictReader(f))
    if len(rows)!=5 or {r['trait'] for r in rows}!=set(TRAITS):raise ValueError('Incomplete metric file: '+str(path))
    if len({int(r['n']) for r in rows})!=1:raise ValueError('Inconsistent sample counts')
    return {r['trait']:{k:(None if v=='' else float(v)) for k,v in r.items() if k!='trait'} for r in rows}

def build_report(run,dataset):
    run=Path(run);destination=run/'paper_tables';destination.mkdir(exist_ok=True)
    _,ytrain=load_manifest(dataset,'training')
    for split in ['validation','test']:
        names,y=load_manifest(dataset,split)
        for tag,const in [('training_mean',ytrain.mean(0)),('training_median',np.median(ytrain,axis=0))]:
            write_csv(run/f'{tag}_{split}_metrics.csv',metrics(y,np.broadcast_to(const,y.shape)))
        all_metrics={tag:read_metrics(run/f'{tag}_{split}_metrics.csv') for tag in MODELS+['training_mean','training_median']}
        if any(int(row['n'])!=len(names) for model in all_metrics.values() for row in model.values()):
            raise ValueError('Results do not cover the full '+split+' split')
        for metric in ['ACC','PCC','FPR_percent','FNR_percent']:
            rows=[]
            for tag,model in all_metrics.items():
                vals=[model[t][metric] for t in TRAITS]
                mean=float(np.mean(vals)) if all(x is not None for x in vals) else None
                rows.append({'model':LABELS[tag],**{t:vals[i] for i,t in enumerate(TRAITS)},'mean':mean})
            write_csv(destination/f'{metric}_{split}.csv',rows)
            def fmt(v):return '--' if v is None else f'{v:.4f}'
            text=['% Generated only from saved run metrics; do not hand-edit numerical values.',
                  '% neuroticism score direction is specified in the run provenance.',
                  '\\begin{tabular}{lrrrrrr}','\\toprule',
                  'Model & Ope. & Con. & Ext. & Agr. & Neu. & Mean \\\\', '\\midrule']
            for row in rows:text.append(row['model']+' & '+' & '.join(fmt(row[t]) for t in TRAITS)+' & '+fmt(row['mean'])+' \\\\')
            text+=['\\bottomrule','\\end{tabular}']
            (destination/f'{metric}_{split}.tex').write_text('\n'.join(text)+'\n')
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        for baseline in ['zero_shot_cosine','zero_shot_scaled']:
            for metric in ['FPR_percent','FNR_percent']:
                fig,axs=plt.subplots(2,3,figsize=(13,7),sharey=True)
                for ax,trained in zip(axs.flat,MODELS[2:]):
                    x=np.arange(5)
                    for offset,tag in [(-.18,baseline),(.18,trained)]:
                        vals=[all_metrics[tag][t][metric] for t in TRAITS]
                        ax.bar(x+offset,[np.nan if v is None else v for v in vals],.36,label=LABELS[tag])
                    ax.set_xticks(x,['Ope.','Con.','Ext.','Agr.','Neu.']);ax.set_ylim(0,100)
                    ax.set_title(LABELS[trained]);ax.set_ylabel(metric.replace('_percent','')+' (%)');ax.legend(fontsize=7)
                fig.suptitle(f'{split.title()} — {metric.replace("_percent", "")} at threshold 0.5')
                fig.tight_layout();fig.savefig(destination/f'{metric}_{baseline}_{split}.png',dpi=180);plt.close(fig)
    print('Saved full-coverage tables and charts:',destination)
    return destination
