"""Download the verified ChaLearn archive set using a guest-access OneDrive folder link.

Uses a fresh requests session (stdlib urllib), not browser login/session export.
The folder link must grant file access without interactive authentication.
"""
import hashlib
import http.cookiejar
import json
from pathlib import Path
import urllib.error
import urllib.parse
import urllib.request
import zipfile

# Sizes and annotation hashes from the user's verified local copies.
FILES = {
 'annotation_training.pkl': (793769, 'cdf3aaccfb8ed217e0f34a40b0560fd5367991c4feba63d94031188da99fb2b6'),
 'annotation_validation.pkl': (261721, '4393caee5468ae44904598359d84e73ee0cbc9431d9c70465948725084527d77'),
 'annotation_test.pkl': (261721, '1d758f806581497ee17fdb1bc00c89d37b3321ffd588c3116fad4f8f479f3f4b'),
 'train-1.zip': (2784614760, None), 'train-2.zip': (2834814355, None),
 'train-3.zip': (2849275589, None), 'train-4.zip': (2797018703, None),
 'train-5.zip': (3058535653, None), 'train-6.zip': (3318816933, None),
 'val-1.zip': (3020533440, None), 'val-2.zip': (2799628344, None),
 'test-1e.zip': (3106761962, None), 'test-2e.zip': (2817034851, None),
}

def _hash(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
    return h.hexdigest()

class FolderDownloader:
    def __init__(self,link):
        parsed=urllib.parse.urlparse(link)
        if parsed.scheme!='https' or not parsed.hostname or not parsed.hostname.endswith('.sharepoint.com'):
            raise ValueError('Expected an HTTPS SharePoint/OneDrive work folder link')
        self.opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
        with self.opener.open(link,timeout=60) as response:
            final=urllib.parse.urlparse(response.url)
            if final.hostname!=parsed.hostname:raise RuntimeError('Interactive Microsoft sign-in is required; do not proceed with this downloader.')
            query=urllib.parse.parse_qs(final.query)
            folder=query.get('id',[None])[0]
        if not folder or not folder.startswith('/personal/') or '/Documents/' not in folder:
            raise RuntimeError('Could not resolve shared folder path from OneDrive redirect')
        self.folder=folder.rstrip('/')
        self.site=urllib.parse.urlunparse((parsed.scheme,parsed.netloc,self.folder.split('/Documents/',1)[0],'','',''))

    def download(self,name,directory):
        if name not in FILES:raise ValueError('File is outside the verified dataset list')
        size,digest=FILES[name];directory=Path(directory);directory.mkdir(parents=True,exist_ok=True)
        out=directory/name
        if out.exists() and out.stat().st_size==size:
            if digest and _hash(out)!=digest:raise ValueError('Existing annotation hash mismatch: '+name)
            if name.endswith('.zip') and not zipfile.is_zipfile(out):raise ValueError('Existing ZIP is invalid: '+name)
            print(name,'already available',flush=True);return out
        tmp=out.with_suffix(out.suffix+'.partial')
        start=tmp.stat().st_size if tmp.exists() else 0
        if start>size:tmp.unlink();start=0
        rel=(self.folder+'/'+name).replace("'","''")
        url=self.site+"/_api/web/GetFileByServerRelativeUrl('"+urllib.parse.quote(rel,safe='/')+"')/$value"
        headers={'Range':f'bytes={start}-'} if start and start<size else {}
        if start<size:
            request=urllib.request.Request(url,headers=headers)
            with self.opener.open(request,timeout=120) as response:
                if response.headers.get_content_type() in ('text/html','application/json'):
                    raise RuntimeError('Expected file bytes; access may have expired: '+name)
                if response.status==206:
                    if not response.headers.get('Content-Range','').startswith(f'bytes {start}-'):
                        raise RuntimeError('Unexpected server range response')
                    mode='ab'
                elif response.status==200:start=0;mode='wb'
                else:raise RuntimeError('Unexpected HTTP status')
                done=start;last=done
                with open(tmp,mode) as f:
                    while True:
                        block=response.read(8*1024*1024)
                        if not block:break
                        f.write(block);done+=len(block)
                        if done>size:raise ValueError('Received more data than expected: '+name)
                        if done-last>=256*1024*1024:
                            print(name,f'{done/size:.0%}',flush=True);last=done
        if tmp.stat().st_size!=size:raise ValueError('Incomplete download; rerun to resume: '+name)
        if digest and _hash(tmp)!=digest:raise ValueError('Annotation hash mismatch: '+name)
        if name.endswith('.zip') and not zipfile.is_zipfile(tmp):raise ValueError('Invalid ZIP download: '+name)
        tmp.replace(out);print(name,'verified size'+(' and SHA-256' if digest else ' and ZIP directory'),flush=True)
        return out

    def download_all(self,directory,names=None):
        for name in (FILES if names is None else names):self.download(name,directory)
