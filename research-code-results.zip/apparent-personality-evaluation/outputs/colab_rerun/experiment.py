"""Official-split ChaLearn CLIP rerun and optional Qwen extension.

Reconstructed protocol, not a recovery of the authors' original implementation.
"""
import csv
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import random
import re
import sys
import numpy as np
from chalearn_data import TRAITS, EXPECTED, atomic_json, sha256

PROMPTS = {
 'openness': ['a photo of a person who is closed-minded and conventional', 'a photo of a person who is open-minded and imaginative'],
 'conscientiousness': ['a photo of a careless and disorganized person', 'a photo of a careful and organized person'],
 'extraversion': ['a photo of an introverted person', 'a photo of an extroverted person'],
 'agreeableness': ['a photo of an unfriendly and uncooperative person', 'a photo of a friendly and cooperative person'],
 'neuroticism': ['a photo of a calm and emotionally stable person', 'a photo of an anxious and emotionally unstable person'],
}
DEFAULT = {'clip_model': 'openai/clip-vit-large-patch14', 'revision': 'main',
 'frames': 10, 'seed': 42, 'neuroticism_high': 'unresolved',
 'epochs': 100, 'batch_size': 64, 'lr': 0.001, 'patience': 15,
 'heads': ['ffnn','cnn','lstm','gru','bilstm','cnn_lstm'],
 'feature': 'normalized_projected', 'frame_rule': 'rounded_linspace_first_to_last',
 'prompts': PROMPTS, 'qwen_model': 'Qwen/Qwen2.5-VL-3B-Instruct'}

def metrics(y, p):
    y,p = np.asarray(y,dtype=float),np.asarray(p,dtype=float)
    if y.shape != p.shape or y.ndim != 2 or y.shape[1] != 5 or len(y)<2: raise ValueError('Invalid metric shapes')
    if not np.isfinite(y).all() or not np.isfinite(p).all(): raise ValueError('Nonfinite predictions/labels')
    if (p<0).any() or (p>1).any(): raise ValueError('Predictions out of range')
    rows=[]
    for j,t in enumerate(TRAITS):
        a,b=y[:,j],p[:,j];yb=a>=0.5;pb=b>=0.5
        tp=int((yb&pb).sum());tn=int((~yb&~pb).sum());fp=int((~yb&pb).sum());fn=int((yb&~pb).sum())
        da,db=a-a.mean(),b-b.mean();den=np.linalg.norm(da)*np.linalg.norm(db)
        rows.append({'trait':t,'n':len(a),'PCC':float(da@db/den) if den>0 and np.ptp(a)>0 and np.ptp(b)>0 else None,
                     'ACC':float(1-np.abs(a-b).mean()),'MAE':float(np.abs(a-b).mean()),
                     'FPR_percent':100*fp/(fp+tn) if fp+tn else None,
                     'FNR_percent':100*fn/(fn+tp) if fn+tp else None,
                     'TP':tp,'TN':tn,'FP':fp,'FN':fn})
    return rows

def write_csv(path, rows):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with open(path,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def load_manifest(root, split):
    with open(Path(root)/f'{split}.csv') as f: rows=list(csv.DictReader(f))
    names=[r['filename'] for r in rows]
    if len(names)!=EXPECTED[split] or len(set(names))!=len(names): raise ValueError('Incomplete/duplicate manifest')
    return names,np.array([[float(r[t]) for t in TRAITS] for r in rows],dtype=np.float32)

def sample_frames(path,n=10):
    import cv2
    from PIL import Image
    cap=cv2.VideoCapture(str(path),cv2.CAP_FFMPEG,[cv2.CAP_PROP_N_THREADS,1])
    try:
        count=int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        if count<n: raise ValueError(f'Only {count} frames: {path}')
        indices=np.rint(np.linspace(0,count-1,n)).astype(int)
        frames=[]
        selected=set(indices.tolist())
        for index in range(int(indices[-1])+1):
            if not cap.grab(): raise ValueError(f'Frame grab failed: {path} at {index}')
            if index in selected:
                ok,frame=cap.retrieve()
                if not ok or frame is None: raise ValueError(f'Frame decode failed: {path} at {index}')
                frames.append(Image.fromarray(cv2.cvtColor(frame,cv2.COLOR_BGR2RGB)))
        return frames,indices.tolist()
    finally: cap.release()

def seed_all(seed):
    import torch
    random.seed(seed);np.random.seed(seed);torch.manual_seed(seed)
    if torch.cuda.is_available():torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark=False
    torch.backends.cudnn.deterministic=True

def versions():
    return {p:importlib.metadata.version(p) for p in ['torch','transformers','numpy','opencv-python-headless','Pillow']}

def setup_run(dataset, output, config):
    import torch
    from transformers import CLIPModel,CLIPProcessor
    if config['neuroticism_high'] not in ('neuroticism','emotional_stability'):
        raise ValueError('Resolve neuroticism label direction in config before inference. See README.')
    seed_all(config['seed']);device='cuda' if torch.cuda.is_available() else 'cpu'
    model=CLIPModel.from_pretrained(config['clip_model'],revision=config['revision']).to(device).eval()
    resolved=getattr(model.config,'_commit_hash',None)
    processor=CLIPProcessor.from_pretrained(config['clip_model'],revision=resolved or config['revision'])
    provenance={'config':config,'resolved_clip_revision':resolved,'versions':versions(),
                'script_sha256':sha256(__file__),'data_script_sha256':sha256(Path(__file__).with_name('chalearn_data.py')),
                'annotation_csv_sha256':{s:sha256(Path(dataset)/f'{s}.csv') for s in EXPECTED},
                'feature_dimension':model.config.projection_dim,'device':device}
    run_id=hashlib.sha256(json.dumps(provenance,sort_keys=True).encode()).hexdigest()[:16]
    run=Path(output)/run_id;run.mkdir(parents=True,exist_ok=True);atomic_json(run/'provenance.json',provenance)
    return model,processor,device,run

def extract_features(dataset,model,processor,device,run,cfg,split_names=None):
    import torch
    import torch.nn.functional as F
    prompts=json.loads(json.dumps(cfg['prompts']))
    if cfg['neuroticism_high']=='emotional_stability':prompts['neuroticism']=list(reversed(prompts['neuroticism']))
    text=[p for t in TRAITS for p in prompts[t]]
    with torch.inference_mode():
        # Forward outputs avoid version-dependent get_*_features return types.
        tokens=processor(text=text,return_tensors='pt',padding=True).to(device)
        pooled=model.text_model(**tokens).pooler_output
        txt=F.normalize(model.text_projection(pooled),dim=-1).reshape(5,2,-1)
        scale=model.logit_scale.exp().item()
    atomic_json(run/'zero_shot_protocol.json',{'prompts_low_high':prompts,'learned_logit_scale':scale,
       'reported_variants':['cosine_softmax_temperature_1','learned_logit_scale'],
       'averaging':'mean of ten frame-level high-prompt probabilities'})
    for split in EXPECTED:
        names,_=load_manifest(dataset,split)
        if split_names is not None:
            requested=set(split_names.get(split,[]))
            if not requested<=set(names):raise ValueError('Unknown requested clip')
            names=[name for name in names if name in requested]
            if not names:continue
        folder=run/'features'/split;folder.mkdir(parents=True,exist_ok=True)
        for i,name in enumerate(names):
            video=Path(dataset)/split/name;digest=sha256(video);out=folder/(name+'.npz')
            if out.exists():
                with np.load(out,allow_pickle=False) as cached:
                    if str(cached['video_sha256'].item())==digest: continue
            try:
                frames,indices=sample_frames(video,cfg['frames'])
                with torch.inference_mode():
                    inputs=processor(images=frames,return_tensors='pt').to(device)
                    pooled=model.vision_model(pixel_values=inputs['pixel_values']).pooler_output
                    features=F.normalize(model.visual_projection(pooled),dim=-1)
                    sims=torch.einsum('nd,tkd->ntk',features,txt)
                    zs=sims.softmax(-1)[:,:,1].mean(0).cpu().numpy()
                    scaled=(scale*sims).softmax(-1)[:,:,1].mean(0).cpu().numpy()
                tmp=out.with_suffix('.tmp')
                with open(tmp,'wb') as f:np.savez_compressed(f,features=features.cpu().numpy(),zero_shot=zs,
                    zero_shot_scaled=scaled,frame_indices=np.array(indices),video_sha256=np.array(digest))
                os.replace(tmp,out)
            except Exception as e:
                atomic_json(run/'failed_video.json',{'split':split,'filename':name,'error':repr(e)})
                raise
            if (i+1)%25==0:print(split,i+1,'/',len(names),flush=True)
        print(split,'features cached for',len(names),'requested clips',flush=True)

def arrays(dataset,run,split,key):
    names,y=load_manifest(dataset,split);data=[]
    for name in names:
        with np.load(run/'features'/split/(name+'.npz'),allow_pickle=False) as f:data.append(f[key])
    x=np.stack(data)
    if not np.isfinite(x).all():raise ValueError('Nonfinite cached features')
    return names,y,x

def evaluate(dataset,run,split,tag,pred):
    names,y=load_manifest(dataset,split)
    rows=metrics(y,pred);write_csv(run/f'{tag}_{split}_metrics.csv',rows)
    means={k:float(np.mean([r[k] for r in rows])) if all(r[k] is not None for r in rows) else None
           for k in ['PCC','ACC','MAE','FPR_percent','FNR_percent']}
    atomic_json(run/f'{tag}_{split}_mean_metrics.json',means)
    write_csv(run/f'{tag}_{split}_predictions.csv',[{'filename':n,**{t:float(pred[i,j]) for j,t in enumerate(TRAITS)}} for i,n in enumerate(names)])
    print(tag,split,means,flush=True)

def make_head(kind,dim):
    import torch
    from torch import nn
    class Head(nn.Module):
        def __init__(self):
            super().__init__();self.kind=kind
            if kind=='ffnn':self.encoder=nn.Identity();width=dim
            elif kind in ('cnn','cnn_lstm'):
                self.conv=nn.Sequential(nn.Conv1d(dim,128,3,padding=1),nn.BatchNorm1d(128),nn.ReLU())
                if kind=='cnn_lstm':self.encoder=nn.LSTM(128,128,batch_first=True)
                width=128
            else:
                unit=nn.GRU if kind=='gru' else nn.LSTM
                self.encoder=unit(dim,128,batch_first=True,bidirectional=kind=='bilstm');width=256 if kind=='bilstm' else 128
            self.regressor=nn.Sequential(nn.Linear(width,128),nn.ReLU(),nn.Linear(128,5),nn.Sigmoid())
        def forward(self,x):
            if self.kind=='ffnn':z=x.mean(1)
            elif self.kind=='cnn':z=self.conv(x.transpose(1,2)).mean(2)
            else:
                if self.kind=='cnn_lstm':x=self.conv(x.transpose(1,2)).transpose(1,2)
                _,h=self.encoder(x)
                if isinstance(h,tuple):h=h[0]
                z=torch.cat([h[-2],h[-1]],dim=1) if self.kind=='bilstm' else h[-1]
            return self.regressor(z)
    return Head()

def train_heads(dataset,run,device,cfg):
    import torch
    from torch.utils.data import DataLoader,TensorDataset
    import copy
    _,yt,xt=arrays(dataset,run,'training','features');_,yv,xv=arrays(dataset,run,'validation','features')
    xv=torch.from_numpy(xv).to(device);yv_t=torch.from_numpy(yv).to(device)
    for kind in cfg['heads']:
        seed_all(cfg['seed']);head=make_head(kind,xt.shape[-1]).to(device)
        loader=DataLoader(TensorDataset(torch.from_numpy(xt),torch.from_numpy(yt)),batch_size=cfg['batch_size'],shuffle=True,
                          generator=torch.Generator().manual_seed(cfg['seed']))
        opt=torch.optim.Adam(head.parameters(),lr=cfg['lr']);loss_fn=torch.nn.MSELoss();best=float('inf');best_state=None;bad=0;history=[]
        for epoch in range(cfg['epochs']):
            head.train();total=0
            for x,y in loader:
                x,y=x.to(device),y.to(device);opt.zero_grad();loss=loss_fn(head(x),y);loss.backward();opt.step();total+=loss.item()*len(x)
            head.eval()
            with torch.inference_mode():vl=loss_fn(head(xv),yv_t).item()
            if not np.isfinite(vl):raise ValueError('Nonfinite training loss')
            history.append({'epoch':epoch+1,'training_mse':total/len(xt),'validation_mse':vl})
            if vl<best:
                best=vl;bad=0;best_state=copy.deepcopy(head.state_dict());best_epoch=epoch+1
                torch.save({'state_dict':best_state,'epoch':best_epoch,'validation_mse':best},run/f'{kind}_best.pt')
            else:bad+=1
            if bad>=cfg['patience']:break
        head.load_state_dict(best_state);head.eval();write_csv(run/f'{kind}_history.csv',history)
        for split in ['validation','test']:
            _,_,x=arrays(dataset,run,split,'features')
            with torch.inference_mode():p=head(torch.from_numpy(x).to(device)).cpu().numpy()
            evaluate(dataset,run,split,kind,p)
        atomic_json(run/f'{kind}_selection.json',{'best_epoch':best_epoch,'validation_mse':best,'seed':cfg['seed']})

def run_clip(dataset,output,config=None):
    cfg={**DEFAULT,**(config or {})}
    model,processor,device,run=setup_run(dataset,output,cfg)
    extract_features(dataset,model,processor,device,run,cfg)
    # Only validation is used for settings/selection; test is scored under fixed config.
    for split in ['validation','test']:
        for key,tag in [('zero_shot','zero_shot_cosine'),('zero_shot_scaled','zero_shot_scaled')]:
            _,_,p=arrays(dataset,run,split,key);evaluate(dataset,run,split,tag,p)
    del model,processor
    import torch
    if torch.cuda.is_available():torch.cuda.empty_cache()
    train_heads(dataset,run,device,cfg)
    return str(run)


def run_qwen(dataset,output,split='validation',limit=20,neuroticism_high='unresolved',model_id='Qwen/Qwen2.5-VL-3B-Instruct'):
    """New visual-only extension: ten chronological images in one multi-image prompt.

    Ten-frame multi-image inference is NOT native video inference or original CLIP reproduction.
    Default is a validation pilot. Inspect failures and freeze protocol before full test use.
    """
    import torch
    from transformers import AutoProcessor,Qwen2_5_VLForConditionalGeneration
    if split not in ('validation','test'):raise ValueError('Only validation/test supported')
    if neuroticism_high not in ('neuroticism','emotional_stability'):raise ValueError('Resolve label direction first')
    if not torch.cuda.is_available():raise RuntimeError('Use a GPU Colab runtime')
    seed_all(42)
    model=Qwen2_5_VLForConditionalGeneration.from_pretrained(model_id,torch_dtype=torch.float16,device_map='auto',attn_implementation='sdpa').eval()
    processor=AutoProcessor.from_pretrained(model_id,revision=getattr(model.config,'_commit_hash',None),min_pixels=256*28*28,max_pixels=512*28*28)
    high='emotional instability' if neuroticism_high=='neuroticism' else 'emotional stability'
    prompt=('These are ten chronological frames from one video. Estimate the apparent first-impression scores that observers might assign, '
       'rather than actual personality or a clinical assessment. Use only these images. Each score must be a number from 0 to 1. '
       f'The neuroticism field here has HIGH meaning {high}. '
       'Return only a JSON object with these five numeric keys: '+', '.join(TRAITS)+'.')
    config={'model':model_id,'revision':getattr(model.config,'_commit_hash',None),'prompt':prompt,'frames':10,'seed':42,
            'max_new_tokens':200,'do_sample':False,'max_pixels':512*28*28,'min_pixels':256*28*28,
            'manifest_sha256':sha256(Path(dataset)/f'{split}.csv'),'versions':versions(),'script_sha256':sha256(__file__)}
    identity=hashlib.sha256(json.dumps(config,sort_keys=True).encode()).hexdigest()[:16]
    run=Path(output)/('qwen_'+identity);run.mkdir(parents=True,exist_ok=True);atomic_json(run/'config.json',config)
    names,y=load_manifest(dataset,split)
    if limit is not None:names=names[:limit];y=y[:limit]
    records=[]
    for i,name in enumerate(names):
        video=Path(dataset)/split/name;digest=sha256(video);path=run/(split+'_'+name+'.json')
        record=None
        if path.exists():
            old=json.loads(path.read_text())
            if old.get('video_sha256')==digest:record=old
        if record is None:
            frames,indices=sample_frames(video,10)
            messages=[{'role':'user','content':[{'type':'image'} for _ in frames]+[{'type':'text','text':prompt}]}]
            text=processor.apply_chat_template(messages,tokenize=False,add_generation_prompt=True)
            inputs=processor(text=[text],images=frames,return_tensors='pt',padding=True).to(model.device)
            with torch.inference_mode():result=model.generate(**inputs,max_new_tokens=200,do_sample=False)
            raw=processor.batch_decode(result[:,inputs['input_ids'].shape[1]:],skip_special_tokens=True)[0]
            record={'filename':name,'video_sha256':digest,'frame_indices':indices,'raw':raw}
            try:
                candidate=raw.strip()
                if candidate.startswith('```'):
                    candidate=re.sub(r'^```(?:json)?\s*','',candidate);candidate=re.sub(r'\s*```$','',candidate)
                parsed=json.loads(candidate)
                if set(parsed)!=set(TRAITS):raise ValueError('Incorrect JSON keys')
                if any(type(parsed[t]) not in (int,float) or not 0<=parsed[t]<=1 for t in TRAITS):raise ValueError('Invalid scores')
                record['predictions']=parsed
            except Exception as e:record['parse_error']=repr(e)
            atomic_json(path,record)
        records.append(record)
        if (i+1)%10==0:print('Qwen',split,i+1,'/',len(names),flush=True)
    valid=[i for i,r in enumerate(records) if 'predictions' in r]
    atomic_json(run/f'{split}_coverage.json',{'attempted':len(records),'valid':len(valid),'invalid':len(records)-len(valid),
                'full_split':len(records)==EXPECTED[split],'conditional_metrics_only':len(valid)!=len(records)})
    if len(valid)>=2:
        pred=np.array([[records[i]['predictions'][t] for t in TRAITS] for i in valid]);write_csv(run/f'{split}_metrics.csv',metrics(y[valid],pred))
        write_csv(run/f'{split}_predictions.csv',[{'filename':records[i]['filename'],**records[i]['predictions']} for i in valid])
    return str(run)


def run_streamed_clip(link,cache,dataset,output,config=None,password_provider=None):
    """Extract real features after each staged archive; no long idle-GPU preparation."""
    import getpass
    from prepare_streaming import prepare_from_onedrive
    from onedrive_download import FolderDownloader
    from chalearn_data import read_annotations
    cfg={**DEFAULT,**(config or {}),'preparation_mode':'one_archive_then_feature_extraction'}
    cache,dataset=Path(cache),Path(dataset);dataset.mkdir(parents=True,exist_ok=True)
    downloader=FolderDownloader(link)
    for split in EXPECTED:
        downloader.download(f'annotation_{split}.pkl',cache)
        labels=read_annotations(cache/f'annotation_{split}.pkl')
        if len(labels)!=EXPECTED[split]:raise ValueError('Annotation count mismatch')
        # Writing a complete target manifest does not claim that media is already staged.
        write_csv(dataset/f'{split}.csv',[{'filename':name,**dict(zip(TRAITS,values))} for name,values in labels.items()])
    model,processor,device,run=setup_run(dataset,output,cfg)
    def ready(split,names):
        if names:extract_features(dataset,model,processor,device,run,cfg,split_names={split:names})
    coverage=prepare_from_onedrive(link,cache,dataset,password_provider=password_provider or getpass.getpass,cleanup_cache=True,on_ready=ready)
    atomic_json(run/'coverage.json',coverage)
    # Require every expected clip cache, including training, before writing headline metrics.
    for split in EXPECTED:arrays(dataset,run,split,'features')
    for split in ['validation','test']:
        for key,tag in [('zero_shot','zero_shot_cosine'),('zero_shot_scaled','zero_shot_scaled')]:
            _,_,pred=arrays(dataset,run,split,key);evaluate(dataset,run,split,tag,pred)
    del model,processor
    import torch
    if torch.cuda.is_available():torch.cuda.empty_cache()
    train_heads(dataset,run,device,cfg)
    return str(run)
