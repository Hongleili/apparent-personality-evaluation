from pathlib import Path
import csv,json,zipfile,hashlib
import numpy as np
import experiment as exp
from google.colab import files
source=Path('/content/drive/MyDrive/chalearn_official_results/70ac0575bf09bf29')
run=source.parent/(source.name+'_five_seeds_v1')
assert (run/'COMPLETE.json').exists(),'Training has not finished'
summary=list(csv.DictReader(open(run/'five_seed_summary.csv')))
macro=list(csv.DictReader(open(run/'per_seed_macro_metrics.csv')))
assert len(summary)==12 and len(macro)==60
counts=0
for seed in [42,43,44,45,46]:
 folder=source if seed==42 else run/f'seed_{seed}'
 for kind in json.loads((source/'provenance.json').read_text())['config']['heads']:
  for split in ['validation','test']:
   rr=list(csv.DictReader(open(folder/f'{kind}_{split}_predictions.csv')))
   names,y=exp.load_manifest(Path('/content/chalearn_repeat_manifests'),split)
   assert [r['filename'] for r in rr]==names
   p=np.array([[float(r[t]) for t in exp.TRAITS] for r in rr]);actual=exp.metrics(y,p)
   saved=list(csv.DictReader(open(folder/f'{kind}_{split}_metrics.csv')))
   assert len(saved)==5
   for a,b in zip(actual,saved):
    assert a['trait']==b['trait'] and int(b['n'])==2000
    for key in ['MAE','PCC','ACC','FPR_percent','FNR_percent']:assert abs(a[key]-float(b[key]))<1e-8
    assert abs(float(b['MAE'])+float(b['ACC'])-1)<1e-10
   m=next(r for r in macro if int(r['seed'])==seed and r['head']==kind and r['split']==split)
   for key in ['MAE','PCC','ACC','FPR_percent','FNR_percent']:assert abs(float(m[key])-np.mean([r[key] for r in actual]))<1e-10
   counts+=1
for r in summary:
 vals=[x for x in macro if x['head']==r['head'] and x['split']==r['split']]
 assert len(vals)==5
 for k in ['MAE','PCC','ACC','FPR_percent','FNR_percent']:
  a=[float(x[k]) for x in vals]
  assert abs(float(r[k+'_mean'])-np.mean(a))<1e-10
  assert abs(float(r[k+'_sd'])-np.std(a,ddof=1))<1e-10
print('VERIFIED:',counts,'prediction/metric pairs; five traits and 2000 clips per pair.')
print('TEST RESULTS: mean +/- sample SD across five seeds')
for r in summary:
 if r['split']=='test':print(r['head'],*[f'{k} {float(r[k+"_mean"]):.6f} +/- {float(r[k+"_sd"]):.6f}' for k in ['MAE','PCC','ACC']])
(run/'verification.json').write_text(json.dumps({'verified_prediction_metric_pairs':counts,'seeds':[42,43,44,45,46],'summary_recomputed':True,'sd_ddof':1,'test_n':2000},indent=2))
archive=Path('/content/ChaLearn_CLIP_five_seed_results.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in run.rglob('*'):
  if p.is_file() and p.suffix in ['.csv','.json']:z.write(p,str(p.relative_to(run)))
 for kind in json.loads((source/'provenance.json').read_text())['config']['heads']:
  for pattern in [f'{kind}_*_metrics.csv',f'{kind}_*_predictions.csv',f'{kind}_history.csv',f'{kind}_selection.json']:
   for p in source.glob(pattern):z.write(p,'seed_42/'+p.name)
 z.write(source/'provenance.json','original_run_provenance.json')
 z.write('/content/repeated_seeds.py','repeated_seeds.py')
print('RESULT ARCHIVE',archive.name,archive.stat().st_size,'bytes')
files.download(str(archive))
